import OpenAI from "openai";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export class LeanValidationEngine {
  async generateValidationFramework(startupIdea: string, targetMarket: string, industry: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are a lean startup validation expert. Create a comprehensive validation framework based on lean startup methodology. Return JSON in this format: {
              "hypotheses": [
                {
                  "type": "problem|solution|customer|business_model",
                  "hypothesis": "clear hypothesis statement",
                  "riskLevel": "high|medium|low",
                  "validationMethods": ["method1", "method2"],
                  "successCriteria": "measurable criteria",
                  "timeframe": "suggested validation period"
                }
              ],
              "mvpRecommendations": ["mvp_approach1", "mvp_approach2"],
              "keyMetrics": ["metric1", "metric2"],
              "validationSequence": ["step1", "step2", "step3"]
            }`
          },
          {
            role: "user",
            content: `Startup idea: ${startupIdea}. Target market: ${targetMarket}. Industry: ${industry}. Create a lean validation framework.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating validation framework:", error);
      throw new Error("Failed to generate validation framework");
    }
  }

  async analyzeExperimentResults(experimentData: any) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze lean startup experiment results and provide actionable insights. Return JSON in this format: {
              "conclusion": "validated|invalidated|inconclusive",
              "confidenceLevel": number_between_0_and_100,
              "keyInsights": ["insight1", "insight2"],
              "dataQuality": "assessment of data reliability",
              "nextSteps": ["action1", "action2"],
              "pivotRecommendations": ["recommendation1", "recommendation2"],
              "additionalValidation": ["validation_needed1", "validation_needed2"]
            }`
          },
          {
            role: "user",
            content: `Experiment: ${experimentData.name}. Hypothesis: ${experimentData.hypothesis}. Results: ${JSON.stringify(experimentData.results)}. Sample size: ${experimentData.sampleSize}. Duration: ${experimentData.duration}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error analyzing experiment results:", error);
      throw new Error("Failed to analyze experiment results");
    }
  }

  async generateCustomerPersonas(validationData: any) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Create detailed customer personas based on validation research data. Return JSON in this format: {
              "personas": [
                {
                  "name": "persona_name",
                  "demographics": {
                    "age": "age_range",
                    "income": "income_range",
                    "location": "location_info",
                    "occupation": "job_type"
                  },
                  "painPoints": ["pain1", "pain2"],
                  "motivations": ["motivation1", "motivation2"],
                  "behaviors": ["behavior1", "behavior2"],
                  "channels": ["channel1", "channel2"],
                  "willingness_to_pay": "price_range"
                }
              ],
              "primaryPersona": "which persona is most important",
              "marketSize": "estimated market size for each persona"
            }`
          },
          {
            role: "user",
            content: `Validation data: ${JSON.stringify(validationData)}. Generate customer personas based on this research.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating customer personas:", error);
      throw new Error("Failed to generate customer personas");
    }
  }

  async assessProductMarketFit(metrics: any) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Assess product-market fit based on key metrics and indicators. Return JSON in this format: {
              "pmfScore": number_between_0_and_100,
              "pmfStage": "pre_pmf|early_pmf|strong_pmf",
              "strongIndicators": ["indicator1", "indicator2"],
              "weakIndicators": ["indicator1", "indicator2"],
              "recommendations": ["action1", "action2"],
              "nextMilestones": ["milestone1", "milestone2"],
              "riskFactors": ["risk1", "risk2"]
            }`
          },
          {
            role: "user",
            content: `Metrics: Customer retention: ${metrics.retention}%, NPS: ${metrics.nps}, Growth rate: ${metrics.growthRate}%, Churn: ${metrics.churn}%, User engagement: ${metrics.engagement}, Revenue growth: ${metrics.revenueGrowth}%.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error assessing product-market fit:", error);
      throw new Error("Failed to assess product-market fit");
    }
  }

  async recommendExperiments(currentStage: string, validatedHypotheses: string[], pendingHypotheses: string[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Recommend the next set of lean startup experiments based on current validation stage. Return JSON in this format: {
              "priorityExperiments": [
                {
                  "name": "experiment_name",
                  "objective": "what you're trying to learn",
                  "methodology": "how to run the experiment",
                  "duration": "suggested timeframe",
                  "resources": "required resources",
                  "successMetrics": "how to measure success",
                  "riskLevel": "high|medium|low"
                }
              ],
              "quickWins": ["quick_validation1", "quick_validation2"],
              "sequencing": "suggested order of experiments"
            }`
          },
          {
            role: "user",
            content: `Current stage: ${currentStage}. Validated: ${validatedHypotheses.join(', ')}. Pending: ${pendingHypotheses.join(', ')}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error recommending experiments:", error);
      throw new Error("Failed to recommend experiments");
    }
  }

  async generateLandingPageStrategy(valueProposition: string, targetAudience: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Create a landing page strategy for lean validation including copy, structure, and testing approach. Return JSON in this format: {
              "headline": "compelling headline",
              "subheadline": "supporting subheadline",
              "valueProps": ["benefit1", "benefit2", "benefit3"],
              "cta": "call to action text",
              "socialProof": ["proof_type1", "proof_type2"],
              "testingStrategy": {
                "variants": ["variant1", "variant2"],
                "metrics": ["metric1", "metric2"],
                "duration": "test duration"
              },
              "copyFramework": "structured copy approach"
            }`
          },
          {
            role: "user",
            content: `Value proposition: ${valueProposition}. Target audience: ${targetAudience}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating landing page strategy:", error);
      throw new Error("Failed to generate landing page strategy");
    }
  }

  async analyzeFeedback(feedbackData: any[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze customer feedback and extract actionable insights for product development. Return JSON in this format: {
              "themes": [
                {
                  "theme": "main theme",
                  "frequency": "how often mentioned",
                  "sentiment": "positive|negative|neutral",
                  "priority": "high|medium|low"
                }
              ],
              "featureRequests": ["feature1", "feature2"],
              "painPoints": ["pain1", "pain2"],
              "delighters": ["positive1", "positive2"],
              "actionableInsights": ["insight1", "insight2"]
            }`
          },
          {
            role: "user",
            content: `Customer feedback: ${feedbackData.map(f => `"${f.feedback}" - ${f.source}`).join('; ')}`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error analyzing feedback:", error);
      throw new Error("Failed to analyze feedback");
    }
  }

  async generatePivotRecommendations(currentModel: any, validationResults: any) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze validation results and recommend pivot strategies if needed. Return JSON in this format: {
              "pivotNeeded": true|false,
              "pivotTypes": [
                {
                  "type": "customer_segment|problem|solution|revenue_model|channel",
                  "description": "what to change",
                  "rationale": "why this pivot makes sense",
                  "effort": "high|medium|low",
                  "risk": "high|medium|low"
                }
              ],
              "preserveElements": ["what_to_keep1", "what_to_keep2"],
              "timeline": "suggested pivot timeline",
              "validationPlan": "how to validate the pivot"
            }`
          },
          {
            role: "user",
            content: `Current model: ${JSON.stringify(currentModel)}. Validation results: ${JSON.stringify(validationResults)}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating pivot recommendations:", error);
      throw new Error("Failed to generate pivot recommendations");
    }
  }
}

export const leanValidationEngine = new LeanValidationEngine();