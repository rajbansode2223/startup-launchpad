import OpenAI from "openai";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export class AICofounderAssistant {
  async generateCofounderProfile(userSkills: string[], industry: string, userExperience: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an AI co-founder assistant that helps entrepreneurs find the perfect co-founder based on complementary skills and experience. Generate detailed co-founder profiles that would complement the user's background. Return JSON in this format: {
              "profiles": [
                {
                  "title": "ideal role title",
                  "skills": ["skill1", "skill2"],
                  "experience": "experience description",
                  "reasoning": "why this profile complements the user",
                  "priority": "high|medium|low"
                }
              ]
            }`
          },
          {
            role: "user",
            content: `User has skills: ${userSkills.join(', ')}. Industry: ${industry}. Experience: ${userExperience}. Generate 3 complementary co-founder profiles.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating co-founder profiles:", error);
      throw new Error("Failed to generate co-founder recommendations");
    }
  }

  async analyzeCofounderCompatibility(user1Profile: any, user2Profile: any) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze the compatibility between two potential co-founders based on their profiles. Consider skill complementarity, experience alignment, and potential conflicts. Return JSON in this format: {
              "compatibilityScore": number_between_0_and_100,
              "strengths": ["strength1", "strength2"],
              "concerns": ["concern1", "concern2"],
              "recommendations": ["recommendation1", "recommendation2"],
              "overall": "detailed compatibility assessment"
            }`
          },
          {
            role: "user",
            content: `Profile 1: Skills: ${user1Profile.skills?.join(', ')}, Experience: ${user1Profile.experience}, Bio: ${user1Profile.bio}
            
            Profile 2: Skills: ${user2Profile.skills?.join(', ')}, Experience: ${user2Profile.experience}, Bio: ${user2Profile.bio}`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error analyzing compatibility:", error);
      throw new Error("Failed to analyze co-founder compatibility");
    }
  }

  async generateStartupAdvice(startupData: any, userRole: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an experienced startup advisor and co-founder mentor. Provide actionable advice for startup development based on the current state and user's role. Return JSON in this format: {
              "immediateActions": ["action1", "action2"],
              "strategicAdvice": ["advice1", "advice2"],
              "cofounderGaps": ["gap1", "gap2"],
              "nextMilestones": ["milestone1", "milestone2"],
              "riskFactors": ["risk1", "risk2"]
            }`
          },
          {
            role: "user",
            content: `Startup: ${startupData.name} in ${startupData.industry}. Description: ${startupData.description}. Current valuation: $${startupData.valuation}. User role: ${userRole}. Stage: ${startupData.stage || 'early'}. Team size: ${startupData.teamSize || 'unknown'}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating startup advice:", error);
      throw new Error("Failed to generate startup advice");
    }
  }

  async assessTeamDynamics(teamMembers: any[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze team dynamics and provide insights on team composition, skill gaps, and collaboration potential. Return JSON in this format: {
              "teamStrength": number_between_0_and_100,
              "skillCoverage": ["covered_area1", "covered_area2"],
              "skillGaps": ["gap1", "gap2"],
              "leadershipBalance": "assessment of leadership distribution",
              "communicationStyle": "team communication analysis",
              "recommendations": ["recommendation1", "recommendation2"]
            }`
          },
          {
            role: "user",
            content: `Team composition: ${teamMembers.map(member => 
              `${member.firstName} ${member.lastName}: ${member.skills?.join(', ') || 'No skills listed'}, Experience: ${member.experience || 'Not specified'}`
            ).join('; ')}`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error assessing team dynamics:", error);
      throw new Error("Failed to assess team dynamics");
    }
  }

  async generateEquitySplitRecommendation(founders: any[], startupStage: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Provide equity split recommendations for co-founders based on their contributions, experience, and the startup stage. Return JSON in this format: {
              "recommendations": [
                {
                  "founder": "founder_name",
                  "suggestedEquity": number_percentage,
                  "reasoning": "justification for this equity percentage"
                }
              ],
              "considerations": ["factor1", "factor2"],
              "vestingRecommendation": "vesting schedule suggestion",
              "disclaimers": ["legal_disclaimer1", "legal_disclaimer2"]
            }`
          },
          {
            role: "user",
            content: `Founders: ${founders.map(f => 
              `${f.name}: Skills ${f.skills}, Experience: ${f.experience}, Contribution: ${f.contribution || 'General'}, Time commitment: ${f.timeCommitment || '100%'}`
            ).join('; ')}. Startup stage: ${startupStage}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating equity recommendations:", error);
      throw new Error("Failed to generate equity split recommendations");
    }
  }

  async suggestNetworkingOpportunities(userProfile: any, targetGoals: string[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Suggest networking opportunities and strategies for finding co-founders and building professional relationships. Return JSON in this format: {
              "events": ["event_type1", "event_type2"],
              "platforms": ["platform1", "platform2"],
              "strategies": ["strategy1", "strategy2"],
              "pitchPoints": ["point1", "point2"],
              "conversationStarters": ["starter1", "starter2"]
            }`
          },
          {
            role: "user",
            content: `Profile: Skills ${userProfile.skills?.join(', ')}, Industry: ${userProfile.industry}, Location: ${userProfile.location || 'Remote'}. Goals: ${targetGoals.join(', ')}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating networking suggestions:", error);
      throw new Error("Failed to generate networking opportunities");
    }
  }
}

export const aiCofounderAssistant = new AICofounderAssistant();