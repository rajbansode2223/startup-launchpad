import OpenAI from "openai";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface MarketData {
  sector: string;
  fundingVolume: number;
  dealCount: number;
  averageValuation: number;
  hotTrends: string[];
  riskFactors: string[];
}

interface InvestorActivity {
  investorId: string;
  recentInvestments: number;
  portfolioGrowth: number;
  focusAreas: string[];
  investmentStyle: string;
}

export class InvestorPulseDashboard {
  async generateMarketInsights(timeframe: string = "30d", sectors: string[] = []) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Generate comprehensive market insights for startup investment opportunities. Return JSON in this format: {
              "marketOverview": {
                "totalFunding": "funding amount trend",
                "dealVolume": "number of deals trend",
                "hotSectors": ["sector1", "sector2"],
                "emergingTrends": ["trend1", "trend2"]
              },
              "sectorAnalysis": [
                {
                  "sector": "sector_name",
                  "fundingGrowth": "percentage_change",
                  "dealCount": number,
                  "averageRound": "average_funding_amount",
                  "keyPlayers": ["company1", "company2"],
                  "outlook": "positive|neutral|negative"
                }
              ],
              "investmentOpportunities": [
                {
                  "opportunity": "specific opportunity",
                  "reasoning": "why this is attractive",
                  "riskLevel": "high|medium|low",
                  "timeHorizon": "short|medium|long"
                }
              ],
              "riskFactors": ["risk1", "risk2"],
              "recommendedActions": ["action1", "action2"]
            }`
          },
          {
            role: "user",
            content: `Analyze market trends for ${timeframe} timeframe. ${sectors.length ? `Focus on sectors: ${sectors.join(', ')}` : 'Cover all major sectors'}. Provide investment insights.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating market insights:", error);
      throw new Error("Failed to generate market insights");
    }
  }

  async analyzeInvestorBehavior(investorData: InvestorActivity[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze investor behavior patterns and market sentiment. Return JSON in this format: {
              "behaviorPatterns": [
                {
                  "pattern": "pattern description",
                  "frequency": "how common this pattern is",
                  "impact": "market impact of this behavior"
                }
              ],
              "investorTypes": [
                {
                  "type": "investor type",
                  "characteristics": ["trait1", "trait2"],
                  "preferredStages": ["stage1", "stage2"],
                  "avgTicketSize": "investment range"
                }
              ],
              "marketSentiment": "bullish|bearish|neutral",
              "competitiveMetrics": {
                "averageResponseTime": "time to decision",
                "fundingSuccess": "percentage",
                "valuationTrends": "trend direction"
              }
            }`
          },
          {
            role: "user",
            content: `Investor activity data: ${JSON.stringify(investorData)}. Analyze patterns and market sentiment.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error analyzing investor behavior:", error);
      throw new Error("Failed to analyze investor behavior");
    }
  }

  async generateStartupScoring(startupData: any, marketContext: any) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Score startups based on investment attractiveness using multiple criteria. Return JSON in this format: {
              "overallScore": number_between_0_and_100,
              "scoreBreakdown": {
                "team": number_between_0_and_100,
                "market": number_between_0_and_100,
                "product": number_between_0_and_100,
                "traction": number_between_0_and_100,
                "financials": number_between_0_and_100
              },
              "strengths": ["strength1", "strength2"],
              "weaknesses": ["weakness1", "weakness2"],
              "investmentThesis": "why invest or not invest",
              "comparableCompanies": ["company1", "company2"],
              "riskAssessment": "detailed risk analysis",
              "investmentRecommendation": "strong_buy|buy|hold|pass"
            }`
          },
          {
            role: "user",
            content: `Startup: ${startupData.name} in ${startupData.industry}. Description: ${startupData.description}. Team size: ${startupData.teamSize || 'unknown'}. Valuation: $${startupData.valuation}. Traction: ${startupData.traction || 'early stage'}. Market context: ${JSON.stringify(marketContext)}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating startup scoring:", error);
      throw new Error("Failed to generate startup scoring");
    }
  }

  async predictFundingTrends(historicalData: any[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Predict funding trends based on historical data and current market conditions. Return JSON in this format: {
              "predictions": [
                {
                  "timeframe": "next_quarter|next_6_months|next_year",
                  "fundingVolume": "predicted volume trend",
                  "hotSectors": ["sector1", "sector2"],
                  "averageValuations": "valuation trend",
                  "confidenceLevel": number_between_0_and_100
                }
              ],
              "emergingOpportunities": ["opportunity1", "opportunity2"],
              "decliningAreas": ["area1", "area2"],
              "blackSwanRisks": ["risk1", "risk2"],
              "actionableInsights": ["insight1", "insight2"]
            }`
          },
          {
            role: "user",
            content: `Historical funding data: ${JSON.stringify(historicalData)}. Predict future trends.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error predicting funding trends:", error);
      throw new Error("Failed to predict funding trends");
    }
  }

  async generateCompetitiveAnalysis(startupId: number, competitors: string[]) {
    try {
      const startup = await storage.getStartup(startupId);
      if (!startup) {
        throw new Error("Startup not found");
      }

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze competitive landscape and positioning. Return JSON in this format: {
              "competitivePosition": "leader|challenger|follower|niche",
              "marketShare": "estimated market position",
              "differentiators": ["differentiator1", "differentiator2"],
              "competitorAnalysis": [
                {
                  "competitor": "company_name",
                  "strengths": ["strength1", "strength2"],
                  "weaknesses": ["weakness1", "weakness2"],
                  "marketPosition": "position assessment",
                  "threatLevel": "high|medium|low"
                }
              ],
              "whitespace": ["opportunity1", "opportunity2"],
              "strategicRecommendations": ["recommendation1", "recommendation2"]
            }`
          },
          {
            role: "user",
            content: `Analyze ${startup.name} in ${startup.industry}. Description: ${startup.description}. Competitors: ${competitors.join(', ')}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating competitive analysis:", error);
      throw new Error("Failed to generate competitive analysis");
    }
  }

  async calculatePortfolioMetrics(investorId: string) {
    try {
      const investments = await storage.getUserCampaignInvestments(investorId);
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Calculate comprehensive portfolio metrics and performance analysis. Return JSON in this format: {
              "portfolioValue": number,
              "totalInvested": number,
              "unrealizedGains": number,
              "irr": number,
              "multipleOnInvested": number,
              "portfolioComposition": [
                {
                  "sector": "sector_name",
                  "allocation": "percentage",
                  "performance": "performance_metric"
                }
              ],
              "topPerformers": ["company1", "company2"],
              "underPerformers": ["company1", "company2"],
              "riskMetrics": {
                "concentration": "portfolio concentration level",
                "sectoral_risk": "sector diversification risk",
                "stage_risk": "investment stage risk"
              },
              "recommendations": ["recommendation1", "recommendation2"]
            }`
          },
          {
            role: "user",
            content: `Portfolio investments: ${JSON.stringify(investments)}. Calculate performance metrics.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error calculating portfolio metrics:", error);
      throw new Error("Failed to calculate portfolio metrics");
    }
  }

  async generateDealFlowInsights(dealData: any[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze deal flow patterns and quality metrics. Return JSON in this format: {
              "dealFlowMetrics": {
                "volumeTrend": "increasing|decreasing|stable",
                "qualityScore": number_between_0_and_100,
                "conversionRate": "percentage",
                "averageTimeToClose": "days"
              },
              "sourceAnalysis": [
                {
                  "source": "deal source",
                  "volume": "number of deals",
                  "quality": "quality assessment",
                  "conversionRate": "percentage"
                }
              ],
              "hotDeals": [
                {
                  "dealName": "startup name",
                  "attractiveness": "why it's hot",
                  "urgency": "timeline pressure"
                }
              ],
              "pipelineHealth": "healthy|concerning|critical",
              "recommendations": ["action1", "action2"]
            }`
          },
          {
            role: "user",
            content: `Deal flow data: ${JSON.stringify(dealData)}. Analyze patterns and quality.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating deal flow insights:", error);
      throw new Error("Failed to generate deal flow insights");
    }
  }

  async generateAlerts(userId: string, alertPreferences: any) {
    try {
      const userInvestments = await storage.getUserCampaignInvestments(userId);
      const activeCampaigns = await storage.getActiveFundraisingCampaigns();

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Generate personalized investment alerts based on user preferences and market conditions. Return JSON in this format: {
              "urgentAlerts": [
                {
                  "type": "funding_deadline|valuation_change|new_opportunity",
                  "message": "alert message",
                  "action": "recommended action",
                  "deadline": "time sensitive deadline"
                }
              ],
              "opportunityAlerts": [
                {
                  "opportunity": "investment opportunity",
                  "reasoning": "why this matches user interests",
                  "riskLevel": "high|medium|low"
                }
              ],
              "portfolioAlerts": [
                {
                  "company": "portfolio company",
                  "update": "what changed",
                  "impact": "positive|negative|neutral"
                }
              ],
              "marketAlerts": [
                {
                  "trend": "market trend",
                  "relevance": "how it affects user",
                  "timeframe": "when to act"
                }
              ]
            }`
          },
          {
            role: "user",
            content: `User preferences: ${JSON.stringify(alertPreferences)}. Current investments: ${userInvestments.length}. Active opportunities: ${activeCampaigns.length}.`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error("Error generating alerts:", error);
      throw new Error("Failed to generate alerts");
    }
  }
}

export const investorPulseDashboard = new InvestorPulseDashboard();