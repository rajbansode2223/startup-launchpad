import OpenAI from "openai";
import { fallbackAssistant } from "./fallbackAssistant";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface AssistantContext {
  userRole: "founder" | "investor";
  userStartups?: any[];
  userInvestments?: any[];
  currentPage?: string;
  previousMessages?: Array<{role: string, content: string}>;
}

export class VirtualAssistant {
  private getSystemPrompt(context: AssistantContext): string {
    const { userRole, userStartups = [], userInvestments = [], currentPage } = context;
    
    const basePrompt = `You are LaunchPad AI, a helpful virtual assistant for the LaunchPad startup funding simulation platform. You help users navigate the platform, make informed decisions, and achieve their goals.

PLATFORM CONTEXT:
- LaunchPad is a startup funding simulation where users can be founders or investors
- Founders create startups, pitch ideas, and raise funding
- Investors review startups, analyze opportunities, and make investments
- The platform includes pitch rooms, messaging, leaderboards, and comprehensive analytics

USER CONTEXT:
- User Role: ${userRole}
- Current Page: ${currentPage || "dashboard"}
- User has ${userStartups.length} startup(s)
- User has ${userInvestments.length} investment(s)

PERSONALITY & TONE:
- Be friendly, professional, and encouraging
- Provide actionable, specific advice
- Keep responses concise but comprehensive
- Use startup and investment terminology appropriately
- Be optimistic about opportunities while being realistic about challenges

CAPABILITIES:
- Platform navigation guidance
- Startup creation and optimization advice  
- Investment analysis and recommendations
- Business strategy insights
- Market research and industry trends
- Pitch deck feedback and suggestions
- Funding round strategy
- Networking and communication tips`;

    if (userRole === "founder") {
      return basePrompt + `

FOUNDER-SPECIFIC GUIDANCE:
- Help with startup ideation and validation
- Business model development and refinement
- Pitch deck creation and optimization
- Funding strategy and round planning
- Investor relations and communication
- Growth planning and scaling advice
- Market positioning and competitive analysis
- Financial projections and valuation guidance`;
    } else {
      return basePrompt + `

INVESTOR-SPECIFIC GUIDANCE:
- Startup evaluation and due diligence
- Investment opportunity analysis
- Portfolio diversification strategies
- Risk assessment and mitigation
- Market trend analysis and opportunities
- Founder and team evaluation criteria
- Financial analysis and projections review
- Exit strategy considerations`;
    }
  }

  async getChatResponse(
    message: string, 
    context: AssistantContext
  ): Promise<string> {
    try {
      const systemPrompt = this.getSystemPrompt(context);
      const previousMessages = context.previousMessages || [];
      
      const messages = [
        { role: "system", content: systemPrompt },
        ...previousMessages.slice(-6), // Keep last 6 messages for context
        { role: "user", content: message }
      ];

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: messages as any,
        max_tokens: 500,
        temperature: 0.7,
      });

      return response.choices[0].message.content || "I apologize, but I couldn't process your request. Please try again.";
    } catch (error) {
      console.error("AI Assistant Error:", error);
      // Fall back to knowledge-based responses when API quota is exceeded
      return fallbackAssistant.getChatResponse(message, context);
    }
  }

  async analyzeStartup(startupData: any): Promise<string> {
    try {
      const analysisPrompt = `Analyze this startup and provide constructive feedback:

Startup: ${startupData.name}
Description: ${startupData.description}
Vision: ${startupData.vision}
Business Model: ${startupData.businessModel}
Market Size: ${startupData.marketSize}
Industry: ${startupData.industry}
Stage: ${startupData.stage}
Valuation: $${startupData.valuation}

Provide:
1. Strengths and opportunities
2. Areas for improvement
3. Market positioning insights
4. Funding readiness assessment
5. Next steps recommendations

Keep the analysis concise but actionable.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: analysisPrompt }],
        max_tokens: 600,
        temperature: 0.6,
      });

      return response.choices[0].message.content || "Unable to analyze startup at this time.";
    } catch (error) {
      console.error("Startup Analysis Error:", error);
      return fallbackAssistant.analyzeStartup(startupData);
    }
  }

  async analyzeInvestmentOpportunity(
    startupData: any, 
    fundingRound: any, 
    marketContext: string = ""
  ): Promise<string> {
    try {
      const analysisPrompt = `Analyze this investment opportunity:

STARTUP:
- Name: ${startupData.name}
- Industry: ${startupData.industry}
- Stage: ${startupData.stage}
- Current Valuation: $${startupData.valuation}
- Description: ${startupData.description}
- Business Model: ${startupData.businessModel}

FUNDING ROUND:
- Round Name: ${fundingRound.name}
- Target Amount: $${fundingRound.targetAmount}
- Equity Offered: ${fundingRound.equityOffered}%
- Minimum Investment: $${fundingRound.minimumInvestment}
- Current Progress: $${fundingRound.raisedAmount}/${fundingRound.targetAmount}

${marketContext ? `MARKET CONTEXT: ${marketContext}` : ''}

Provide investment analysis:
1. Investment thesis and opportunity assessment
2. Risk factors and mitigation strategies  
3. Market potential and competitive positioning
4. Financial projections and returns analysis
5. Recommendation (invest/pass/monitor) with reasoning

Be objective and analytical.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: analysisPrompt }],
        max_tokens: 700,
        temperature: 0.5,
      });

      return response.choices[0].message.content || "Unable to analyze investment opportunity at this time.";
    } catch (error) {
      console.error("Investment Analysis Error:", error);
      return fallbackAssistant.analyzeInvestmentOpportunity(startupData, fundingRound);
    }
  }

  async generateBusinessIdeas(industry: string, interests: string[]): Promise<string[]> {
    try {
      const prompt = `Generate 5 innovative startup ideas for the ${industry} industry. Consider these interests/trends: ${interests.join(", ")}.

For each idea, provide:
- Name
- One-sentence description
- Key value proposition

Format as a simple list.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        max_tokens: 400,
        temperature: 0.8,
      });

      const content = response.choices[0].message.content || "";
      return content.split('\n').filter(line => line.trim().length > 0);
    } catch (error) {
      console.error("Business Ideas Generation Error:", error);
      return fallbackAssistant.generateBusinessIdeas(industry, interests);
    }
  }
}

export const virtualAssistant = new VirtualAssistant();