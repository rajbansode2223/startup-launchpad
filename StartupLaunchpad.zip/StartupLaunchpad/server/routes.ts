import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import path from "path";
import session from "express-session";
import { storage } from "./storage_fixed";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { virtualAssistant } from "./aiAssistant";
import { fallbackAssistant } from "./fallbackAssistant";
import { aiCofounderAssistant } from "./aiCofounderAssistant";
import { leanValidationEngine } from "./leanValidationEngine";
import { investorPulseDashboard } from "./investorPulseDashboard";
import { growthStack } from "./growthStack";
import {
  insertStartupSchema,
  insertFundingRoundSchema,
  insertInvestmentSchema,
  insertPitchRoomSchema,
  insertMessageSchema,
  insertRatingSchema,
  insertCofounderProfileSchema,
  insertCofounderMatchSchema,
  insertCofounderConnectionSchema,
  insertFundraisingCampaignSchema,
  insertCampaignInvestmentSchema,
  insertCampaignMilestoneSchema,
  insertCampaignUpdateSchema,
  insertInvestorInterestSchema,
  insertUserConnectionSchema,
  insertChatConversationSchema,
  insertChatMessageSchema,
  insertChatNotificationSchema,
} from "@shared/schema";
import { z } from "zod";

// File upload configuration
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware - force development auth for local testing
  if (false && process.env.REPLIT_DOMAINS) {
    await setupAuth(app);
  } else {
    // Simple session configuration for development
    app.use(session({
      secret: process.env.SESSION_SECRET || 'dev-secret-key-12345',
      resave: true,
      saveUninitialized: true,
      name: 'launchpad.sid',
      cookie: {
        httpOnly: true,
        secure: false,
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        sameSite: 'lax'
      }
    }));

    // Development auth middleware - set user directly
    app.use(async (req: any, res, next) => {
      try {
        const devUserId = 'dev-user-123';
        
        // Ensure user exists without overriding existing data
        let existingUser = await storage.getUser(devUserId);
        if (!existingUser) {
          existingUser = await storage.upsertUser({
            id: devUserId,
            email: 'dev@example.com',
            firstName: 'Dev',
            lastName: 'User',
            profileImageUrl: null,
            role: 'founder'
          });
        }
        
        // Set user claims on request (preserve database role)
        req.user = {
          claims: {
            sub: devUserId,
            email: existingUser.email,
            first_name: existingUser.firstName,
            last_name: existingUser.lastName,
            profile_image_url: existingUser.profileImageUrl
          }
        };
        
        req.isAuthenticated = () => true;
        next();
      } catch (error) {
        console.error('Development auth middleware error:', error);
        next();
      }
    });
  }

  // Flexible authentication middleware
  const flexAuth = async (req: any, res: any, next: any) => {
    try {
      // Check if user is authenticated
      if (req.user?.claims?.sub) {
        return next();
      }
      
      return res.status(401).json({ message: "Unauthorized" });
    } catch (error) {
      console.error("Auth middleware error:", error);
      return res.status(401).json({ message: "Unauthorized" });
    }
  };

  // Update user role
  app.post('/api/auth/role', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { role } = req.body;
      
      if (!role || !['founder', 'investor'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const updatedUser = await storage.updateUserRole(userId, role);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Debug route to check session (public)
  app.get('/api/debug/session', (req: any, res) => {
    res.json({
      isAuthenticated: req.isAuthenticated(),
      hasUser: !!req.user,
      sessionExists: !!req.session,
      headers: req.headers,
      cookies: req.cookies
    });
  });

  // Test public route
  app.get('/api/test', (req, res) => {
    res.json({ message: "Backend is working", timestamp: new Date().toISOString() });
  });

  // Development authentication helper
  app.post('/api/auth/dev-login', async (req, res) => {
    try {
      const { role = 'founder', email = 'user@example.com' } = req.body;
      
      // Generate unique user ID based on email
      const userId = `user-${Buffer.from(email).toString('base64').slice(0, 8)}`;
      
      const user = await storage.upsertUser({
        id: userId,
        email: email,
        firstName: email.split('@')[0],
        lastName: 'User',
        profileImageUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
        role: role as 'founder' | 'investor'
      });

      // Create session for development
      req.session = req.session || {};
      (req.session as any).user = {
        claims: {
          sub: user.id,
          email: user.email,
          first_name: user.firstName,
          last_name: user.lastName,
          profile_image_url: user.profileImageUrl
        },
        expires_at: Math.floor(Date.now() / 1000) + 86400 // 24 hours
      };

      res.json(user);
    } catch (error) {
      console.error('Development login error:', error);
      res.status(500).json({ message: 'Failed to create development session' });
    }
  });

  // Updated auth endpoint that works with both auth methods
  app.get('/api/auth/user', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User role update
  app.patch('/api/auth/user/role', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { role } = req.body;
      
      if (!role || !["founder", "investor"].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const user = await storage.upsertUser({
        id: userId,
        email: req.user.claims.email,
        firstName: req.user.claims.first_name,
        lastName: req.user.claims.last_name,
        profileImageUrl: req.user.claims.profile_image_url,
        role,
      });

      res.json(user);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Startup routes
  app.post('/api/startups', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== "founder") {
        return res.status(403).json({ message: "Only founders can create startups" });
      }

      const startupData = insertStartupSchema.parse({
        ...req.body,
        founderId: userId,
      });

      const startup = await storage.createStartup(startupData);
      res.json(startup);
    } catch (error) {
      console.error("Error creating startup:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid startup data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create startup" });
    }
  });

  app.get('/api/startups', async (req, res) => {
    try {
      const startups = await storage.getAllStartups();
      res.json(startups);
    } catch (error) {
      console.error("Error fetching startups:", error);
      res.status(500).json({ message: "Failed to fetch startups" });
    }
  });

  app.get('/api/startups/my', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const startups = await storage.getStartupsByFounder(userId);
      res.json(startups);
    } catch (error) {
      console.error("Error fetching user startups:", error);
      res.status(500).json({ message: "Failed to fetch user startups" });
    }
  });

  app.get('/api/startups/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const startup = await storage.getStartup(id);
      if (!startup) {
        return res.status(404).json({ message: "Startup not found" });
      }
      res.json(startup);
    } catch (error) {
      console.error("Error fetching startup:", error);
      res.status(500).json({ message: "Failed to fetch startup" });
    }
  });

  // File upload for pitch decks
  app.post('/api/startups/:id/pitch-deck', flexAuth, upload.single('pitchDeck'), async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const startup = await storage.getStartup(id);
      if (!startup) {
        return res.status(404).json({ message: "Startup not found" });
      }
      
      if (startup.founderId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this startup" });
      }

      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const pitchDeckUrl = `/uploads/${req.file.filename}`;
      const updatedStartup = await storage.updateStartup(id, { pitchDeckUrl });
      
      res.json({ pitchDeckUrl: updatedStartup.pitchDeckUrl });
    } catch (error) {
      console.error("Error uploading pitch deck:", error);
      res.status(500).json({ message: "Failed to upload pitch deck" });
    }
  });

  // Funding round routes
  app.post('/api/funding-rounds', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const roundData = insertFundingRoundSchema.parse(req.body);
      
      // Check if user owns the startup
      const startup = await storage.getStartup(roundData.startupId);
      if (!startup || startup.founderId !== userId) {
        return res.status(403).json({ message: "Not authorized to create funding round for this startup" });
      }

      const round = await storage.createFundingRound(roundData);
      res.json(round);
    } catch (error) {
      console.error("Error creating funding round:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid funding round data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create funding round" });
    }
  });

  app.get('/api/funding-rounds/active', async (req, res) => {
    try {
      const rounds = await storage.getActiveFundingRounds();
      res.json(rounds);
    } catch (error) {
      console.error("Error fetching active funding rounds:", error);
      res.status(500).json({ message: "Failed to fetch active funding rounds" });
    }
  });

  app.patch('/api/funding-rounds/:id', flexAuth, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const round = await storage.getFundingRound(id);
      if (!round) {
        return res.status(404).json({ message: "Funding round not found" });
      }
      
      const startup = await storage.getStartup(round.startupId);
      if (!startup || startup.founderId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this funding round" });
      }

      const updatedRound = await storage.updateFundingRound(id, req.body);
      res.json(updatedRound);
    } catch (error) {
      console.error("Error updating funding round:", error);
      res.status(500).json({ message: "Failed to update funding round" });
    }
  });

  app.get('/api/startups/:id/funding-rounds', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const rounds = await storage.getFundingRoundsByStartup(id);
      res.json(rounds);
    } catch (error) {
      console.error("Error fetching funding rounds:", error);
      res.status(500).json({ message: "Failed to fetch funding rounds" });
    }
  });

  // Investment routes
  app.post('/api/investments', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== "investor") {
        return res.status(403).json({ message: "Only investors can make investments" });
      }

      const investmentData = insertInvestmentSchema.parse({
        ...req.body,
        investorId: userId,
      });

      const investment = await storage.createInvestment(investmentData);
      res.json(investment);
    } catch (error) {
      console.error("Error creating investment:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid investment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create investment" });
    }
  });

  app.get('/api/investments/my', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investments = await storage.getInvestmentsByInvestor(userId);
      res.json(investments);
    } catch (error) {
      console.error("Error fetching user investments:", error);
      res.status(500).json({ message: "Failed to fetch user investments" });
    }
  });

  // Investor portfolio stats endpoint
  app.get('/api/investors/portfolio-stats', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investments = await storage.getInvestmentsByInvestor(userId);
      
      // Calculate portfolio statistics
      const totalInvested = investments.reduce((sum: number, inv: any) => sum + (parseFloat(inv.amount) || 0), 0);
      const totalStartups = investments.length;
      const activeInvestments = investments.filter((inv: any) => inv.status === 'active').length;
      
      // Mock portfolio growth calculation (in a real app, this would come from actual startup valuations)
      const portfolioValue = totalInvested * 1.25; // 25% assumed growth
      const totalReturn = portfolioValue - totalInvested;
      const returnPercentage = totalInvested > 0 ? (totalReturn / totalInvested) * 100 : 0;
      
      res.json({
        totalInvested,
        portfolioValue,
        totalReturn,
        returnPercentage,
        totalStartups,
        activeInvestments,
        investments: investments.slice(0, 5) // Latest 5 investments for dashboard
      });
    } catch (error) {
      console.error("Error fetching portfolio stats:", error);
      res.status(500).json({ message: "Failed to fetch portfolio stats" });
    }
  });

  // Pitch room routes
  app.post('/api/pitch-rooms', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      // Create pitch room data without schema validation
      const roomData = {
        startupId: req.body.startupId,
        name: req.body.name,
        description: req.body.description || '',
        scheduledAt: req.body.scheduledAt ? new Date(req.body.scheduledAt) : new Date(),
        status: 'scheduled' as const,
        maxDuration: req.body.maxDuration || 3600
      };
      
      // Check if user owns the startup
      const startup = await storage.getStartup(roomData.startupId);
      if (!startup || startup.founderId !== userId) {
        return res.status(403).json({ message: "Not authorized to create pitch room for this startup" });
      }

      const room = await storage.createPitchRoom(roomData);
      res.json(room);
    } catch (error) {
      console.error("Error creating pitch room:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid pitch room data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create pitch room" });
    }
  });

  app.get('/api/pitch-rooms/active', async (req, res) => {
    try {
      const rooms = await storage.getActivePitchRooms();
      res.json(rooms);
    } catch (error) {
      console.error("Error fetching active pitch rooms:", error);
      res.status(500).json({ message: "Failed to fetch active pitch rooms" });
    }
  });

  app.post('/api/pitch-rooms/:id/join', flexAuth, async (req: any, res) => {
    try {
      const roomId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      await storage.joinPitchRoom(roomId, userId);
      res.json({ message: "Joined pitch room successfully" });
    } catch (error) {
      console.error("Error joining pitch room:", error);
      res.status(500).json({ message: "Failed to join pitch room" });
    }
  });

  // Message routes
  app.post('/api/messages', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messageData = insertMessageSchema.parse({
        ...req.body,
        senderId: userId,
      });

      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  app.get('/api/messages/direct/:userId', flexAuth, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const otherUserId = req.params.userId;
      
      const messages = await storage.getDirectMessages(currentUserId, otherUserId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching direct messages:", error);
      res.status(500).json({ message: "Failed to fetch direct messages" });
    }
  });

  app.get('/api/messages/my', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messages = await storage.getUserMessages(userId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching user messages:", error);
      res.status(500).json({ message: "Failed to fetch user messages" });
    }
  });

  // Rating routes
  app.post('/api/ratings', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== "investor") {
        return res.status(403).json({ message: "Only investors can rate startups" });
      }

      const ratingData = insertRatingSchema.parse({
        ...req.body,
        investorId: userId,
      });

      const rating = await storage.createRating(ratingData);
      res.json(rating);
    } catch (error) {
      console.error("Error creating rating:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid rating data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create rating" });
    }
  });

  app.get('/api/startups/:id/ratings', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const ratings = await storage.getRatingsByStartup(id);
      res.json(ratings);
    } catch (error) {
      console.error("Error fetching startup ratings:", error);
      res.status(500).json({ message: "Failed to fetch startup ratings" });
    }
  });

  // Leaderboard routes
  app.get('/api/leaderboard', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const topStartups = await storage.getTopStartups(limit);
      res.json(topStartups);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  // AI Assistant API routes
  app.post('/api/assistant/chat', flexAuth, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const { message, context = {} } = req.body;
    
    if (!message) {
      return res.status(400).json({ message: "Message is required" });
    }

    try {
      // Get user data for context
      const user = await storage.getUser(userId);
      const userStartups = await storage.getStartupsByFounder(userId);
      const userInvestments = await storage.getInvestmentsByInvestor(userId);
      
      const assistantContext = {
        userRole: user?.role || "founder",
        userStartups,
        userInvestments,
        currentPage: context.currentPage,
        previousMessages: context.previousMessages || []
      };

      const response = await virtualAssistant.getChatResponse(message, assistantContext);
      res.json({ response, timestamp: new Date().toISOString() });
    } catch (error) {
      console.error("Assistant chat error:", error);
      // Use fallback assistant if virtual assistant fails
      try {
        const user = await storage.getUser(userId);
        const fallbackContext = {
          userRole: user?.role || "founder",
          userStartups: [],
          userInvestments: [],
          currentPage: context.currentPage
        };
        const fallbackResponse = fallbackAssistant.getChatResponse(message, fallbackContext);
        res.json({ response: fallbackResponse, timestamp: new Date().toISOString() });
      } catch (fallbackError) {
        console.error("Fallback assistant error:", fallbackError);
        res.status(500).json({ message: "Assistant is temporarily unavailable" });
      }
    }
  });

  app.post('/api/assistant/analyze-startup/:id', flexAuth, async (req: any, res) => {
    try {
      const startupId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const startup = await storage.getStartup(startupId);
      if (!startup) {
        return res.status(404).json({ message: "Startup not found" });
      }
      
      // Check if user owns the startup or is an investor
      const user = await storage.getUser(userId);
      if (startup.founderId !== userId && user?.role !== "investor") {
        return res.status(403).json({ message: "Not authorized to analyze this startup" });
      }

      const analysis = await virtualAssistant.analyzeStartup(startup);
      res.json({ analysis, timestamp: new Date().toISOString() });
    } catch (error) {
      console.error("Startup analysis error:", error);
      res.status(500).json({ message: "Failed to analyze startup" });
    }
  });

  app.post('/api/assistant/analyze-investment/:roundId', flexAuth, async (req: any, res) => {
    try {
      const roundId = parseInt(req.params.roundId);
      const userId = req.user.claims.sub;
      
      const user = await storage.getUser(userId);
      if (user?.role !== "investor") {
        return res.status(403).json({ message: "Only investors can request investment analysis" });
      }

      const round = await storage.getFundingRound(roundId);
      if (!round) {
        return res.status(404).json({ message: "Funding round not found" });
      }

      const startup = await storage.getStartup(round.startupId);
      if (!startup) {
        return res.status(404).json({ message: "Startup not found" });
      }

      const { marketContext = "" } = req.body;
      const analysis = await virtualAssistant.analyzeInvestmentOpportunity(startup, round, marketContext);
      res.json({ analysis, timestamp: new Date().toISOString() });
    } catch (error) {
      console.error("Investment analysis error:", error);
      res.status(500).json({ message: "Failed to analyze investment opportunity" });
    }
  });

  app.post('/api/assistant/generate-ideas', flexAuth, async (req: any, res) => {
    try {
      const { industry, interests = [] } = req.body;
      
      if (!industry) {
        return res.status(400).json({ message: "Industry is required" });
      }

      const ideas = await virtualAssistant.generateBusinessIdeas(industry, interests);
      res.json({ ideas, timestamp: new Date().toISOString() });
    } catch (error) {
      console.error("Ideas generation error:", error);
      res.status(500).json({ message: "Failed to generate business ideas" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static('uploads'));

  // Co-founder matchmaking API routes
  app.post('/api/cofounder/profile', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profileData = insertCofounderProfileSchema.parse(req.body);
      
      // Check if profile already exists
      const existingProfile = await storage.getCofounderProfile(userId);
      if (existingProfile) {
        return res.status(400).json({ message: "Profile already exists. Use PUT to update." });
      }
      
      const profile = await storage.createCofounderProfile({
        ...profileData,
        userId
      });
      
      res.status(201).json(profile);
    } catch (error) {
      console.error("Create cofounder profile error:", error);
      res.status(500).json({ message: "Failed to create profile" });
    }
  });

  app.get('/api/cofounder/profile', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getCofounderProfile(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      console.error("Get cofounder profile error:", error);
      res.status(500).json({ message: "Failed to get profile" });
    }
  });

  app.put('/api/cofounder/profile', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updates = insertCofounderProfileSchema.partial().parse(req.body);
      
      const profile = await storage.updateCofounderProfile(userId, updates);
      res.json(profile);
    } catch (error) {
      console.error("Update cofounder profile error:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.delete('/api/cofounder/profile', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.deleteCofounderProfile(userId);
      res.status(204).send();
    } catch (error) {
      console.error("Delete cofounder profile error:", error);
      res.status(500).json({ message: "Failed to delete profile" });
    }
  });

  app.get('/api/cofounder/search', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { skills, industries, experience, commitment, location, remoteOk, limit } = req.query;
      
      const filters = {
        skills: skills ? String(skills).split(',') : undefined,
        industries: industries ? String(industries).split(',') : undefined,
        experience: experience ? String(experience) : undefined,
        commitment: commitment ? String(commitment) : undefined,
        location: location ? String(location) : undefined,
        remoteOk: remoteOk === 'true',
        limit: limit ? parseInt(String(limit)) : 20,
        excludeUserId: userId
      };
      
      const profiles = await storage.searchCofounderProfiles(filters);
      res.json(profiles);
    } catch (error) {
      console.error("Search cofounder profiles error:", error);
      res.status(500).json({ message: "Failed to search profiles" });
    }
  });

  app.post('/api/cofounder/match', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { targetId, message } = req.body;
      
      if (!targetId) {
        return res.status(400).json({ message: "Target user ID is required" });
      }
      
      // Check if match already exists
      const existingMatch = await storage.getMatchBetweenUsers(userId, targetId);
      if (existingMatch) {
        return res.status(400).json({ message: "Match request already exists" });
      }
      
      const match = await storage.createCofounderMatch({
        requesterId: userId,
        targetId,
        status: "pending",
        message: message || null
      });
      
      res.status(201).json(match);
    } catch (error) {
      console.error("Create cofounder match error:", error);
      res.status(500).json({ message: "Failed to create match request" });
    }
  });

  app.get('/api/cofounder/matches', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { status } = req.query;
      
      const matches = await storage.getCofounderMatches(userId, status ? String(status) : undefined);
      res.json(matches);
    } catch (error) {
      console.error("Get cofounder matches error:", error);
      res.status(500).json({ message: "Failed to get matches" });
    }
  });

  app.put('/api/cofounder/match/:id', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const matchId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!["accepted", "declined", "connected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const match = await storage.updateCofounderMatch(matchId, { status });
      
      // Create connection if accepted
      if (status === "accepted") {
        await storage.createCofounderConnection({
          user1Id: match.requesterId,
          user2Id: match.targetId,
          connectionType: "matched"
        });
      }
      
      res.json(match);
    } catch (error) {
      console.error("Update cofounder match error:", error);
      res.status(500).json({ message: "Failed to update match" });
    }
  });

  app.get('/api/cofounder/connections', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const connections = await storage.getCofounderConnections(userId);
      res.json(connections);
    } catch (error) {
      console.error("Get cofounder connections error:", error);
      res.status(500).json({ message: "Failed to get connections" });
    }
  });

  // Fundraising campaigns API
  app.post("/api/fundraising/campaigns", flexAuth, async (req: any, res) => {
    try {
      const validated = insertFundraisingCampaignSchema.parse(req.body);
      const campaign = await storage.createFundraisingCampaign(validated);
      res.json(campaign);
    } catch (error) {
      console.error("Error creating fundraising campaign:", error);
      res.status(500).json({ message: "Failed to create campaign" });
    }
  });

  app.get("/api/fundraising/campaigns", async (req, res) => {
    try {
      const campaigns = await storage.getActiveFundraisingCampaigns();
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.get("/api/fundraising/campaigns/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const campaign = await storage.getFundraisingCampaign(id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      res.json(campaign);
    } catch (error) {
      console.error("Error fetching campaign:", error);
      res.status(500).json({ message: "Failed to fetch campaign" });
    }
  });

  app.patch("/api/fundraising/campaigns/:id", flexAuth, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const campaign = await storage.updateFundraisingCampaign(id, updates);
      res.json(campaign);
    } catch (error) {
      console.error("Error updating campaign:", error);
      res.status(500).json({ message: "Failed to update campaign" });
    }
  });

  // Campaign investments API
  app.post("/api/fundraising/campaigns/:id/invest", flexAuth, async (req: any, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const validated = insertCampaignInvestmentSchema.parse({
        ...req.body,
        campaignId,
        investorId: userId,
      });
      
      const investment = await storage.createCampaignInvestment(validated);
      
      // Update campaign raised amount
      const campaign = await storage.getFundraisingCampaign(campaignId);
      if (campaign) {
        const newRaisedAmount = (parseFloat(campaign.raisedAmount) + parseFloat(validated.amount)).toString();
        await storage.updateCampaignRaisedAmount(campaignId, newRaisedAmount);
      }
      
      res.json(investment);
    } catch (error) {
      console.error("Error creating investment:", error);
      res.status(500).json({ message: "Failed to create investment" });
    }
  });

  app.get("/api/fundraising/campaigns/:id/investments", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const investments = await storage.getCampaignInvestments(campaignId);
      res.json(investments);
    } catch (error) {
      console.error("Error fetching investments:", error);
      res.status(500).json({ message: "Failed to fetch investments" });
    }
  });

  app.get("/api/fundraising/my-investments", flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investments = await storage.getUserCampaignInvestments(userId);
      res.json(investments);
    } catch (error) {
      console.error("Error fetching user investments:", error);
      res.status(500).json({ message: "Failed to fetch investments" });
    }
  });

  // Campaign milestones API
  app.post("/api/fundraising/campaigns/:id/milestones", flexAuth, async (req: any, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const validated = insertCampaignMilestoneSchema.parse({
        ...req.body,
        campaignId,
      });
      
      const milestone = await storage.createCampaignMilestone(validated);
      res.json(milestone);
    } catch (error) {
      console.error("Error creating milestone:", error);
      res.status(500).json({ message: "Failed to create milestone" });
    }
  });

  app.get("/api/fundraising/campaigns/:id/milestones", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const milestones = await storage.getCampaignMilestones(campaignId);
      res.json(milestones);
    } catch (error) {
      console.error("Error fetching milestones:", error);
      res.status(500).json({ message: "Failed to fetch milestones" });
    }
  });

  // Campaign updates API
  app.post("/api/fundraising/campaigns/:id/updates", flexAuth, async (req: any, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const validated = insertCampaignUpdateSchema.parse({
        ...req.body,
        campaignId,
      });
      
      const update = await storage.createCampaignUpdate(validated);
      res.json(update);
    } catch (error) {
      console.error("Error creating update:", error);
      res.status(500).json({ message: "Failed to create update" });
    }
  });

  app.get("/api/fundraising/campaigns/:id/updates", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const visibility = req.query.visibility as string;
      const updates = await storage.getCampaignUpdates(campaignId, visibility);
      res.json(updates);
    } catch (error) {
      console.error("Error fetching updates:", error);
      res.status(500).json({ message: "Failed to fetch updates" });
    }
  });

  // Investor interests API
  app.post("/api/fundraising/campaigns/:id/interest", flexAuth, async (req: any, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const validated = insertInvestorInterestSchema.parse({
        ...req.body,
        campaignId,
        investorId: userId,
      });
      
      // Check if interest already exists
      const existingInterest = await storage.getInvestorInterest(campaignId, userId);
      
      let interest;
      if (existingInterest) {
        interest = await storage.updateInvestorInterest(campaignId, userId, validated);
      } else {
        interest = await storage.createInvestorInterest(validated);
      }
      
      res.json(interest);
    } catch (error) {
      console.error("Error managing interest:", error);
      res.status(500).json({ message: "Failed to manage interest" });
    }
  });

  app.get("/api/fundraising/campaigns/:id/interests", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const interests = await storage.getCampaignInterests(campaignId);
      res.json(interests);
    } catch (error) {
      console.error("Error fetching interests:", error);
      res.status(500).json({ message: "Failed to fetch interests" });
    }
  });

  // AI Co-Founder Assistant API
  app.post("/api/ai/cofounder/profile-recommendations", flexAuth, async (req: any, res) => {
    try {
      const { skills, industry, experience } = req.body;
      const recommendations = await aiCofounderAssistant.generateCofounderProfile(skills, industry, experience);
      res.json(recommendations);
    } catch (error) {
      console.error("Error generating co-founder recommendations:", error);
      res.status(500).json({ message: "Failed to generate recommendations" });
    }
  });

  app.post("/api/ai/cofounder/compatibility", flexAuth, async (req: any, res) => {
    try {
      const { profile1, profile2 } = req.body;
      const compatibility = await aiCofounderAssistant.analyzeCofounderCompatibility(profile1, profile2);
      res.json(compatibility);
    } catch (error) {
      console.error("Error analyzing compatibility:", error);
      res.status(500).json({ message: "Failed to analyze compatibility" });
    }
  });

  app.post("/api/ai/cofounder/startup-advice", flexAuth, async (req: any, res) => {
    try {
      const { startupData, userRole } = req.body;
      const advice = await aiCofounderAssistant.generateStartupAdvice(startupData, userRole);
      res.json(advice);
    } catch (error) {
      console.error("Error generating startup advice:", error);
      res.status(500).json({ message: "Failed to generate advice" });
    }
  });

  app.post("/api/ai/cofounder/team-dynamics", flexAuth, async (req: any, res) => {
    try {
      const { teamMembers } = req.body;
      const analysis = await aiCofounderAssistant.assessTeamDynamics(teamMembers);
      res.json(analysis);
    } catch (error) {
      console.error("Error assessing team dynamics:", error);
      res.status(500).json({ message: "Failed to assess team dynamics" });
    }
  });

  app.post("/api/ai/cofounder/equity-split", flexAuth, async (req: any, res) => {
    try {
      const { founders, startupStage } = req.body;
      const recommendations = await aiCofounderAssistant.generateEquitySplitRecommendation(founders, startupStage);
      res.json(recommendations);
    } catch (error) {
      console.error("Error generating equity recommendations:", error);
      res.status(500).json({ message: "Failed to generate equity recommendations" });
    }
  });

  // Lean Validation Engine API
  app.post("/api/ai/validation/framework", flexAuth, async (req: any, res) => {
    try {
      const { startupIdea, targetMarket, industry } = req.body;
      const framework = await leanValidationEngine.generateValidationFramework(startupIdea, targetMarket, industry);
      res.json(framework);
    } catch (error) {
      console.error("Error generating validation framework:", error);
      res.status(500).json({ message: "Failed to generate validation framework" });
    }
  });

  app.post("/api/ai/validation/experiment-analysis", flexAuth, async (req: any, res) => {
    try {
      const { experimentData } = req.body;
      const analysis = await leanValidationEngine.analyzeExperimentResults(experimentData);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing experiment results:", error);
      res.status(500).json({ message: "Failed to analyze experiment results" });
    }
  });

  app.post("/api/ai/validation/customer-personas", flexAuth, async (req: any, res) => {
    try {
      const { validationData } = req.body;
      const personas = await leanValidationEngine.generateCustomerPersonas(validationData);
      res.json(personas);
    } catch (error) {
      console.error("Error generating customer personas:", error);
      res.status(500).json({ message: "Failed to generate customer personas" });
    }
  });

  app.post("/api/ai/validation/product-market-fit", flexAuth, async (req: any, res) => {
    try {
      const { metrics } = req.body;
      const assessment = await leanValidationEngine.assessProductMarketFit(metrics);
      res.json(assessment);
    } catch (error) {
      console.error("Error assessing product-market fit:", error);
      res.status(500).json({ message: "Failed to assess product-market fit" });
    }
  });

  app.post("/api/ai/validation/experiments", flexAuth, async (req: any, res) => {
    try {
      const { currentStage, validatedHypotheses, pendingHypotheses } = req.body;
      const experiments = await leanValidationEngine.recommendExperiments(currentStage, validatedHypotheses, pendingHypotheses);
      res.json(experiments);
    } catch (error) {
      console.error("Error recommending experiments:", error);
      res.status(500).json({ message: "Failed to recommend experiments" });
    }
  });

  // Investor Pulse Dashboard API
  app.get("/api/ai/investor/market-insights", flexAuth, async (req: any, res) => {
    try {
      const { timeframe = "30d", sectors = [] } = req.query;
      const insights = await investorPulseDashboard.generateMarketInsights(timeframe, sectors);
      res.json(insights);
    } catch (error) {
      console.error("Error generating market insights:", error);
      res.status(500).json({ message: "Failed to generate market insights" });
    }
  });

  app.post("/api/ai/investor/startup-scoring", flexAuth, async (req: any, res) => {
    try {
      const { startupData, marketContext } = req.body;
      const scoring = await investorPulseDashboard.generateStartupScoring(startupData, marketContext);
      res.json(scoring);
    } catch (error) {
      console.error("Error generating startup scoring:", error);
      res.status(500).json({ message: "Failed to generate startup scoring" });
    }
  });

  app.post("/api/ai/investor/competitive-analysis/:startupId", flexAuth, async (req: any, res) => {
    try {
      const startupId = parseInt(req.params.startupId);
      const { competitors } = req.body;
      const analysis = await investorPulseDashboard.generateCompetitiveAnalysis(startupId, competitors);
      res.json(analysis);
    } catch (error) {
      console.error("Error generating competitive analysis:", error);
      res.status(500).json({ message: "Failed to generate competitive analysis" });
    }
  });

  app.get("/api/ai/investor/portfolio-metrics", flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const metrics = await investorPulseDashboard.calculatePortfolioMetrics(userId);
      res.json(metrics);
    } catch (error) {
      console.error("Error calculating portfolio metrics:", error);
      res.status(500).json({ message: "Failed to calculate portfolio metrics" });
    }
  });

  app.post("/api/ai/investor/alerts", flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { alertPreferences } = req.body;
      const alerts = await investorPulseDashboard.generateAlerts(userId, alertPreferences);
      res.json(alerts);
    } catch (error) {
      console.error("Error generating alerts:", error);
      res.status(500).json({ message: "Failed to generate alerts" });
    }
  });

  // Growth Stack API
  app.post("/api/ai/growth/strategy", flexAuth, async (req: any, res) => {
    try {
      const { startupData, currentMetrics, targetMarket } = req.body;
      const strategy = await growthStack.generateGrowthStrategy(startupData, currentMetrics, targetMarket);
      res.json(strategy);
    } catch (error) {
      console.error("Error generating growth strategy:", error);
      res.status(500).json({ message: "Failed to generate growth strategy" });
    }
  });

  app.post("/api/ai/growth/funnel-optimization", flexAuth, async (req: any, res) => {
    try {
      const { funnelData } = req.body;
      const optimization = await growthStack.optimizeConversionFunnel(funnelData);
      res.json(optimization);
    } catch (error) {
      console.error("Error optimizing conversion funnel:", error);
      res.status(500).json({ message: "Failed to optimize conversion funnel" });
    }
  });

  app.post("/api/ai/growth/content-strategy", flexAuth, async (req: any, res) => {
    try {
      const { brandVoice, targetAudience, goals } = req.body;
      const strategy = await growthStack.generateContentStrategy(brandVoice, targetAudience, goals);
      res.json(strategy);
    } catch (error) {
      console.error("Error generating content strategy:", error);
      res.status(500).json({ message: "Failed to generate content strategy" });
    }
  });

  app.post("/api/ai/growth/channel-analysis", flexAuth, async (req: any, res) => {
    try {
      const { channelData, budget } = req.body;
      const analysis = await growthStack.analyzeGrowthChannels(channelData, budget);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing growth channels:", error);
      res.status(500).json({ message: "Failed to analyze growth channels" });
    }
  });

  app.post("/api/ai/growth/viral-mechanisms", flexAuth, async (req: any, res) => {
    try {
      const { productType, userBehavior } = req.body;
      const mechanisms = await growthStack.generateViralMechanisms(productType, userBehavior);
      res.json(mechanisms);
    } catch (error) {
      console.error("Error generating viral mechanisms:", error);
      res.status(500).json({ message: "Failed to generate viral mechanisms" });
    }
  });

  app.post("/api/ai/growth/onboarding-optimization", flexAuth, async (req: any, res) => {
    try {
      const { onboardingData, dropOffPoints } = req.body;
      const optimization = await growthStack.optimizeUserOnboarding(onboardingData, dropOffPoints);
      res.json(optimization);
    } catch (error) {
      console.error("Error optimizing user onboarding:", error);
      res.status(500).json({ message: "Failed to optimize user onboarding" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server - temporarily disabled to fix frontend rendering
  // const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  //
  // wss.on('connection', (ws: WebSocket, req) => {
  //   console.log('New WebSocket connection');
  //
  //   ws.on('message', async (data) => {
  //     try {
  //       const message = JSON.parse(data.toString());
  //       
  //       // Broadcast message to all connected clients
  //       wss.clients.forEach((client) => {
  //         if (client.readyState === WebSocket.OPEN) {
  //           client.send(JSON.stringify(message));
  //         }
  //       });
  //     } catch (error) {
  //       console.error('Error handling WebSocket message:', error);
  //     }
  //   });
  //
  //   ws.on('close', () => {
  //     console.log('WebSocket connection closed');
  //   });
  // });

  // Chat system API routes
  // User connections
  app.post('/api/chat/connections', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validated = insertUserConnectionSchema.parse({
        ...req.body,
        requesterId: userId,
      });
      
      const connection = await storage.createUserConnection(validated);
      
      // Create notification for target user
      await storage.createChatNotification({
        userId: validated.targetId,
        conversationId: 0, // Will be updated when conversation is created
        notificationType: "connection_request",
        isRead: false,
      });
      
      res.json(connection);
    } catch (error) {
      console.error("Create connection error:", error);
      res.status(500).json({ message: "Failed to create connection request" });
    }
  });

  app.get('/api/chat/connections', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const connections = await storage.getUserConnections(userId);
      res.json(connections);
    } catch (error) {
      console.error("Get connections error:", error);
      res.status(500).json({ message: "Failed to get connections" });
    }
  });

  app.put('/api/chat/connections/:id', flexAuth, async (req: any, res) => {
    try {
      const connectionId = parseInt(req.params.id);
      const { status, responseMessage } = req.body;
      
      const connection = await storage.updateUserConnection(connectionId, {
        status,
        responseMessage,
      });
      
      // Create conversation if approved
      if (status === "approved") {
        const conversation = await storage.createChatConversation({
          connectionId: connectionId,
          isGroup: false,
        });
        
        // Create approval notification
        await storage.createChatNotification({
          userId: connection.requesterId,
          conversationId: conversation.id,
          notificationType: "connection_approved",
          isRead: false,
        });
      }
      
      res.json(connection);
    } catch (error) {
      console.error("Update connection error:", error);
      res.status(500).json({ message: "Failed to update connection" });
    }
  });

  // Chat conversations
  app.get('/api/chat/conversations', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversations = await storage.getUserConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error("Get conversations error:", error);
      res.status(500).json({ message: "Failed to get conversations" });
    }
  });

  app.get('/api/chat/conversations/:id/messages', flexAuth, async (req: any, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getConversationMessages(conversationId);
      res.json(messages);
    } catch (error) {
      console.error("Get messages error:", error);
      res.status(500).json({ message: "Failed to get messages" });
    }
  });

  app.post('/api/chat/conversations/:id/messages', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversationId = parseInt(req.params.id);
      
      const validated = insertChatMessageSchema.parse({
        ...req.body,
        conversationId,
        senderId: userId,
      });
      
      const message = await storage.createChatMessage(validated);
      
      // Create notification for other participants
      const conversation = await storage.getConversation(conversationId);
      if (conversation) {
        // Get connection to find other participant
        const connections = await storage.getUserConnections(userId);
        const relevantConnection = connections.find(c => 
          c.id === conversation.connectionId
        );
        
        if (relevantConnection) {
          const otherUserId = relevantConnection.requesterId === userId 
            ? relevantConnection.targetId 
            : relevantConnection.requesterId;
            
          await storage.createChatNotification({
            userId: otherUserId,
            conversationId: conversationId,
            messageId: message.id,
            notificationType: "new_message",
            isRead: false,
          });
        }
      }
      
      res.json(message);
    } catch (error) {
      console.error("Send message error:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.put('/api/chat/messages/:id/read', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messageId = parseInt(req.params.id);
      
      await storage.markMessageAsRead(messageId, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark message read error:", error);
      res.status(500).json({ message: "Failed to mark message as read" });
    }
  });

  // Chat notifications
  app.get('/api/chat/notifications', flexAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Get notifications error:", error);
      res.status(500).json({ message: "Failed to get notifications" });
    }
  });

  app.put('/api/chat/notifications/:id/read', flexAuth, async (req: any, res) => {
    try {
      const notificationId = parseInt(req.params.id);
      await storage.markNotificationAsRead(notificationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark notification read error:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  return httpServer;
}
