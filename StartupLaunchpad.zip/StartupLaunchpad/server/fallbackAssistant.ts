interface AssistantContext {
  userRole: "founder" | "investor";
  userStartups?: any[];
  userInvestments?: any[];
  currentPage?: string;
}

export class FallbackAssistant {
  private founderGuidance = {
    "startup-form": [
      "Focus on clearly defining your value proposition",
      "Research your target market thoroughly",
      "Validate your idea with potential customers",
      "Consider your competitive landscape"
    ],
    "cofounder": [
      "Look for complementary skills to your own",
      "Consider personality and work style compatibility",
      "Discuss equity splits early and transparently",
      "Ensure aligned vision and commitment levels"
    ],
    "fundraising": [
      "Prepare detailed financial projections",
      "Practice your pitch with multiple audiences",
      "Research investor backgrounds and preferences",
      "Have clear use of funds and milestones"
    ],
    "general": [
      "Start with customer development and validation",
      "Build an MVP to test core assumptions",
      "Focus on product-market fit before scaling",
      "Track key metrics and iterate based on data"
    ]
  };

  private investorGuidance = {
    "dashboard": [
      "Review portfolio performance regularly",
      "Monitor market trends in your sectors",
      "Network with other investors for deal flow",
      "Stay updated on regulatory changes"
    ],
    "fundraising": [
      "Evaluate team experience and track record",
      "Assess market size and growth potential",
      "Review business model and unit economics",
      "Consider exit opportunities and timeline"
    ],
    "general": [
      "Diversify across stages and sectors",
      "Conduct thorough due diligence",
      "Add value beyond capital investment",
      "Build long-term relationships with founders"
    ]
  };

  private generalGuidance = {
    "networking": [
      "Attend relevant industry events and conferences",
      "Join startup communities and online forums",
      "Build genuine relationships, not just transactional ones",
      "Offer help before asking for favors"
    ],
    "learning": [
      "Stay current with industry trends and news",
      "Learn from successful entrepreneurs and investors",
      "Read relevant books and case studies",
      "Take courses on business and entrepreneurship"
    ]
  };

  getChatResponse(message: string, context: AssistantContext): string {
    const lowerMessage = message.toLowerCase();
    
    // Detect topic and provide relevant guidance
    if (lowerMessage.includes("fundraising") || lowerMessage.includes("investor")) {
      const guidance = context.userRole === "founder" 
        ? this.founderGuidance.fundraising 
        : this.investorGuidance.fundraising;
      return `Here's some guidance on fundraising:\n\n${guidance.map(item => `• ${item}`).join('\n')}`;
    }
    
    if (lowerMessage.includes("cofounder") || lowerMessage.includes("team")) {
      return `Here's guidance on finding co-founders:\n\n${this.founderGuidance.cofounder.map(item => `• ${item}`).join('\n')}`;
    }
    
    if (lowerMessage.includes("startup") || lowerMessage.includes("business")) {
      const guidance = context.userRole === "founder" 
        ? this.founderGuidance.general 
        : this.investorGuidance.general;
      return `Here's general startup guidance:\n\n${guidance.map(item => `• ${item}`).join('\n')}`;
    }
    
    if (lowerMessage.includes("network")) {
      return `Here's networking advice:\n\n${this.generalGuidance.networking.map(item => `• ${item}`).join('\n')}`;
    }
    
    // Default response
    return "I can help you with startup guidance, fundraising advice, co-founder matching, and general business questions. What specific area would you like to discuss?";
  }

  analyzeStartup(startupData: any): string {
    const strengths = [];
    const improvements = [];
    
    if (startupData.description && startupData.description.length > 50) {
      strengths.push("Well-described value proposition");
    } else {
      improvements.push("Expand your startup description to better communicate value");
    }
    
    if (startupData.industry) {
      strengths.push("Clear industry focus");
    } else {
      improvements.push("Define your target industry more specifically");
    }
    
    if (startupData.valuation && startupData.valuation > 0) {
      strengths.push("Defined valuation target");
    } else {
      improvements.push("Consider setting a realistic valuation based on market research");
    }
    
    let analysis = "**Startup Analysis:**\n\n";
    
    if (strengths.length > 0) {
      analysis += "**Strengths:**\n" + strengths.map(s => `• ${s}`).join('\n') + "\n\n";
    }
    
    if (improvements.length > 0) {
      analysis += "**Areas for Improvement:**\n" + improvements.map(i => `• ${i}`).join('\n');
    }
    
    return analysis;
  }

  analyzeInvestmentOpportunity(startupData: any, fundingRound: any): string {
    const factors = [];
    
    if (startupData.valuation) {
      factors.push(`Current valuation: $${startupData.valuation.toLocaleString()}`);
    }
    
    if (fundingRound?.targetAmount) {
      factors.push(`Funding target: $${fundingRound.targetAmount.toLocaleString()}`);
    }
    
    if (startupData.industry) {
      factors.push(`Industry: ${startupData.industry}`);
    }
    
    const analysis = `**Investment Opportunity Analysis:**\n\n${factors.map(f => `• ${f}`).join('\n')}\n\n**Key Considerations:**\n• Market size and growth potential\n• Team experience and track record\n• Business model sustainability\n• Competitive landscape\n• Exit strategy potential`;
    
    return analysis;
  }

  generateBusinessIdeas(industry: string, interests: string[]): string[] {
    const ideas = [
      `AI-powered solution for ${industry} automation`,
      `Marketplace connecting ${industry} professionals`,
      `SaaS platform for ${industry} management`,
      `Mobile app for ${industry} consumers`,
      `Data analytics platform for ${industry} insights`
    ];
    
    if (interests.includes("sustainability")) {
      ideas.push(`Sustainable technology solution for ${industry}`);
    }
    
    if (interests.includes("AI")) {
      ideas.push(`Machine learning platform for ${industry} optimization`);
    }
    
    return ideas.slice(0, 5);
  }
}

export const fallbackAssistant = new FallbackAssistant();