import {
  users,
  startups,
  fundingRounds,
  investments,
  pitchRooms,
  pitchRoomParticipants,
  messages,
  ratings,
  cofounderProfiles,
  cofounderMatches,
  cofounderConnections,
  fundraisingCampaigns,
  campaignInvestments,
  campaignMilestones,
  campaignUpdates,
  investorInterests,
  userConnections,
  chatConversations,
  chatMessages,
  chatNotifications,
  type User,
  type UpsertUser,
  type Startup,
  type InsertStartup,
  type FundingRound,
  type InsertFundingRound,
  type Investment,
  type InsertInvestment,
  type PitchRoom,
  type InsertPitchRoom,
  type Message,
  type InsertMessage,
  type Rating,
  type InsertRating,
  type CofounderProfile,
  type InsertCofounderProfile,
  type CofounderMatch,
  type InsertCofounderMatch,
  type CofounderConnection,
  type InsertCofounderConnection,
  type FundraisingCampaign,
  type InsertFundraisingCampaign,
  type CampaignInvestment,
  type InsertCampaignInvestment,
  type CampaignMilestone,
  type InsertCampaignMilestone,
  type CampaignUpdate,
  type InsertCampaignUpdate,
  type InvestorInterest,
  type InsertInvestorInterest,
  type UserConnection,
  type InsertUserConnection,
  type ChatConversation,
  type InsertChatConversation,
  type ChatMessage,
  type InsertChatMessage,
  type ChatNotification,
  type InsertChatNotification,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, or } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT - mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserRole(id: string, role: "founder" | "investor"): Promise<User>;
  
  // Startup operations
  createStartup(startup: InsertStartup): Promise<Startup>;
  getStartup(id: number): Promise<Startup | undefined>;
  getStartupsByFounder(founderId: string): Promise<Startup[]>;
  getAllStartups(): Promise<Startup[]>;
  updateStartup(id: number, updates: Partial<InsertStartup>): Promise<Startup>;
  
  // Funding round operations
  createFundingRound(round: InsertFundingRound): Promise<FundingRound>;
  getFundingRound(id: number): Promise<FundingRound | undefined>;
  getFundingRoundsByStartup(startupId: number): Promise<FundingRound[]>;
  getActiveFundingRounds(): Promise<FundingRound[]>;
  updateFundingRound(id: number, updates: Partial<InsertFundingRound>): Promise<FundingRound>;
  
  // Investment operations
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  getInvestmentsByRound(roundId: number): Promise<Investment[]>;
  getInvestmentsByInvestor(investorId: string): Promise<Investment[]>;
  updateInvestment(id: number, updates: Partial<InsertInvestment>): Promise<Investment>;
  
  // Pitch room operations
  createPitchRoom(room: InsertPitchRoom): Promise<PitchRoom>;
  getPitchRoom(id: number): Promise<PitchRoom | undefined>;
  getPitchRoomsByStartup(startupId: number): Promise<PitchRoom[]>;
  getActivePitchRooms(): Promise<PitchRoom[]>;
  updatePitchRoom(id: number, updates: Partial<InsertPitchRoom>): Promise<PitchRoom>;
  joinPitchRoom(roomId: number, userId: string): Promise<void>;
  leavePitchRoom(roomId: number, userId: string): Promise<void>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getDirectMessages(userId1: string, userId2: string): Promise<Message[]>;
  getRoomMessages(roomId: number): Promise<Message[]>;
  getUserMessages(userId: string): Promise<Message[]>;
  
  // Rating operations
  createRating(rating: InsertRating): Promise<Rating>;
  getRatingsByStartup(startupId: number): Promise<Rating[]>;
  getAverageRating(startupId: number): Promise<number>;
  
  // Leaderboard operations
  getTopStartups(limit?: number): Promise<Array<Startup & { averageRating: number; totalFunding: string }>>;
  
  // Co-founder operations
  createCofounderProfile(profile: InsertCofounderProfile): Promise<CofounderProfile>;
  getCofounderProfile(userId: string): Promise<CofounderProfile | undefined>;
  updateCofounderProfile(userId: string, updates: Partial<InsertCofounderProfile>): Promise<CofounderProfile>;
  deleteCofounderProfile(userId: string): Promise<void>;
  searchCofounderProfiles(filters: {
    skills?: string[];
    industries?: string[];
    experience?: string;
    commitment?: string;
    location?: string;
    remoteOk?: boolean;
    limit?: number;
    excludeUserId?: string;
  }): Promise<Array<CofounderProfile & { user: User }>>;
  
  // Co-founder matching operations
  createCofounderMatch(match: InsertCofounderMatch): Promise<CofounderMatch>;
  getCofounderMatches(userId: string, status?: string): Promise<Array<CofounderMatch & { requester: User; target: User }>>;
  updateCofounderMatch(id: number, updates: Partial<InsertCofounderMatch>): Promise<CofounderMatch>;
  getMatchBetweenUsers(requesterId: string, targetId: string): Promise<CofounderMatch | undefined>;
  
  // Co-founder connection operations
  createCofounderConnection(connection: InsertCofounderConnection): Promise<CofounderConnection>;
  getCofounderConnections(userId: string): Promise<Array<CofounderConnection & { user1: User; user2: User }>>;
  
  // Fundraising campaign operations
  createFundraisingCampaign(campaign: InsertFundraisingCampaign): Promise<FundraisingCampaign>;
  getFundraisingCampaign(id: number): Promise<FundraisingCampaign | undefined>;
  getFundraisingCampaignsByStartup(startupId: number): Promise<FundraisingCampaign[]>;
  getActiveFundraisingCampaigns(): Promise<Array<FundraisingCampaign & { startup: Startup }>>;
  updateFundraisingCampaign(id: number, updates: Partial<InsertFundraisingCampaign>): Promise<FundraisingCampaign>;
  updateCampaignRaisedAmount(campaignId: number, amount: string): Promise<void>;
  
  // Campaign investment operations
  createCampaignInvestment(investment: InsertCampaignInvestment): Promise<CampaignInvestment>;
  getCampaignInvestments(campaignId: number): Promise<Array<CampaignInvestment & { investor: User }>>;
  getUserCampaignInvestments(userId: string): Promise<Array<CampaignInvestment & { campaign: FundraisingCampaign & { startup: Startup } }>>;
  updateCampaignInvestment(id: number, updates: Partial<InsertCampaignInvestment>): Promise<CampaignInvestment>;
  
  // Campaign milestone operations
  createCampaignMilestone(milestone: InsertCampaignMilestone): Promise<CampaignMilestone>;
  getCampaignMilestones(campaignId: number): Promise<CampaignMilestone[]>;
  updateCampaignMilestone(id: number, updates: Partial<InsertCampaignMilestone>): Promise<CampaignMilestone>;
  
  // Campaign update operations
  createCampaignUpdate(update: InsertCampaignUpdate): Promise<CampaignUpdate>;
  getCampaignUpdates(campaignId: number, visibility?: string): Promise<CampaignUpdate[]>;
  
  // Investor interest operations
  createInvestorInterest(interest: InsertInvestorInterest): Promise<InvestorInterest>;
  getInvestorInterest(campaignId: number, investorId: string): Promise<InvestorInterest | undefined>;
  updateInvestorInterest(campaignId: number, investorId: string, updates: Partial<InsertInvestorInterest>): Promise<InvestorInterest>;
  getCampaignInterests(campaignId: number): Promise<Array<InvestorInterest & { investor: User }>>;
  
  // Chat system operations
  createUserConnection(connection: InsertUserConnection): Promise<UserConnection>;
  getUserConnections(userId: string): Promise<Array<UserConnection & { requester: User; target: User }>>;
  updateUserConnection(id: number, updates: Partial<InsertUserConnection>): Promise<UserConnection>;
  
  createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation>;
  getUserConversations(userId: string): Promise<Array<ChatConversation & { connection: UserConnection & { requester: User; target: User } }>>;
  getConversation(id: number): Promise<ChatConversation | undefined>;
  updateConversation(id: number, updates: Partial<InsertChatConversation>): Promise<ChatConversation>;
  
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getConversationMessages(conversationId: number): Promise<Array<ChatMessage & { sender: User }>>;
  markMessageAsRead(messageId: number, userId: string): Promise<void>;
  
  createChatNotification(notification: InsertChatNotification): Promise<ChatNotification>;
  getUserNotifications(userId: string): Promise<Array<ChatNotification & { conversation: ChatConversation }>>;
  markNotificationAsRead(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations (IMPORTANT - mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserRole(id: string, role: "founder" | "investor"): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Startup operations
  async createStartup(startup: InsertStartup): Promise<Startup> {
    const [created] = await db.insert(startups).values(startup).returning();
    return created;
  }

  async getStartup(id: number): Promise<Startup | undefined> {
    const [startup] = await db.select().from(startups).where(eq(startups.id, id));
    return startup;
  }

  async getStartupsByFounder(founderId: string): Promise<Startup[]> {
    return await db.select().from(startups).where(eq(startups.founderId, founderId));
  }

  async getAllStartups(): Promise<Startup[]> {
    return await db.select().from(startups).orderBy(desc(startups.createdAt));
  }

  async updateStartup(id: number, updates: Partial<InsertStartup>): Promise<Startup> {
    const [updated] = await db
      .update(startups)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(startups.id, id))
      .returning();
    return updated;
  }

  // Funding round operations
  async createFundingRound(round: InsertFundingRound): Promise<FundingRound> {
    const [created] = await db.insert(startups).values(startup).returning();
    return created;
  }

  async getStartup(id: number): Promise<Startup | undefined> {
    const [startup] = await db.select().from(startups).where(eq(startups.id, id));
    return startup;
  }

  async getStartupsByFounder(founderId: string): Promise<Startup[]> {
    return await db.select().from(startups).where(eq(startups.founderId, founderId));
  }

  async getAllStartups(): Promise<Startup[]> {
    return await db.select().from(startups).orderBy(desc(startups.createdAt));
  }

  async updateStartup(id: number, updates: Partial<InsertStartup>): Promise<Startup> {
    const [updated] = await db
      .update(startups)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(startups.id, id))
      .returning();
    return updated;
  }

  // Funding round operations
  async createFundingRound(round: InsertFundingRound): Promise<FundingRound> {
    const [created] = await db.insert(fundingRounds).values(round).returning();
    return created;
  }

  async getFundingRound(id: number): Promise<FundingRound | undefined> {
    const [round] = await db.select().from(fundingRounds).where(eq(fundingRounds.id, id));
    return round;
  }

  async getFundingRoundsByStartup(startupId: number): Promise<FundingRound[]> {
    return await db
      .select()
      .from(fundingRounds)
      .where(eq(fundingRounds.startupId, startupId))
      .orderBy(desc(fundingRounds.createdAt));
  }

  async getActiveFundingRounds(): Promise<FundingRound[]> {
    return await db
      .select()
      .from(fundingRounds)
      .where(eq(fundingRounds.status, "active"))
      .orderBy(desc(fundingRounds.createdAt));
  }

  async updateFundingRound(id: number, updates: Partial<InsertFundingRound>): Promise<FundingRound> {
    const [updated] = await db
      .update(fundingRounds)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(fundingRounds.id, id))
      .returning();
    return updated;
  }

  // Investment operations
  async createInvestment(investment: InsertInvestment): Promise<Investment> {
    const [created] = await db.insert(investments).values(investment).returning();
    
    // Update funding round raised amount
    const amount = parseFloat(investment.amount.toString());
    await db
      .update(fundingRounds)
      .set({
        raisedAmount: sql`${fundingRounds.raisedAmount} + ${amount}`,
        updatedAt: new Date(),
      })
      .where(eq(fundingRounds.id, investment.fundingRoundId));
    
    return created;
  }

  async getInvestmentsByRound(roundId: number): Promise<Investment[]> {
    return await db
      .select()
      .from(investments)
      .where(eq(investments.fundingRoundId, roundId))
      .orderBy(desc(investments.createdAt));
  }

  async getInvestmentsByInvestor(investorId: string): Promise<Investment[]> {
    return await db
      .select()
      .from(investments)
      .where(eq(investments.investorId, investorId))
      .orderBy(desc(investments.createdAt));
  }

  async updateInvestment(id: number, updates: Partial<InsertInvestment>): Promise<Investment> {
    const [updated] = await db
      .update(investments)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(investments.id, id))
      .returning();
    return updated;
  }

  // Pitch room operations
  async createPitchRoom(room: InsertPitchRoom): Promise<PitchRoom> {
    const [created] = await db.insert(pitchRooms).values(room).returning();
    return created;
  }

  async getPitchRoom(id: number): Promise<PitchRoom | undefined> {
    const [room] = await db.select().from(pitchRooms).where(eq(pitchRooms.id, id));
    return room;
  }

  async getPitchRoomsByStartup(startupId: number): Promise<PitchRoom[]> {
    return await db
      .select()
      .from(pitchRooms)
      .where(eq(pitchRooms.startupId, startupId))
      .orderBy(desc(pitchRooms.scheduledAt));
  }

  async getActivePitchRooms(): Promise<PitchRoom[]> {
    return await db
      .select()
      .from(pitchRooms)
      .where(or(eq(pitchRooms.status, "live"), eq(pitchRooms.status, "scheduled")))
      .orderBy(desc(pitchRooms.scheduledAt));
  }

  async updatePitchRoom(id: number, updates: Partial<InsertPitchRoom>): Promise<PitchRoom> {
    const [updated] = await db
      .update(pitchRooms)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(pitchRooms.id, id))
      .returning();
    return updated;
  }

  async joinPitchRoom(roomId: number, userId: string): Promise<void> {
    await db.insert(pitchRoomParticipants).values({
      pitchRoomId: roomId,
      userId,
    });
  }

  async leavePitchRoom(roomId: number, userId: string): Promise<void> {
    await db
      .update(pitchRoomParticipants)
      .set({ leftAt: new Date() })
      .where(
        and(
          eq(pitchRoomParticipants.pitchRoomId, roomId),
          eq(pitchRoomParticipants.userId, userId)
        )
      );
  }

  // Message operations
  async createMessage(message: InsertMessage): Promise<Message> {
    const [created] = await db.insert(messages).values(message).returning();
    return created;
  }

  async getDirectMessages(userId1: string, userId2: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.type, "direct"),
          or(
            and(eq(messages.senderId, userId1), eq(messages.receiverId, userId2)),
            and(eq(messages.senderId, userId2), eq(messages.receiverId, userId1))
          )
        )
      )
      .orderBy(desc(messages.createdAt));
  }

  async getRoomMessages(roomId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(and(eq(messages.type, "room"), eq(messages.pitchRoomId, roomId)))
      .orderBy(desc(messages.createdAt));
  }

  async getUserMessages(userId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.type, "direct"),
          or(eq(messages.senderId, userId), eq(messages.receiverId, userId))
        )
      )
      .orderBy(desc(messages.createdAt));
  }

  // Rating operations
  async createRating(rating: InsertRating): Promise<Rating> {
    const [created] = await db.insert(ratings).values(rating).returning();
    return created;
  }

  async getRatingsByStartup(startupId: number): Promise<Rating[]> {
    return await db
      .select()
      .from(ratings)
      .where(eq(ratings.startupId, startupId))
      .orderBy(desc(ratings.createdAt));
  }

  async getAverageRating(startupId: number): Promise<number> {
    const result = await db
      .select({
        average: sql<number>`AVG(${ratings.overallScore})`,
      })
      .from(ratings)
      .where(eq(ratings.startupId, startupId));
    
    return result[0]?.average || 0;
  }

  // Leaderboard operations
  async getTopStartups(limit = 10): Promise<Array<Startup & { averageRating: number; totalFunding: string }>> {
    const result = await db
      .select({
        id: startups.id,
        founderId: startups.founderId,
        name: startups.name,
        description: startups.description,
        vision: startups.vision,
        businessModel: startups.businessModel,
        marketSize: startups.marketSize,
        industry: startups.industry,
        stage: startups.stage,
        valuation: startups.valuation,
        logoUrl: startups.logoUrl,
        pitchDeckUrl: startups.pitchDeckUrl,
        websiteUrl: startups.websiteUrl,
        createdAt: startups.createdAt,
        updatedAt: startups.updatedAt,
        averageRating: sql<number>`COALESCE(AVG(${ratings.overallScore}), 0)`,
        totalFunding: sql<string>`COALESCE(SUM(${fundingRounds.raisedAmount}), 0)`,
      })
      .from(startups)
      .leftJoin(ratings, eq(startups.id, ratings.startupId))
      .leftJoin(fundingRounds, eq(startups.id, fundingRounds.startupId))
      .groupBy(startups.id)
      .orderBy(desc(sql`COALESCE(AVG(${ratings.overallScore}), 0)`), desc(sql`COALESCE(SUM(${fundingRounds.raisedAmount}), 0)`))
      .limit(limit);

    return result;
  }

  // Co-founder operations
  async createCofounderProfile(profile: InsertCofounderProfile): Promise<CofounderProfile> {
    const [result] = await db.insert(cofounderProfiles).values(profile).returning();
    return result;
  }

  async getCofounderProfile(userId: string): Promise<CofounderProfile | undefined> {
    const [profile] = await db.select().from(cofounderProfiles).where(eq(cofounderProfiles.userId, userId));
    return profile;
  }

  async updateCofounderProfile(userId: string, updates: Partial<InsertCofounderProfile>): Promise<CofounderProfile> {
    const [result] = await db
      .update(cofounderProfiles)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(cofounderProfiles.userId, userId))
      .returning();
    return result;
  }

  async deleteCofounderProfile(userId: string): Promise<void> {
    await db.delete(cofounderProfiles).where(eq(cofounderProfiles.userId, userId));
  }

  async searchCofounderProfiles(filters: {
    skills?: string[];
    industries?: string[];
    experience?: string;
    commitment?: string;
    location?: string;
    remoteOk?: boolean;
    limit?: number;
    excludeUserId?: string;
  }): Promise<Array<CofounderProfile & { user: User }>> {
    const { skills, industries, experience, commitment, location, remoteOk, limit = 20, excludeUserId } = filters;
    
    let query = db
      .select({
        id: cofounderProfiles.id,
        userId: cofounderProfiles.userId,
        title: cofounderProfiles.title,
        bio: cofounderProfiles.bio,
        skills: cofounderProfiles.skills,
        experience: cofounderProfiles.experience,
        industries: cofounderProfiles.industries,
        commitment: cofounderProfiles.commitment,
        location: cofounderProfiles.location,
        remoteOk: cofounderProfiles.remoteOk,
        equityExpectation: cofounderProfiles.equityExpectation,
        lookingFor: cofounderProfiles.lookingFor,
        portfolio: cofounderProfiles.portfolio,
        linkedin: cofounderProfiles.linkedin,
        github: cofounderProfiles.github,
        available: cofounderProfiles.available,
        createdAt: cofounderProfiles.createdAt,
        updatedAt: cofounderProfiles.updatedAt,
        user: users,
      })
      .from(cofounderProfiles)
      .innerJoin(users, eq(cofounderProfiles.userId, users.id))
      .where(eq(cofounderProfiles.available, true));

    const conditions = [];
    if (excludeUserId) {
      conditions.push(sql`${cofounderProfiles.userId} != ${excludeUserId}`);
    }
    if (experience) {
      conditions.push(eq(cofounderProfiles.experience, experience));
    }
    if (commitment) {
      conditions.push(eq(cofounderProfiles.commitment, commitment));
    }
    if (location) {
      conditions.push(eq(cofounderProfiles.location, location));
    }
    if (remoteOk !== undefined) {
      conditions.push(eq(cofounderProfiles.remoteOk, remoteOk));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const results = await query.limit(limit);
    return results.map(row => ({
      ...row,
      user: row.user,
    }));
  }

  // Co-founder matching operations
  async createCofounderMatch(match: InsertCofounderMatch): Promise<CofounderMatch> {
    const [result] = await db.insert(cofounderMatches).values(match).returning();
    return result;
  }

  async getCofounderMatches(userId: string, status?: string): Promise<Array<CofounderMatch & { requester: User; target: User }>> {
    let query = db
      .select({
        id: cofounderMatches.id,
        requesterId: cofounderMatches.requesterId,
        targetId: cofounderMatches.targetId,
        status: cofounderMatches.status,
        message: cofounderMatches.message,
        createdAt: cofounderMatches.createdAt,
        updatedAt: cofounderMatches.updatedAt,
        requester: {
          id: sql`requester.id`,
          email: sql`requester.email`,
          firstName: sql`requester.first_name`,
          lastName: sql`requester.last_name`,
          profileImageUrl: sql`requester.profile_image_url`,
          role: sql`requester.role`,
        },
        target: {
          id: sql`target.id`,
          email: sql`target.email`,
          firstName: sql`target.first_name`,
          lastName: sql`target.last_name`,
          profileImageUrl: sql`target.profile_image_url`,
          role: sql`target.role`,
        },
      })
      .from(cofounderMatches)
      .innerJoin(sql`users AS requester`, sql`${cofounderMatches.requesterId} = requester.id`)
      .innerJoin(sql`users AS target`, sql`${cofounderMatches.targetId} = target.id`)
      .where(or(eq(cofounderMatches.requesterId, userId), eq(cofounderMatches.targetId, userId)));

    if (status) {
      query = query.where(eq(cofounderMatches.status, status));
    }

    return await query.orderBy(desc(cofounderMatches.createdAt));
  }

  async updateCofounderMatch(id: number, updates: Partial<InsertCofounderMatch>): Promise<CofounderMatch> {
    const [result] = await db
      .update(cofounderMatches)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(cofounderMatches.id, id))
      .returning();
    return result;
  }

  async getMatchBetweenUsers(requesterId: string, targetId: string): Promise<CofounderMatch | undefined> {
    const [match] = await db
      .select()
      .from(cofounderMatches)
      .where(
        or(
          and(eq(cofounderMatches.requesterId, requesterId), eq(cofounderMatches.targetId, targetId)),
          and(eq(cofounderMatches.requesterId, targetId), eq(cofounderMatches.targetId, requesterId))
        )
      );
    return match;
  }

  // Co-founder connection operations
  async createCofounderConnection(connection: InsertCofounderConnection): Promise<CofounderConnection> {
    const [result] = await db.insert(cofounderConnections).values(connection).returning();
    return result;
  }

  async getCofounderConnections(userId: string): Promise<Array<CofounderConnection & { user1: User; user2: User }>> {
    const results = await db
      .select({
        id: cofounderConnections.id,
        user1Id: cofounderConnections.user1Id,
        user2Id: cofounderConnections.user2Id,
        connectionType: cofounderConnections.connectionType,
        notes: cofounderConnections.notes,
        createdAt: cofounderConnections.createdAt,
        user1: sql`user1.*`,
        user2: sql`user2.*`,
      })
      .from(cofounderConnections)
      .innerJoin(sql`users AS user1`, sql`${cofounderConnections.user1Id} = user1.id`)
      .innerJoin(sql`users AS user2`, sql`${cofounderConnections.user2Id} = user2.id`)
      .where(or(eq(cofounderConnections.user1Id, userId), eq(cofounderConnections.user2Id, userId)))
      .orderBy(desc(cofounderConnections.createdAt));

    return results;
  }

  // Fundraising campaign operations
  async createFundraisingCampaign(campaign: InsertFundraisingCampaign): Promise<FundraisingCampaign> {
    const [result] = await db.insert(fundraisingCampaigns).values(campaign).returning();
    return result;
  }

  async getFundraisingCampaign(id: number): Promise<FundraisingCampaign | undefined> {
    const [campaign] = await db.select().from(fundraisingCampaigns).where(eq(fundraisingCampaigns.id, id));
    return campaign;
  }

  async getFundraisingCampaignsByStartup(startupId: number): Promise<FundraisingCampaign[]> {
    return await db.select().from(fundraisingCampaigns)
      .where(eq(fundraisingCampaigns.startupId, startupId))
      .orderBy(desc(fundraisingCampaigns.createdAt));
  }

  async getActiveFundraisingCampaigns(): Promise<Array<FundraisingCampaign & { startup: Startup }>> {
    const results = await db
      .select({
        id: fundraisingCampaigns.id,
        startupId: fundraisingCampaigns.startupId,
        title: fundraisingCampaigns.title,
        description: fundraisingCampaigns.description,
        targetAmount: fundraisingCampaigns.targetAmount,
        raisedAmount: fundraisingCampaigns.raisedAmount,
        minimumInvestment: fundraisingCampaigns.minimumInvestment,
        campaignType: fundraisingCampaigns.campaignType,
        equityOffered: fundraisingCampaigns.equityOffered,
        valuation: fundraisingCampaigns.valuation,
        status: fundraisingCampaigns.status,
        startDate: fundraisingCampaigns.startDate,
        endDate: fundraisingCampaigns.endDate,
        useOfFunds: fundraisingCampaigns.useOfFunds,
        marketingPlan: fundraisingCampaigns.marketingPlan,
        revenueProjections: fundraisingCampaigns.revenueProjections,
        investorBenefits: fundraisingCampaigns.investorBenefits,
        riskFactors: fundraisingCampaigns.riskFactors,
        documents: fundraisingCampaigns.documents,
        createdAt: fundraisingCampaigns.createdAt,
        updatedAt: fundraisingCampaigns.updatedAt,
        startup: startups,
      })
      .from(fundraisingCampaigns)
      .innerJoin(startups, eq(fundraisingCampaigns.startupId, startups.id))
      .where(eq(fundraisingCampaigns.status, "active"))
      .orderBy(desc(fundraisingCampaigns.createdAt));

    return results.map(row => ({
      ...row,
      startup: row.startup,
    }));
  }

  async updateFundraisingCampaign(id: number, updates: Partial<InsertFundraisingCampaign>): Promise<FundraisingCampaign> {
    const [result] = await db
      .update(fundraisingCampaigns)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(fundraisingCampaigns.id, id))
      .returning();
    return result;
  }

  async updateCampaignRaisedAmount(campaignId: number, amount: string): Promise<void> {
    await db
      .update(fundraisingCampaigns)
      .set({ raisedAmount: amount, updatedAt: new Date() })
      .where(eq(fundraisingCampaigns.id, campaignId));
  }

  // Campaign investment operations
  async createCampaignInvestment(investment: InsertCampaignInvestment): Promise<CampaignInvestment> {
    const [result] = await db.insert(campaignInvestments).values(investment).returning();
    return result;
  }

  async getCampaignInvestments(campaignId: number): Promise<Array<CampaignInvestment & { investor: User }>> {
    const results = await db
      .select({
        id: campaignInvestments.id,
        campaignId: campaignInvestments.campaignId,
        investorId: campaignInvestments.investorId,
        amount: campaignInvestments.amount,
        equityPercentage: campaignInvestments.equityPercentage,
        status: campaignInvestments.status,
        paymentMethod: campaignInvestments.paymentMethod,
        investorNotes: campaignInvestments.investorNotes,
        founderResponse: campaignInvestments.founderResponse,
        dueDate: campaignInvestments.dueDate,
        completedAt: campaignInvestments.completedAt,
        createdAt: campaignInvestments.createdAt,
        updatedAt: campaignInvestments.updatedAt,
        investor: users,
      })
      .from(campaignInvestments)
      .innerJoin(users, eq(campaignInvestments.investorId, users.id))
      .where(eq(campaignInvestments.campaignId, campaignId))
      .orderBy(desc(campaignInvestments.createdAt));

    return results.map(row => ({
      ...row,
      investor: row.investor,
    }));
  }

  async getUserCampaignInvestments(userId: string): Promise<Array<CampaignInvestment & { campaign: FundraisingCampaign & { startup: Startup } }>> {
    const results = await db
      .select({
        id: campaignInvestments.id,
        campaignId: campaignInvestments.campaignId,
        investorId: campaignInvestments.investorId,
        amount: campaignInvestments.amount,
        equityPercentage: campaignInvestments.equityPercentage,
        status: campaignInvestments.status,
        paymentMethod: campaignInvestments.paymentMethod,
        investorNotes: campaignInvestments.investorNotes,
        founderResponse: campaignInvestments.founderResponse,
        dueDate: campaignInvestments.dueDate,
        completedAt: campaignInvestments.completedAt,
        createdAt: campaignInvestments.createdAt,
        updatedAt: campaignInvestments.updatedAt,
        campaign: fundraisingCampaigns,
        startup: startups,
      })
      .from(campaignInvestments)
      .innerJoin(fundraisingCampaigns, eq(campaignInvestments.campaignId, fundraisingCampaigns.id))
      .innerJoin(startups, eq(fundraisingCampaigns.startupId, startups.id))
      .where(eq(campaignInvestments.investorId, userId))
      .orderBy(desc(campaignInvestments.createdAt));

    return results.map(row => ({
      ...row,
      campaign: { ...row.campaign, startup: row.startup },
    }));
  }

  async updateCampaignInvestment(id: number, updates: Partial<InsertCampaignInvestment>): Promise<CampaignInvestment> {
    const [result] = await db
      .update(campaignInvestments)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(campaignInvestments.id, id))
      .returning();
    return result;
  }

  // Campaign milestone operations
  async createCampaignMilestone(milestone: InsertCampaignMilestone): Promise<CampaignMilestone> {
    const [result] = await db.insert(campaignMilestones).values(milestone).returning();
    return result;
  }

  async getCampaignMilestones(campaignId: number): Promise<CampaignMilestone[]> {
    return await db.select().from(campaignMilestones)
      .where(eq(campaignMilestones.campaignId, campaignId))
      .orderBy(campaignMilestones.targetDate);
  }

  async updateCampaignMilestone(id: number, updates: Partial<InsertCampaignMilestone>): Promise<CampaignMilestone> {
    const [result] = await db
      .update(campaignMilestones)
      .set(updates)
      .where(eq(campaignMilestones.id, id))
      .returning();
    return result;
  }

  // Campaign update operations
  async createCampaignUpdate(update: InsertCampaignUpdate): Promise<CampaignUpdate> {
    const [result] = await db.insert(campaignUpdates).values(update).returning();
    return result;
  }

  async getCampaignUpdates(campaignId: number, visibility?: string): Promise<CampaignUpdate[]> {
    let query = db.select().from(campaignUpdates)
      .where(eq(campaignUpdates.campaignId, campaignId));

    if (visibility) {
      query = query.where(eq(campaignUpdates.visibility, visibility));
    }

    return await query.orderBy(desc(campaignUpdates.createdAt));
  }

  // Investor interest operations
  async createInvestorInterest(interest: InsertInvestorInterest): Promise<InvestorInterest> {
    const [result] = await db.insert(investorInterests).values(interest).returning();
    return result;
  }

  async getInvestorInterest(campaignId: number, investorId: string): Promise<InvestorInterest | undefined> {
    const [interest] = await db.select().from(investorInterests)
      .where(and(
        eq(investorInterests.campaignId, campaignId),
        eq(investorInterests.investorId, investorId)
      ));
    return interest;
  }

  async updateInvestorInterest(campaignId: number, investorId: string, updates: Partial<InsertInvestorInterest>): Promise<InvestorInterest> {
    const [result] = await db
      .update(investorInterests)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(
        eq(investorInterests.campaignId, campaignId),
        eq(investorInterests.investorId, investorId)
      ))
      .returning();
    return result;
  }

  async getCampaignInterests(campaignId: number): Promise<Array<InvestorInterest & { investor: User }>> {
    const results = await db
      .select({
        id: investorInterests.id,
        campaignId: investorInterests.campaignId,
        investorId: investorInterests.investorId,
        interestLevel: investorInterests.interestLevel,
        notes: investorInterests.notes,
        followUp: investorInterests.followUp,
        createdAt: investorInterests.createdAt,
        updatedAt: investorInterests.updatedAt,
        investor: users,
      })
      .from(investorInterests)
      .innerJoin(users, eq(investorInterests.investorId, users.id))
      .where(eq(investorInterests.campaignId, campaignId))
      .orderBy(desc(investorInterests.createdAt));

    return results.map(row => ({
      ...row,
      investor: row.investor,
    }));
  }

  // Chat system operations
  async createUserConnection(connection: InsertUserConnection): Promise<UserConnection> {
    const [result] = await db
      .insert(userConnections)
      .values(connection)
      .returning();
    return result;
  }

  async getUserConnections(userId: string): Promise<Array<UserConnection & { requester: User; target: User }>> {
    const results = await db
      .select({
        id: userConnections.id,
        requesterId: userConnections.requesterId,
        targetId: userConnections.targetId,
        status: userConnections.status,
        requestMessage: userConnections.requestMessage,
        responseMessage: userConnections.responseMessage,
        connectionType: userConnections.connectionType,
        createdAt: userConnections.createdAt,
        updatedAt: userConnections.updatedAt,
        requester: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          role: users.role,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
        target: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          role: users.role,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(userConnections)
      .innerJoin(users, eq(userConnections.requesterId, users.id))
      .where(or(
        eq(userConnections.requesterId, userId),
        eq(userConnections.targetId, userId)
      ))
      .orderBy(desc(userConnections.createdAt));

    return results;
  }

  async updateUserConnection(id: number, updates: Partial<InsertUserConnection>): Promise<UserConnection> {
    const [result] = await db
      .update(userConnections)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(userConnections.id, id))
      .returning();
    return result;
  }

  async createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation> {
    const [result] = await db
      .insert(chatConversations)
      .values(conversation)
      .returning();
    return result;
  }

  async getUserConversations(userId: string): Promise<Array<ChatConversation & { connection: UserConnection & { requester: User; target: User } }>> {
    const results = await db
      .select({
        id: chatConversations.id,
        connectionId: chatConversations.connectionId,
        name: chatConversations.name,
        isGroup: chatConversations.isGroup,
        lastMessageAt: chatConversations.lastMessageAt,
        createdAt: chatConversations.createdAt,
        updatedAt: chatConversations.updatedAt,
        connection: {
          id: userConnections.id,
          requesterId: userConnections.requesterId,
          targetId: userConnections.targetId,
          status: userConnections.status,
          requestMessage: userConnections.requestMessage,
          responseMessage: userConnections.responseMessage,
          connectionType: userConnections.connectionType,
          createdAt: userConnections.createdAt,
          updatedAt: userConnections.updatedAt,
          requester: {
            id: users.id,
            email: users.email,
            firstName: users.firstName,
            lastName: users.lastName,
            profileImageUrl: users.profileImageUrl,
            role: users.role,
            createdAt: users.createdAt,
            updatedAt: users.updatedAt,
          },
          target: {
            id: users.id,
            email: users.email,
            firstName: users.firstName,
            lastName: users.lastName,
            profileImageUrl: users.profileImageUrl,
            role: users.role,
            createdAt: users.createdAt,
            updatedAt: users.updatedAt,
          },
        },
      })
      .from(chatConversations)
      .innerJoin(userConnections, eq(chatConversations.connectionId, userConnections.id))
      .innerJoin(users, eq(userConnections.requesterId, users.id))
      .where(or(
        eq(userConnections.requesterId, userId),
        eq(userConnections.targetId, userId)
      ))
      .orderBy(desc(chatConversations.lastMessageAt));

    return results;
  }

  async getConversation(id: number): Promise<ChatConversation | undefined> {
    const [conversation] = await db.select().from(chatConversations).where(eq(chatConversations.id, id));
    return conversation;
  }

  async updateConversation(id: number, updates: Partial<InsertChatConversation>): Promise<ChatConversation> {
    const [result] = await db
      .update(chatConversations)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(chatConversations.id, id))
      .returning();
    return result;
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [result] = await db
      .insert(chatMessages)
      .values(message)
      .returning();

    // Update conversation's last message timestamp
    await db
      .update(chatConversations)
      .set({ lastMessageAt: new Date(), updatedAt: new Date() })
      .where(eq(chatConversations.id, message.conversationId));

    return result;
  }

  async getConversationMessages(conversationId: number): Promise<Array<ChatMessage & { sender: User }>> {
    const results = await db
      .select({
        id: chatMessages.id,
        conversationId: chatMessages.conversationId,
        senderId: chatMessages.senderId,
        content: chatMessages.content,
        messageType: chatMessages.messageType,
        attachments: chatMessages.attachments,
        isEdited: chatMessages.isEdited,
        editedAt: chatMessages.editedAt,
        replyToId: chatMessages.replyToId,
        readBy: chatMessages.readBy,
        createdAt: chatMessages.createdAt,
        updatedAt: chatMessages.updatedAt,
        sender: users,
      })
      .from(chatMessages)
      .innerJoin(users, eq(chatMessages.senderId, users.id))
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(chatMessages.createdAt);

    return results.map(row => ({
      ...row,
      sender: row.sender,
    }));
  }

  async markMessageAsRead(messageId: number, userId: string): Promise<void> {
    const [message] = await db.select().from(chatMessages).where(eq(chatMessages.id, messageId));
    if (!message) return;

    const readBy = message.readBy || [];
    if (!readBy.includes(userId)) {
      readBy.push(userId);
      await db
        .update(chatMessages)
        .set({ readBy, updatedAt: new Date() })
        .where(eq(chatMessages.id, messageId));
    }
  }

  async createChatNotification(notification: InsertChatNotification): Promise<ChatNotification> {
    const [result] = await db
      .insert(chatNotifications)
      .values(notification)
      .returning();
    return result;
  }

  async getUserNotifications(userId: string): Promise<Array<ChatNotification & { conversation: ChatConversation }>> {
    const results = await db
      .select({
        id: chatNotifications.id,
        userId: chatNotifications.userId,
        conversationId: chatNotifications.conversationId,
        messageId: chatNotifications.messageId,
        notificationType: chatNotifications.notificationType,
        isRead: chatNotifications.isRead,
        createdAt: chatNotifications.createdAt,
        conversation: chatConversations,
      })
      .from(chatNotifications)
      .innerJoin(chatConversations, eq(chatNotifications.conversationId, chatConversations.id))
      .where(eq(chatNotifications.userId, userId))
      .orderBy(desc(chatNotifications.createdAt));

    return results.map(row => ({
      ...row,
      conversation: row.conversation,
    }));
  }

  async markNotificationAsRead(id: number): Promise<void> {
    await db
      .update(chatNotifications)
      .set({ isRead: true })
      .where(eq(chatNotifications.id, id));
  }
}

export const storage = new DatabaseStorage();
