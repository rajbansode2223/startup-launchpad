import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  uuid
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role", { enum: ["founder", "investor"] }).notNull().default("founder"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const startups = pgTable("startups", {
  id: serial("id").primaryKey(),
  founderId: varchar("founder_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  vision: text("vision").notNull(),
  businessModel: text("business_model").notNull(),
  marketSize: text("market_size").notNull(),
  industry: varchar("industry").notNull(),
  stage: varchar("stage", { enum: ["idea", "mvp", "seed", "seriesA", "seriesB", "growth"] }).notNull(),
  valuation: decimal("valuation", { precision: 12, scale: 2 }),
  logoUrl: text("logo_url"),
  pitchDeckUrl: text("pitch_deck_url"),
  websiteUrl: text("website_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const fundingRounds = pgTable("funding_rounds", {
  id: serial("id").primaryKey(),
  startupId: integer("startup_id").references(() => startups.id).notNull(),
  name: text("name").notNull(),
  targetAmount: decimal("target_amount", { precision: 12, scale: 2 }).notNull(),
  raisedAmount: decimal("raised_amount", { precision: 12, scale: 2 }).default("0"),
  equityOffered: decimal("equity_offered", { precision: 5, scale: 2 }).notNull(),
  minimumInvestment: decimal("minimum_investment", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { enum: ["draft", "active", "closed", "cancelled"] }).notNull().default("draft"),
  deadline: timestamp("deadline"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  fundingRoundId: integer("funding_round_id").references(() => fundingRounds.id).notNull(),
  investorId: varchar("investor_id").references(() => users.id).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  equityReceived: decimal("equity_received", { precision: 5, scale: 2 }).notNull(),
  status: varchar("status", { enum: ["pending", "accepted", "rejected"] }).notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const pitchRooms = pgTable("pitch_rooms", {
  id: serial("id").primaryKey(),
  startupId: integer("startup_id").references(() => startups.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  status: varchar("status", { enum: ["scheduled", "live", "ended"] }).notNull().default("scheduled"),
  scheduledAt: timestamp("scheduled_at").notNull(),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  maxDuration: integer("max_duration").notNull().default(3600), // seconds
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const pitchRoomParticipants = pgTable("pitch_room_participants", {
  id: serial("id").primaryKey(),
  pitchRoomId: integer("pitch_room_id").references(() => pitchRooms.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
  leftAt: timestamp("left_at"),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: varchar("sender_id").references(() => users.id).notNull(),
  receiverId: varchar("receiver_id").references(() => users.id),
  pitchRoomId: integer("pitch_room_id").references(() => pitchRooms.id),
  content: text("content").notNull(),
  type: varchar("type", { enum: ["direct", "room"] }).notNull().default("direct"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const ratings = pgTable("ratings", {
  id: serial("id").primaryKey(),
  startupId: integer("startup_id").references(() => startups.id).notNull(),
  investorId: varchar("investor_id").references(() => users.id).notNull(),
  teamScore: integer("team_score").notNull(),
  productScore: integer("product_score").notNull(),
  marketScore: integer("market_score").notNull(),
  overallScore: decimal("overall_score", { precision: 3, scale: 1 }).notNull(),
  feedback: text("feedback"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Co-founder profiles and matchmaking
export const cofounderProfiles = pgTable("cofounder_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull().unique(),
  title: varchar("title").notNull(), // e.g., "Technical Co-founder", "Marketing Co-founder"
  bio: text("bio").notNull(),
  skills: text("skills").array().notNull(), // Array of skills
  experience: varchar("experience").notNull(), // e.g., "5+ years", "2-5 years", "0-2 years"
  industries: text("industries").array().notNull(), // Preferred industries
  commitment: varchar("commitment").notNull(), // "Full-time", "Part-time", "Equity-only"
  location: varchar("location"),
  remoteOk: boolean("remote_ok").default(false),
  equityExpectation: varchar("equity_expectation"), // e.g., "10-20%", "20-30%"
  lookingFor: text("looking_for").notNull(), // What they're looking for in a co-founder
  portfolio: varchar("portfolio_url"),
  linkedin: varchar("linkedin_url"),
  github: varchar("github_url"),
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const cofounderMatches = pgTable("cofounder_matches", {
  id: serial("id").primaryKey(),
  requesterId: varchar("requester_id").references(() => users.id).notNull(),
  targetId: varchar("target_id").references(() => users.id).notNull(),
  status: varchar("status").notNull(), // "pending", "accepted", "declined", "connected"
  message: text("message"), // Optional message when sending match request
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const cofounderConnections = pgTable("cofounder_connections", {
  id: serial("id").primaryKey(),
  user1Id: varchar("user1_id").references(() => users.id).notNull(),
  user2Id: varchar("user2_id").references(() => users.id).notNull(),
  connectionType: varchar("connection_type").notNull(), // "matched", "direct"
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Fundraising campaigns and investor participation
export const fundraisingCampaigns = pgTable("fundraising_campaigns", {
  id: serial("id").primaryKey(),
  startupId: integer("startup_id").references(() => startups.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  targetAmount: decimal("target_amount", { precision: 12, scale: 2 }).notNull(),
  raisedAmount: decimal("raised_amount", { precision: 12, scale: 2 }).default("0").notNull(),
  minimumInvestment: decimal("minimum_investment", { precision: 10, scale: 2 }).notNull(),
  campaignType: varchar("campaign_type").notNull(), // "seed", "series-a", "series-b", "crowdfunding"
  equityOffered: decimal("equity_offered", { precision: 5, scale: 2 }).notNull(),
  valuation: decimal("valuation", { precision: 15, scale: 2 }).notNull(),
  status: varchar("status").notNull().default("draft"), // "draft", "active", "completed", "cancelled"
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  useOfFunds: text("use_of_funds").notNull(),
  marketingPlan: text("marketing_plan"),
  revenueProjections: jsonb("revenue_projections"), // Array of yearly projections
  investorBenefits: text("investor_benefits").array().notNull(),
  riskFactors: text("risk_factors").array().notNull(),
  documents: text("documents").array(), // URLs to pitch deck, financials, etc.
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const campaignInvestments = pgTable("campaign_investments", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => fundraisingCampaigns.id).notNull(),
  investorId: varchar("investor_id").references(() => users.id).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  equityPercentage: decimal("equity_percentage", { precision: 8, scale: 5 }).notNull(),
  status: varchar("status").notNull().default("pending"), // "pending", "confirmed", "completed", "cancelled"
  paymentMethod: varchar("payment_method"), // "wire", "check", "crypto", "other"
  investorNotes: text("investor_notes"),
  founderResponse: text("founder_response"),
  dueDate: timestamp("due_date"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const campaignMilestones = pgTable("campaign_milestones", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => fundraisingCampaigns.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  targetAmount: decimal("target_amount", { precision: 12, scale: 2 }).notNull(),
  targetDate: timestamp("target_date").notNull(),
  status: varchar("status").notNull().default("pending"), // "pending", "achieved", "missed"
  achievedAt: timestamp("achieved_at"),
  reward: text("reward"), // Special benefits for reaching milestone
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const campaignUpdates = pgTable("campaign_updates", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => fundraisingCampaigns.id).notNull(),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  updateType: varchar("update_type").notNull(), // "progress", "milestone", "news", "financial"
  visibility: varchar("visibility").notNull().default("investors"), // "public", "investors", "private"
  attachments: text("attachments").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const investorInterests = pgTable("investor_interests", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => fundraisingCampaigns.id).notNull(),
  investorId: varchar("investor_id").references(() => users.id).notNull(),
  interestLevel: varchar("interest_level").notNull(), // "watching", "interested", "very_interested"
  notes: text("notes"),
  followUp: boolean("follow_up").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Chat System Tables
export const userConnections = pgTable("user_connections", {
  id: serial("id").primaryKey(),
  requesterId: varchar("requester_id").references(() => users.id).notNull(),
  targetId: varchar("target_id").references(() => users.id).notNull(),
  status: varchar("status").notNull().default("pending"), // "pending", "approved", "rejected", "blocked"
  requestMessage: text("request_message"),
  responseMessage: text("response_message"),
  connectionType: varchar("connection_type").notNull().default("professional"), // "professional", "mentor", "investor", "cofounder"
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chatConversations = pgTable("chat_conversations", {
  id: serial("id").primaryKey(),
  connectionId: integer("connection_id").references(() => userConnections.id).notNull(),
  name: varchar("name"), // Optional conversation name
  isGroup: boolean("is_group").default(false),
  lastMessageAt: timestamp("last_message_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").references(() => chatConversations.id).notNull(),
  senderId: varchar("sender_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  messageType: varchar("message_type").notNull().default("text"), // "text", "image", "file", "system"
  attachments: text("attachments").array(),
  isEdited: boolean("is_edited").default(false),
  editedAt: timestamp("edited_at"),
  replyToId: integer("reply_to_id").references(() => chatMessages.id),
  readBy: text("read_by").array(), // Array of user IDs who have read the message
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chatNotifications = pgTable("chat_notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  conversationId: integer("conversation_id").references(() => chatConversations.id).notNull(),
  messageId: integer("message_id").references(() => chatMessages.id),
  notificationType: varchar("notification_type").notNull(), // "new_message", "connection_request", "connection_approved"
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  startups: many(startups),
  investments: many(investments),
  sentMessages: many(messages, { relationName: "sentMessages" }),
  receivedMessages: many(messages, { relationName: "receivedMessages" }),
  ratings: many(ratings),
  pitchRoomParticipants: many(pitchRoomParticipants),
  cofounderProfile: one(cofounderProfiles),
  sentMatches: many(cofounderMatches, { relationName: "sentMatches" }),
  receivedMatches: many(cofounderMatches, { relationName: "receivedMatches" }),
}));

export const startupsRelations = relations(startups, ({ one, many }) => ({
  founder: one(users, {
    fields: [startups.founderId],
    references: [users.id],
  }),
  fundingRounds: many(fundingRounds),
  pitchRooms: many(pitchRooms),
  ratings: many(ratings),
}));

export const fundingRoundsRelations = relations(fundingRounds, ({ one, many }) => ({
  startup: one(startups, {
    fields: [fundingRounds.startupId],
    references: [startups.id],
  }),
  investments: many(investments),
}));

export const investmentsRelations = relations(investments, ({ one }) => ({
  fundingRound: one(fundingRounds, {
    fields: [investments.fundingRoundId],
    references: [fundingRounds.id],
  }),
  investor: one(users, {
    fields: [investments.investorId],
    references: [users.id],
  }),
}));

export const pitchRoomsRelations = relations(pitchRooms, ({ one, many }) => ({
  startup: one(startups, {
    fields: [pitchRooms.startupId],
    references: [startups.id],
  }),
  participants: many(pitchRoomParticipants),
  messages: many(messages),
}));

export const pitchRoomParticipantsRelations = relations(pitchRoomParticipants, ({ one }) => ({
  pitchRoom: one(pitchRooms, {
    fields: [pitchRoomParticipants.pitchRoomId],
    references: [pitchRooms.id],
  }),
  user: one(users, {
    fields: [pitchRoomParticipants.userId],
    references: [users.id],
  }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
    relationName: "sentMessages",
  }),
  receiver: one(users, {
    fields: [messages.receiverId],
    references: [users.id],
    relationName: "receivedMessages",
  }),
  pitchRoom: one(pitchRooms, {
    fields: [messages.pitchRoomId],
    references: [pitchRooms.id],
  }),
}));

export const ratingsRelations = relations(ratings, ({ one }) => ({
  startup: one(startups, {
    fields: [ratings.startupId],
    references: [startups.id],
  }),
  investor: one(users, {
    fields: [ratings.investorId],
    references: [users.id],
  }),
}));

export const cofounderProfilesRelations = relations(cofounderProfiles, ({ one }) => ({
  user: one(users, {
    fields: [cofounderProfiles.userId],
    references: [users.id],
  }),
}));

export const cofounderMatchesRelations = relations(cofounderMatches, ({ one }) => ({
  requester: one(users, {
    fields: [cofounderMatches.requesterId],
    references: [users.id],
    relationName: "sentMatches",
  }),
  target: one(users, {
    fields: [cofounderMatches.targetId],
    references: [users.id],
    relationName: "receivedMatches",
  }),
}));

export const cofounderConnectionsRelations = relations(cofounderConnections, ({ one }) => ({
  user1: one(users, {
    fields: [cofounderConnections.user1Id],
    references: [users.id],
  }),
  user2: one(users, {
    fields: [cofounderConnections.user2Id],
    references: [users.id],
  }),
}));

export const fundraisingCampaignsRelations = relations(fundraisingCampaigns, ({ one, many }) => ({
  startup: one(startups, {
    fields: [fundraisingCampaigns.startupId],
    references: [startups.id],
  }),
  investments: many(campaignInvestments),
  milestones: many(campaignMilestones),
  updates: many(campaignUpdates),
  interests: many(investorInterests),
}));

export const campaignInvestmentsRelations = relations(campaignInvestments, ({ one }) => ({
  campaign: one(fundraisingCampaigns, {
    fields: [campaignInvestments.campaignId],
    references: [fundraisingCampaigns.id],
  }),
  investor: one(users, {
    fields: [campaignInvestments.investorId],
    references: [users.id],
  }),
}));

export const campaignMilestonesRelations = relations(campaignMilestones, ({ one }) => ({
  campaign: one(fundraisingCampaigns, {
    fields: [campaignMilestones.campaignId],
    references: [fundraisingCampaigns.id],
  }),
}));

export const campaignUpdatesRelations = relations(campaignUpdates, ({ one }) => ({
  campaign: one(fundraisingCampaigns, {
    fields: [campaignUpdates.campaignId],
    references: [fundraisingCampaigns.id],
  }),
}));

export const investorInterestsRelations = relations(investorInterests, ({ one }) => ({
  campaign: one(fundraisingCampaigns, {
    fields: [investorInterests.campaignId],
    references: [fundraisingCampaigns.id],
  }),
  investor: one(users, {
    fields: [investorInterests.investorId],
    references: [users.id],
  }),
}));

// Chat system relations
export const userConnectionsRelations = relations(userConnections, ({ one, many }) => ({
  requester: one(users, {
    fields: [userConnections.requesterId],
    references: [users.id],
    relationName: "connectionRequests",
  }),
  target: one(users, {
    fields: [userConnections.targetId],
    references: [users.id],
    relationName: "connectionTargets",
  }),
  conversations: many(chatConversations),
}));

export const chatConversationsRelations = relations(chatConversations, ({ one, many }) => ({
  connection: one(userConnections, {
    fields: [chatConversations.connectionId],
    references: [userConnections.id],
  }),
  messages: many(chatMessages),
  notifications: many(chatNotifications),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one, many }) => ({
  conversation: one(chatConversations, {
    fields: [chatMessages.conversationId],
    references: [chatConversations.id],
  }),
  sender: one(users, {
    fields: [chatMessages.senderId],
    references: [users.id],
  }),
  replyTo: one(chatMessages, {
    fields: [chatMessages.replyToId],
    references: [chatMessages.id],
    relationName: "replies",
  }),
  replies: many(chatMessages, { relationName: "replies" }),
  notifications: many(chatNotifications),
}));

export const chatNotificationsRelations = relations(chatNotifications, ({ one }) => ({
  user: one(users, {
    fields: [chatNotifications.userId],
    references: [users.id],
  }),
  conversation: one(chatConversations, {
    fields: [chatNotifications.conversationId],
    references: [chatConversations.id],
  }),
  message: one(chatMessages, {
    fields: [chatNotifications.messageId],
    references: [chatMessages.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertStartupSchema = createInsertSchema(startups).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFundingRoundSchema = createInsertSchema(fundingRounds).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deadline: true,
}).extend({
  deadline: z.string().transform((str) => new Date(str)).optional(),
});

export const insertInvestmentSchema = createInsertSchema(investments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPitchRoomSchema = createInsertSchema(pitchRooms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  scheduledAt: true,
}).extend({
  scheduledAt: z.string().transform((str) => new Date(str)),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertRatingSchema = createInsertSchema(ratings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCofounderProfileSchema = createInsertSchema(cofounderProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCofounderMatchSchema = createInsertSchema(cofounderMatches).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCofounderConnectionSchema = createInsertSchema(cofounderConnections).omit({
  id: true,
  createdAt: true,
});

export const insertFundraisingCampaignSchema = createInsertSchema(fundraisingCampaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  raisedAmount: true,
}).extend({
  startDate: z.string().transform((str) => new Date(str)).optional(),
  endDate: z.string().transform((str) => new Date(str)).optional(),
});

export const insertCampaignInvestmentSchema = createInsertSchema(campaignInvestments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  completedAt: true,
}).extend({
  dueDate: z.string().transform((str) => new Date(str)).optional(),
});

export const insertCampaignMilestoneSchema = createInsertSchema(campaignMilestones).omit({
  id: true,
  createdAt: true,
  achievedAt: true,
}).extend({
  targetDate: z.string().transform((str) => new Date(str)),
});

export const insertCampaignUpdateSchema = createInsertSchema(campaignUpdates).omit({
  id: true,
  createdAt: true,
});

export const insertInvestorInterestSchema = createInsertSchema(investorInterests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Chat system insert schemas
export const insertUserConnectionSchema = createInsertSchema(userConnections).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatConversationSchema = createInsertSchema(chatConversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastMessageAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  editedAt: true,
});

export const insertChatNotificationSchema = createInsertSchema(chatNotifications).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertStartup = z.infer<typeof insertStartupSchema>;
export type Startup = typeof startups.$inferSelect;
export type InsertFundingRound = z.infer<typeof insertFundingRoundSchema>;
export type FundingRound = typeof fundingRounds.$inferSelect;
export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;
export type Investment = typeof investments.$inferSelect;
export type InsertPitchRoom = z.infer<typeof insertPitchRoomSchema>;
export type PitchRoom = typeof pitchRooms.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertRating = z.infer<typeof insertRatingSchema>;
export type Rating = typeof ratings.$inferSelect;
export type InsertCofounderProfile = z.infer<typeof insertCofounderProfileSchema>;
export type CofounderProfile = typeof cofounderProfiles.$inferSelect;
export type InsertCofounderMatch = z.infer<typeof insertCofounderMatchSchema>;
export type CofounderMatch = typeof cofounderMatches.$inferSelect;
export type InsertCofounderConnection = z.infer<typeof insertCofounderConnectionSchema>;
export type CofounderConnection = typeof cofounderConnections.$inferSelect;
export type InsertFundraisingCampaign = z.infer<typeof insertFundraisingCampaignSchema>;
export type FundraisingCampaign = typeof fundraisingCampaigns.$inferSelect;
export type InsertCampaignInvestment = z.infer<typeof insertCampaignInvestmentSchema>;
export type CampaignInvestment = typeof campaignInvestments.$inferSelect;
export type InsertCampaignMilestone = z.infer<typeof insertCampaignMilestoneSchema>;
export type CampaignMilestone = typeof campaignMilestones.$inferSelect;
export type InsertCampaignUpdate = z.infer<typeof insertCampaignUpdateSchema>;
export type CampaignUpdate = typeof campaignUpdates.$inferSelect;
export type InsertInvestorInterest = z.infer<typeof insertInvestorInterestSchema>;
export type InvestorInterest = typeof investorInterests.$inferSelect;

// Chat system types
export type InsertUserConnection = z.infer<typeof insertUserConnectionSchema>;
export type UserConnection = typeof userConnections.$inferSelect;
export type InsertChatConversation = z.infer<typeof insertChatConversationSchema>;
export type ChatConversation = typeof chatConversations.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatNotification = z.infer<typeof insertChatNotificationSchema>;
export type ChatNotification = typeof chatNotifications.$inferSelect;
