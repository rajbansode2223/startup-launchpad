import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { DevAuth } from "@/components/dev-auth";
import { VirtualAssistant } from "@/components/virtual-assistant";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import StartupForm from "@/pages/startup-form";
import FundingRound from "@/pages/funding-round";
import AIDashboard from "@/pages/ai-dashboard";
import PitchRoom from "@/pages/pitch-room";
import Leaderboard from "@/pages/leaderboard";
import Cofounder from "@/pages/cofounder";
import Chat from "@/pages/chat";
import NotFound from "@/pages/not-found";

function Router() {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading LaunchPad...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Switch>
        {!isAuthenticated ? (
          <Route path="/" component={Landing} />
        ) : (
          <>
            <Route path="/" component={Dashboard} />
            <Route path="/ai-dashboard" component={AIDashboard} />
            <Route path="/startup/new" component={StartupForm} />
            <Route path="/startup/:id/edit" component={StartupForm} />
            <Route path="/fundraising" component={FundingRound} />
            <Route path="/funding-round/:id" component={FundingRound} />
            <Route path="/pitch-room/:id" component={PitchRoom} />
            <Route path="/leaderboard" component={Leaderboard} />
            <Route path="/cofounder" component={Cofounder} />
            <Route path="/chat" component={Chat} />
          </>
        )}
        <Route component={NotFound} />
      </Switch>
      {/* Temporarily disabled to fix rendering issues */}
      {/* {isAuthenticated && <VirtualAssistant />} */}
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <DevAuth />
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
