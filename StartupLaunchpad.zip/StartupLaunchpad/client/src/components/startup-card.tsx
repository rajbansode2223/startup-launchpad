import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { 
  Edit, 
  BarChart3, 
  Star, 
  DollarSign, 
  Users,
  ExternalLink,
  FileText
} from "lucide-react";

interface StartupCardProps {
  startup: any;
  showActions?: boolean;
}

export default function StartupCard({ startup, showActions = true }: StartupCardProps) {
  const [, setLocation] = useLocation();

  const getStageColor = (stage: string) => {
    switch (stage) {
      case "idea":
        return "bg-blue-100 text-blue-700";
      case "mvp":
        return "bg-purple-100 text-purple-700";
      case "seed":
        return "bg-green-100 text-green-700";
      case "seriesA":
        return "bg-orange-100 text-orange-700";
      case "seriesB":
        return "bg-red-100 text-red-700";
      case "growth":
        return "bg-emerald-100 text-emerald-700";
      default:
        return "bg-neutral-100 text-neutral-700";
    }
  };

  const formatStage = (stage: string) => {
    switch (stage) {
      case "seriesA":
        return "Series A";
      case "seriesB":
        return "Series B";
      default:
        return stage.charAt(0).toUpperCase() + stage.slice(1);
    }
  };

  return (
    <Card className="startup-card hover:shadow-lg transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-4 flex-1">
            {/* Logo placeholder */}
            {startup.logoUrl ? (
              <img 
                src={startup.logoUrl} 
                alt={`${startup.name} logo`}
                className="w-16 h-16 rounded-xl object-cover border-2 border-white shadow-sm"
              />
            ) : (
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">
                  {startup.name.charAt(0)}
                </span>
              </div>
            )}
            
            <div className="flex-1">
              <h3 className="text-xl font-bold text-neutral-900 mb-1">
                {startup.name}
              </h3>
              <p className="text-neutral-600 text-sm mb-2 line-clamp-2">
                {startup.description}
              </p>
              <div className="flex items-center space-x-2">
                <Badge className={getStageColor(startup.stage)}>
                  {formatStage(startup.stage)}
                </Badge>
                <Badge variant="outline">
                  {startup.industry}
                </Badge>
              </div>
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-2xl font-bold text-primary">
              ${startup.valuation ? parseFloat(startup.valuation).toLocaleString() : "TBD"}
            </div>
            <div className="text-sm text-neutral-600">Valuation</div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center">
            <div className="text-lg font-semibold text-neutral-900">
              $0 {/* This would come from funding rounds */}
            </div>
            <div className="text-sm text-neutral-600">Raised</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-neutral-900">
              0% {/* This would come from funding rounds */}
            </div>
            <div className="text-sm text-neutral-600">Equity</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-neutral-900">
              0 {/* This would come from investments */}
            </div>
            <div className="text-sm text-neutral-600">Investors</div>
          </div>
        </div>

        {/* Actions */}
        {showActions && (
          <div className="flex items-center justify-between pt-4 border-t border-neutral-100">
            <div className="flex space-x-2">
              <Button 
                size="sm"
                onClick={() => setLocation(`/startup/${startup.id}/edit`)}
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => setLocation(`/startup/${startup.id}/analytics`)}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Analytics
              </Button>
              {startup.pitchDeckUrl && (
                <Button 
                  size="sm" 
                  variant="outline"
                  asChild
                >
                  <a href={startup.pitchDeckUrl} target="_blank" rel="noopener noreferrer">
                    <FileText className="w-4 h-4 mr-2" />
                    Pitch Deck
                  </a>
                </Button>
              )}
            </div>
            
            <div className="flex items-center space-x-1">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star 
                    key={star} 
                    className={`w-4 h-4 ${
                      star <= 4 ? "text-amber-400 fill-current" : "text-neutral-300"
                    }`} 
                  />
                ))}
              </div>
              <span className="text-sm text-neutral-600 ml-2">4.0/5</span>
            </div>
          </div>
        )}

        {/* External links */}
        {startup.websiteUrl && (
          <div className="mt-4 pt-4 border-t border-neutral-100">
            <Button 
              size="sm" 
              variant="ghost" 
              className="w-full justify-start"
              asChild
            >
              <a href={startup.websiteUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="w-4 h-4 mr-2" />
                Visit Website
              </a>
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
