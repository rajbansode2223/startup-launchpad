import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useLocation } from "wouter";
import { 
  DollarSign, 
  Users, 
  Clock, 
  Target,
  TrendingUp,
  Calendar
} from "lucide-react";

interface FundingProgressProps {
  round: any;
  detailed?: boolean;
}

export default function FundingProgress({ round, detailed = false }: FundingProgressProps) {
  const [, setLocation] = useLocation();

  const progressPercentage = Math.min(
    (parseFloat(round.raisedAmount) / parseFloat(round.targetAmount)) * 100,
    100
  );

  const daysLeft = round.deadline 
    ? Math.max(0, Math.ceil((new Date(round.deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
    : null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-700";
      case "closed":
        return "bg-neutral-100 text-neutral-700";
      case "cancelled":
        return "bg-red-100 text-red-700";
      default:
        return "bg-blue-100 text-blue-700";
    }
  };

  if (detailed) {
    return (
      <Card className="hover:shadow-md transition-shadow duration-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 rounded-full ${
                round.status === "active" ? "bg-green-500 animate-pulse" :
                round.status === "closed" ? "bg-neutral-400" :
                "bg-amber-400"
              }`} />
              <div>
                <h3 className="font-semibold text-neutral-900">{round.name}</h3>
                <p className="text-sm text-neutral-600">
                  {round.startup?.name || "Unknown Startup"}
                </p>
              </div>
            </div>
            <Badge className={getStatusColor(round.status)}>
              {round.status.charAt(0).toUpperCase() + round.status.slice(1)}
            </Badge>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="text-center">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Target className="w-5 h-5 text-primary" />
              </div>
              <div className="font-semibold text-neutral-900">
                ${parseFloat(round.targetAmount).toLocaleString()}
              </div>
              <div className="text-xs text-neutral-600">Target</div>
            </div>
            
            <div className="text-center">
              <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-2">
                <DollarSign className="w-5 h-5 text-secondary" />
              </div>
              <div className="font-semibold text-neutral-900">
                ${parseFloat(round.raisedAmount).toLocaleString()}
              </div>
              <div className="text-xs text-neutral-600">Raised</div>
            </div>
            
            <div className="text-center">
              <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Users className="w-5 h-5 text-accent" />
              </div>
              <div className="font-semibold text-neutral-900">
                {round.investments?.length || 0}
              </div>
              <div className="text-xs text-neutral-600">Investors</div>
            </div>
            
            <div className="text-center">
              <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Clock className="w-5 h-5 text-amber-500" />
              </div>
              <div className="font-semibold text-neutral-900">
                {daysLeft !== null ? daysLeft : "∞"}
              </div>
              <div className="text-xs text-neutral-600">Days Left</div>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex justify-between text-sm text-neutral-600 mb-2">
              <span>Progress</span>
              <span>{progressPercentage.toFixed(1)}%</span>
            </div>
            <Progress value={progressPercentage} className="h-3 funding-progress" />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 text-sm text-neutral-600">
              <span className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {round.equityOffered}% equity
              </span>
              <span className="flex items-center">
                <DollarSign className="w-4 h-4 mr-1" />
                Min: ${parseFloat(round.minimumInvestment).toLocaleString()}
              </span>
            </div>
            <Button 
              size="sm"
              onClick={() => setLocation(`/funding-round/${round.id}`)}
            >
              View Details
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Simplified version for dashboard
  return (
    <div className="border border-neutral-200 rounded-lg p-4 hover:border-primary/30 transition-colors">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className={`w-3 h-3 rounded-full ${
            round.status === "active" ? "bg-green-500 animate-pulse" :
            round.status === "closed" ? "bg-neutral-400" :
            "bg-amber-400"
          }`} />
          <h3 className="font-semibold text-neutral-900">{round.name}</h3>
          <Badge className={getStatusColor(round.status)}>
            {round.status.charAt(0).toUpperCase() + round.status.slice(1)}
          </Badge>
        </div>
        <div className="text-right">
          <div className="font-semibold text-neutral-900">
            ${parseFloat(round.targetAmount).toLocaleString()}
          </div>
          <div className="text-sm text-neutral-600">{round.equityOffered}% equity</div>
        </div>
      </div>
      
      <div className="mb-3">
        <div className="flex justify-between text-sm text-neutral-600 mb-1">
          <span>Progress</span>
          <span>
            ${parseFloat(round.raisedAmount).toLocaleString()} / 
            ${parseFloat(round.targetAmount).toLocaleString()} ({progressPercentage.toFixed(1)}%)
          </span>
        </div>
        <Progress value={progressPercentage} className="h-2" />
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4 text-sm text-neutral-600">
          <span className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            {round.investments?.length || 0} investors
          </span>
          {daysLeft !== null && (
            <span className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              {daysLeft} days left
            </span>
          )}
        </div>
        <Button 
          size="sm"
          onClick={() => setLocation(`/funding-round/${round.id}`)}
        >
          View Details
        </Button>
      </div>
    </div>
  );
}
