import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLocation } from "wouter";
import { Rocket, Users, TrendingUp, MessageSquare, Trophy, LogOut, Loader2, DollarSign, Brain } from "lucide-react";

interface HeaderProps {
  user: any;
  onRoleChange?: (role: "founder" | "investor") => void;
  isChangingRole?: boolean;
}

export default function Header({ user, onRoleChange, isChangingRole }: HeaderProps) {
  const [location, setLocation] = useLocation();

  const navigation = [
    { name: "Dashboard", href: "/", icon: TrendingUp },
    { name: "AI Intelligence", href: "/ai-dashboard", icon: Brain },
    { name: "Fundraising", href: "/fundraising", icon: DollarSign },
    { name: "Co-founders", href: "/cofounder", icon: Users },
    { name: "Chat", href: "/chat", icon: MessageSquare },
    { name: "Leaderboard", href: "/leaderboard", icon: Trophy },
  ];

  const handleRoleSwitch = (role: "founder" | "investor") => {
    if (onRoleChange && role !== user.role) {
      onRoleChange(role);
    }
  };

  return (
    <header className="bg-white border-b border-neutral-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            {/* Logo */}
            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => setLocation("/")}>
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <Rocket className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-neutral-900">LaunchPad</span>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex space-x-6">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href || 
                  (item.href !== "/" && location.startsWith(item.href));
                
                return (
                  <button
                    key={item.name}
                    onClick={() => setLocation(item.href)}
                    className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive
                        ? "text-primary bg-primary/10"
                        : "text-neutral-700 hover:text-primary hover:bg-neutral-50"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.name}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            {/* Role Switcher */}
            {onRoleChange && (
              <div className="flex items-center space-x-2 bg-neutral-100 rounded-lg p-1">
                <button
                  onClick={() => handleRoleSwitch("founder")}
                  disabled={isChangingRole}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                    user.role === "founder"
                      ? "bg-primary text-white"
                      : "text-neutral-600 hover:bg-white"
                  }`}
                >
                  {isChangingRole && user.role === "founder" && (
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                  )}
                  Founder
                </button>
                <button
                  onClick={() => handleRoleSwitch("investor")}
                  disabled={isChangingRole}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                    user.role === "investor"
                      ? "bg-primary text-white"
                      : "text-neutral-600 hover:bg-white"
                  }`}
                >
                  {isChangingRole && user.role === "investor" && (
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                  )}
                  Investor
                </button>
              </div>
            )}

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.profileImageUrl} alt={user.firstName} />
                    <AvatarFallback>
                      {user.firstName?.[0]}{user.lastName?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  {/* Notification badge */}
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-secondary rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">3</span>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex flex-col space-y-1 leading-none">
                    <p className="font-medium">
                      {user.firstName} {user.lastName}
                    </p>
                    <p className="w-[200px] truncate text-sm text-muted-foreground">
                      {user.email}
                    </p>
                    <Badge variant="outline" className="w-fit capitalize">
                      {user.role}
                    </Badge>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setLocation("/profile")}>
                  Profile Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLocation("/notifications")}>
                  Notifications
                  <Badge className="ml-auto">3</Badge>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => window.location.href = "/api/logout"}
                  className="text-red-600"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden border-t border-neutral-200">
        <div className="px-4 py-2">
          <div className="flex space-x-2 overflow-x-auto">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href || 
                (item.href !== "/" && location.startsWith(item.href));
              
              return (
                <button
                  key={item.name}
                  onClick={() => setLocation(item.href)}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap transition-colors ${
                    isActive
                      ? "text-primary bg-primary/10"
                      : "text-neutral-700 hover:text-primary hover:bg-neutral-50"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
}
