// Development authentication component - manual login only
export function DevAuth() {
  return null;
}