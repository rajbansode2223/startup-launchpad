import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, Clock } from "lucide-react";

interface MessageListProps {
  messages: any[];
  isLoading: boolean;
  maxItems?: number;
}

export default function MessageList({ messages, isLoading, maxItems = 5 }: MessageListProps) {
  // Group messages by conversation (sender/receiver pairs)
  const groupedMessages = messages.reduce((acc, message) => {
    const otherUserId = message.senderId === message.currentUserId ? message.receiverId : message.senderId;
    const otherUserName = message.senderId === message.currentUserId ? message.receiverName : message.senderName;
    
    if (!acc[otherUserId]) {
      acc[otherUserId] = {
        userId: otherUserId,
        userName: otherUserName,
        messages: [],
        lastMessage: null,
        unreadCount: 0,
      };
    }
    
    acc[otherUserId].messages.push(message);
    if (!acc[otherUserId].lastMessage || new Date(message.createdAt) > new Date(acc[otherUserId].lastMessage.createdAt)) {
      acc[otherUserId].lastMessage = message;
    }
    
    return acc;
  }, {} as Record<string, any>);

  const conversations = Object.values(groupedMessages)
    .sort((a: any, b: any) => 
      new Date(b.lastMessage?.createdAt || 0).getTime() - new Date(a.lastMessage?.createdAt || 0).getTime()
    )
    .slice(0, maxItems);

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "just now";
    if (diffInMinutes < 60) return `${diffInMinutes}m`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h`;
    return `${Math.floor(diffInMinutes / 1440)}d`;
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2 text-lg">
            <MessageSquare className="w-5 h-5" />
            <span>Messages</span>
          </CardTitle>
          {conversations.length > 0 && (
            <Badge variant="destructive" className="text-xs">
              {conversations.reduce((sum: number, conv: any) => sum + conv.unreadCount, 0) || conversations.length}
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <ScrollArea className="h-64">
          {isLoading ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-neutral-200 rounded-full animate-pulse" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-neutral-200 rounded animate-pulse" />
                    <div className="h-3 bg-neutral-200 rounded w-3/4 animate-pulse" />
                  </div>
                </div>
              ))}
            </div>
          ) : conversations.length > 0 ? (
            <div className="divide-y divide-neutral-200">
              {conversations.map((conversation: any) => (
                <div 
                  key={conversation.userId}
                  className="p-4 hover:bg-neutral-50 transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={conversation.profileImageUrl} />
                      <AvatarFallback>
                        {conversation.userName
                          ?.split(' ')
                          .map((n: string) => n[0])
                          .join('')
                          .toUpperCase() || "?"}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-neutral-900 truncate">
                          {conversation.userName || "Unknown User"}
                        </p>
                        <p className="text-xs text-neutral-500">
                          {conversation.lastMessage 
                            ? formatTimeAgo(conversation.lastMessage.createdAt)
                            : ""
                          }
                        </p>
                      </div>
                      <p className="text-sm text-neutral-600 truncate">
                        {conversation.lastMessage?.content || "No messages"}
                      </p>
                    </div>
                    
                    {conversation.unreadCount > 0 && (
                      <div className="w-2 h-2 bg-primary rounded-full" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center">
              <MessageSquare className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-600 text-sm">No messages yet</p>
              <p className="text-neutral-500 text-xs mt-1">
                Connect with investors and founders
              </p>
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
