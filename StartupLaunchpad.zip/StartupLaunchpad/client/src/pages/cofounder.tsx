import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Search, Users, MessageCircle, CheckCircle, X, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/header";
import { useAuth } from "@/hooks/useAuth";

// Schema for co-founder profile form
const cofounderProfileSchema = z.object({
  title: z.string().min(1, "Title is required"),
  bio: z.string().min(50, "Bio must be at least 50 characters"),
  skills: z.array(z.string()).min(1, "At least one skill is required"),
  experience: z.string().min(1, "Experience level is required"),
  industries: z.array(z.string()).min(1, "At least one industry is required"),
  commitment: z.string().min(1, "Commitment level is required"),
  location: z.string().optional(),
  remoteOk: z.boolean().default(false),
  equityExpectation: z.string().optional(),
  lookingFor: z.string().min(30, "Please describe what you're looking for (minimum 30 characters)"),
  portfolio: z.string().url().optional().or(z.literal("")),
  linkedin: z.string().url().optional().or(z.literal("")),
  github: z.string().url().optional().or(z.literal("")),
});

type CofounderProfileData = z.infer<typeof cofounderProfileSchema>;

const skillOptions = [
  "Frontend Development", "Backend Development", "Full Stack Development", "Mobile Development",
  "UI/UX Design", "Product Management", "Marketing", "Sales", "Business Development",
  "Data Science", "Machine Learning", "DevOps", "Cybersecurity", "Blockchain",
  "Financial Planning", "Legal", "Operations", "Human Resources", "Customer Success"
];

const industryOptions = [
  "Technology", "Healthcare", "Fintech", "E-commerce", "Education", "Gaming",
  "SaaS", "Marketplace", "Social Media", "IoT", "AI/ML", "Blockchain",
  "Sustainability", "Real Estate", "Food & Beverage", "Fashion", "Transportation"
];

export default function Cofounder() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showProfileForm, setShowProfileForm] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<any>(null);
  const [searchFilters, setSearchFilters] = useState({
    experience: "",
    commitment: "",
    skills: "",
    industries: "",
    location: "",
    remoteOk: false
  });

  // Get user's co-founder profile
  const { data: userProfile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/cofounder/profile"],
    retry: false,
  });

  // Search co-founder profiles
  const { data: searchResults = [], isLoading: searchLoading } = useQuery({
    queryKey: ["/api/cofounder/search", searchFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      Object.entries(searchFilters).forEach(([key, value]) => {
        if (value) params.append(key, String(value));
      });
      return apiRequest(`/api/cofounder/search?${params}`);
    },
  });

  // Get matches
  const { data: matches = [] } = useQuery({
    queryKey: ["/api/cofounder/matches"],
  });

  // Get connections
  const { data: connections = [] } = useQuery({
    queryKey: ["/api/cofounder/connections"],
  });

  const form = useForm<CofounderProfileData>({
    resolver: zodResolver(cofounderProfileSchema),
    defaultValues: {
      title: "",
      bio: "",
      skills: [],
      experience: "",
      industries: [],
      commitment: "",
      location: "",
      remoteOk: false,
      equityExpectation: "",
      lookingFor: "",
      portfolio: "",
      linkedin: "",
      github: "",
    },
  });

  // Create/Update profile mutation
  const profileMutation = useMutation({
    mutationFn: async (data: CofounderProfileData) => {
      const method = userProfile ? "PUT" : "POST";
      return apiRequest("/api/cofounder/profile", {
        method,
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Profile saved successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cofounder/profile"] });
      setShowProfileForm(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save profile",
        variant: "destructive",
      });
    },
  });

  // Send match request mutation
  const matchMutation = useMutation({
    mutationFn: async ({ targetId, message }: { targetId: string; message?: string }) => {
      return apiRequest("/api/cofounder/match", {
        method: "POST",
        body: JSON.stringify({ targetId, message }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Match request sent successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cofounder/matches"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send match request",
        variant: "destructive",
      });
    },
  });

  // Update match status mutation
  const updateMatchMutation = useMutation({
    mutationFn: async ({ matchId, status }: { matchId: number; status: string }) => {
      return apiRequest(`/api/cofounder/match/${matchId}`, {
        method: "PUT",
        body: JSON.stringify({ status }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Match status updated successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cofounder/matches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/cofounder/connections"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update match status",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CofounderProfileData) => {
    profileMutation.mutate(data);
  };

  const handleSendMatch = (targetId: string, message?: string) => {
    matchMutation.mutate({ targetId, message });
  };

  const handleMatchResponse = (matchId: number, status: string) => {
    updateMatchMutation.mutate({ matchId, status });
  };

  const ProfileCard = ({ profile }: { profile: any }) => (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img
              src={profile.user.profileImageUrl}
              alt={`${profile.user.firstName} ${profile.user.lastName}`}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <CardTitle className="text-lg">
                {profile.user.firstName} {profile.user.lastName}
              </CardTitle>
              <CardDescription className="text-sm font-medium text-primary">
                {profile.title}
              </CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground line-clamp-3">{profile.bio}</p>
        
        <div className="space-y-2">
          <div className="flex flex-wrap gap-1">
            {profile.skills.slice(0, 3).map((skill: string) => (
              <Badge key={skill} variant="secondary" className="text-xs">
                {skill}
              </Badge>
            ))}
            {profile.skills.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{profile.skills.length - 3} more
              </Badge>
            )}
          </div>
          
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>{profile.experience} experience</span>
            <span>{profile.commitment}</span>
          </div>
          
          {profile.location && (
            <div className="text-sm text-muted-foreground">
              📍 {profile.location} {profile.remoteOk && "(Remote OK)"}
            </div>
          )}
        </div>

        <div className="flex gap-2 pt-2">
          <Button
            size="sm"
            onClick={() => setSelectedProfile(profile)}
            variant="outline"
            className="flex-1"
          >
            <Eye className="w-4 h-4 mr-1" />
            View
          </Button>
          <Button
            size="sm"
            onClick={() => handleSendMatch(profile.userId)}
            disabled={matchMutation.isPending}
            className="flex-1"
          >
            <MessageCircle className="w-4 h-4 mr-1" />
            Connect
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  if (profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Co-founder Matchmaking</h1>
            <p className="text-muted-foreground mt-2">
              Find the perfect co-founder to build your startup together
            </p>
          </div>
          
          {!userProfile && (
            <Button onClick={() => setShowProfileForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Profile
            </Button>
          )}
        </div>

        {!userProfile ? (
          <Card className="text-center py-12">
            <CardContent>
              <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">Create Your Co-founder Profile</h3>
              <p className="text-muted-foreground mb-6">
                Start by creating your profile to connect with potential co-founders
              </p>
              <Button onClick={() => setShowProfileForm(true)} size="lg">
                <Plus className="w-4 h-4 mr-2" />
                Create Profile
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="search" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="search">
                <Search className="w-4 h-4 mr-2" />
                Search
              </TabsTrigger>
              <TabsTrigger value="matches">
                <MessageCircle className="w-4 h-4 mr-2" />
                Matches ({matches.length})
              </TabsTrigger>
              <TabsTrigger value="connections">
                <Users className="w-4 h-4 mr-2" />
                Connections ({connections.length})
              </TabsTrigger>
              <TabsTrigger value="profile">Profile</TabsTrigger>
            </TabsList>

            <TabsContent value="search" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Search Filters</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Select
                    value={searchFilters.experience}
                    onValueChange={(value) => setSearchFilters(prev => ({ ...prev, experience: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Experience Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Experience</SelectItem>
                      <SelectItem value="0-2 years">0-2 years</SelectItem>
                      <SelectItem value="2-5 years">2-5 years</SelectItem>
                      <SelectItem value="5+ years">5+ years</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select
                    value={searchFilters.commitment}
                    onValueChange={(value) => setSearchFilters(prev => ({ ...prev, commitment: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Commitment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Commitments</SelectItem>
                      <SelectItem value="Full-time">Full-time</SelectItem>
                      <SelectItem value="Part-time">Part-time</SelectItem>
                      <SelectItem value="Equity-only">Equity-only</SelectItem>
                    </SelectContent>
                  </Select>

                  <Input
                    placeholder="Location"
                    value={searchFilters.location}
                    onChange={(e) => setSearchFilters(prev => ({ ...prev, location: e.target.value }))}
                  />
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {searchLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="h-64 bg-muted" />
                    </Card>
                  ))
                ) : searchResults.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <Search className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No profiles found</h3>
                    <p className="text-muted-foreground">
                      Try adjusting your search filters
                    </p>
                  </div>
                ) : (
                  searchResults.map((profile: any) => (
                    <ProfileCard key={profile.id} profile={profile} />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="matches" className="space-y-6">
              <div className="space-y-4">
                {matches.length === 0 ? (
                  <Card className="text-center py-12">
                    <CardContent>
                      <MessageCircle className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                      <h3 className="text-xl font-semibold mb-2">No matches yet</h3>
                      <p className="text-muted-foreground">
                        Start connecting with potential co-founders
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  matches.map((match: any) => (
                    <Card key={match.id}>
                      <CardContent className="flex items-center justify-between p-6">
                        <div className="flex items-center space-x-4">
                          <img
                            src={match.target.profileImageUrl || match.requester.profileImageUrl}
                            alt="Profile"
                            className="w-12 h-12 rounded-full object-cover"
                          />
                          <div>
                            <h4 className="font-semibold">
                              {match.target.firstName} {match.target.lastName}
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {match.status === "pending" ? "Pending response" : `Status: ${match.status}`}
                            </p>
                            {match.message && (
                              <p className="text-sm text-muted-foreground italic mt-1">
                                "{match.message}"
                              </p>
                            )}
                          </div>
                        </div>
                        
                        {match.status === "pending" && match.targetId === user?.id && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => handleMatchResponse(match.id, "accepted")}
                              disabled={updateMatchMutation.isPending}
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Accept
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleMatchResponse(match.id, "declined")}
                              disabled={updateMatchMutation.isPending}
                            >
                              <X className="w-4 h-4 mr-1" />
                              Decline
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="connections" className="space-y-6">
              <div className="space-y-4">
                {connections.length === 0 ? (
                  <Card className="text-center py-12">
                    <CardContent>
                      <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                      <h3 className="text-xl font-semibold mb-2">No connections yet</h3>
                      <p className="text-muted-foreground">
                        Accept match requests to build your network
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  connections.map((connection: any) => (
                    <Card key={connection.id}>
                      <CardContent className="flex items-center justify-between p-6">
                        <div className="flex items-center space-x-4">
                          <img
                            src={connection.user1.profileImageUrl || connection.user2.profileImageUrl}
                            alt="Profile"
                            className="w-12 h-12 rounded-full object-cover"
                          />
                          <div>
                            <h4 className="font-semibold">
                              {connection.user1.id === user?.id 
                                ? `${connection.user2.firstName} ${connection.user2.lastName}`
                                : `${connection.user1.firstName} ${connection.user1.lastName}`
                              }
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              Connected via {connection.connectionType}
                            </p>
                          </div>
                        </div>
                        
                        <Button size="sm" variant="outline">
                          <MessageCircle className="w-4 h-4 mr-1" />
                          Message
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="profile" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Your Co-founder Profile</CardTitle>
                  <CardDescription>
                    This is how other potential co-founders will see you
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={() => {
                    if (userProfile) {
                      form.reset(userProfile);
                    }
                    setShowProfileForm(true);
                  }}>
                    Edit Profile
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}

        {/* Profile Form Dialog */}
        <Dialog open={showProfileForm} onOpenChange={setShowProfileForm}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {userProfile ? "Edit" : "Create"} Co-founder Profile
              </DialogTitle>
              <DialogDescription>
                Share your background and what you're looking for in a co-founder
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title/Role</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Technical Co-founder, Marketing Co-founder" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bio</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Tell potential co-founders about yourself, your background, and your vision..."
                          className="min-h-24"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="experience"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Experience Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select experience level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="0-2 years">0-2 years</SelectItem>
                            <SelectItem value="2-5 years">2-5 years</SelectItem>
                            <SelectItem value="5+ years">5+ years</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="commitment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Commitment Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select commitment level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Full-time">Full-time</SelectItem>
                            <SelectItem value="Part-time">Part-time</SelectItem>
                            <SelectItem value="Equity-only">Equity-only</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="skills"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Skills & Expertise</FormLabel>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-48 overflow-y-auto border rounded-md p-4">
                        {skillOptions.map((skill) => (
                          <div key={skill} className="flex items-center space-x-2">
                            <Checkbox
                              id={skill}
                              checked={field.value?.includes(skill)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  field.onChange([...field.value, skill]);
                                } else {
                                  field.onChange(field.value?.filter((s: string) => s !== skill));
                                }
                              }}
                            />
                            <label htmlFor={skill} className="text-sm">
                              {skill}
                            </label>
                          </div>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="industries"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preferred Industries</FormLabel>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-48 overflow-y-auto border rounded-md p-4">
                        {industryOptions.map((industry) => (
                          <div key={industry} className="flex items-center space-x-2">
                            <Checkbox
                              id={industry}
                              checked={field.value?.includes(industry)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  field.onChange([...field.value, industry]);
                                } else {
                                  field.onChange(field.value?.filter((i: string) => i !== industry));
                                }
                              }}
                            />
                            <label htmlFor={industry} className="text-sm">
                              {industry}
                            </label>
                          </div>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lookingFor"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>What I'm Looking For</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe what you're looking for in a co-founder..."
                          className="min-h-24"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., San Francisco, CA" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="equityExpectation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Equity Expectation (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., 10-20%, 25-40%" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="remoteOk"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Open to remote collaboration
                        </FormLabel>
                      </div>
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <FormField
                    control={form.control}
                    name="portfolio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Portfolio URL (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="https://yourportfolio.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="linkedin"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>LinkedIn URL (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="https://linkedin.com/in/yourprofile" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="github"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>GitHub URL (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="https://github.com/yourusername" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowProfileForm(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={profileMutation.isPending}>
                    {profileMutation.isPending ? "Saving..." : "Save Profile"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Profile Detail Dialog */}
        {selectedProfile && (
          <Dialog open={!!selectedProfile} onOpenChange={() => setSelectedProfile(null)}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <div className="flex items-center space-x-4">
                  <img
                    src={selectedProfile.user.profileImageUrl}
                    alt={`${selectedProfile.user.firstName} ${selectedProfile.user.lastName}`}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <DialogTitle className="text-xl">
                      {selectedProfile.user.firstName} {selectedProfile.user.lastName}
                    </DialogTitle>
                    <DialogDescription className="text-lg font-medium text-primary">
                      {selectedProfile.title}
                    </DialogDescription>
                  </div>
                </div>
              </DialogHeader>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-2">About</h4>
                  <p className="text-muted-foreground">{selectedProfile.bio}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Skills & Expertise</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProfile.skills.map((skill: string) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Preferred Industries</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProfile.industries.map((industry: string) => (
                      <Badge key={industry} variant="outline">
                        {industry}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold mb-1">Experience</h4>
                    <p className="text-muted-foreground">{selectedProfile.experience}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Commitment</h4>
                    <p className="text-muted-foreground">{selectedProfile.commitment}</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Looking For</h4>
                  <p className="text-muted-foreground">{selectedProfile.lookingFor}</p>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedProfile(null)}
                  >
                    Close
                  </Button>
                  <Button
                    onClick={() => {
                      handleSendMatch(selectedProfile.userId);
                      setSelectedProfile(null);
                    }}
                    disabled={matchMutation.isPending}
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Send Match Request
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}