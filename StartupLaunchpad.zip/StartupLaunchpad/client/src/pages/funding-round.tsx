import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Calendar, Clock, DollarSign, Target, Users, TrendingUp, Award, MessageSquare, FileText, Heart } from "lucide-react";
import { format } from "date-fns";

const campaignSchema = z.object({
  startupId: z.number(),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  targetAmount: z.string().min(1, "Target amount is required"),
  minimumInvestment: z.string().min(1, "Minimum investment is required"),
  campaignType: z.enum(["seed", "series-a", "series-b", "crowdfunding"]),
  equityOffered: z.string().min(1, "Equity offered is required"),
  valuation: z.string().min(1, "Valuation is required"),
  useOfFunds: z.string().min(1, "Use of funds is required"),
  marketingPlan: z.string().optional(),
  investorBenefits: z.array(z.string()).min(1, "At least one benefit required"),
  riskFactors: z.array(z.string()).min(1, "At least one risk factor required"),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

const investmentSchema = z.object({
  amount: z.string().min(1, "Investment amount is required"),
  equityPercentage: z.string().min(1, "Equity percentage is required"),
  investorNotes: z.string().optional(),
  paymentMethod: z.enum(["wire", "check", "crypto", "other"]).optional(),
});

const milestoneSchema = z.object({
  title: z.string().min(1, "Milestone title is required"),
  description: z.string().min(1, "Description is required"),
  targetAmount: z.string().min(1, "Target amount is required"),
  targetDate: z.string().min(1, "Target date is required"),
  reward: z.string().optional(),
});

const updateSchema = z.object({
  title: z.string().min(1, "Update title is required"),
  content: z.string().min(1, "Content is required"),
  updateType: z.enum(["progress", "milestone", "news", "financial"]),
  visibility: z.enum(["public", "investors", "private"]),
});

export default function FundingRound() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedCampaign, setSelectedCampaign] = useState<any>(null);
  const [activeTab, setActiveTab] = useState("campaigns");

  // Fetch campaigns
  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery({
    queryKey: ["/api/fundraising/campaigns"],
  });

  // Fetch user's investments
  const { data: myInvestments = [] } = useQuery({
    queryKey: ["/api/fundraising/my-investments"],
    enabled: isAuthenticated,
  });

  // Fetch user's startups for creating campaigns
  const { data: userStartups = [] } = useQuery({
    queryKey: ["/api/startups/my"],
    enabled: isAuthenticated,
  });

  // Create campaign mutation
  const createCampaignMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/fundraising/campaigns", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fundraising/campaigns"] });
      toast({ title: "Campaign created successfully!" });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create campaign",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Investment mutation
  const investMutation = useMutation({
    mutationFn: async ({ campaignId, data }: { campaignId: number; data: any }) => {
      return await apiRequest("POST", `/api/fundraising/campaigns/${campaignId}/invest`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fundraising/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/fundraising/my-investments"] });
      toast({ title: "Investment submitted successfully!" });
    },
    onError: (error: any) => {
      toast({
        title: "Investment failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const campaignForm = useForm({
    resolver: zodResolver(campaignSchema),
    defaultValues: {
      startupId: 0,
      title: "",
      description: "",
      targetAmount: "",
      minimumInvestment: "",
      campaignType: "seed" as const,
      equityOffered: "",
      valuation: "",
      useOfFunds: "",
      marketingPlan: "",
      investorBenefits: [""],
      riskFactors: [""],
    },
  });

  const investmentForm = useForm({
    resolver: zodResolver(investmentSchema),
    defaultValues: {
      amount: "",
      equityPercentage: "",
      investorNotes: "",
      paymentMethod: "wire" as const,
    },
  });

  const onCreateCampaign = (data: any) => {
    createCampaignMutation.mutate({
      ...data,
      investorBenefits: data.investorBenefits.filter((b: string) => b.trim()),
      riskFactors: data.riskFactors.filter((r: string) => r.trim()),
    });
  };

  const onInvest = (data: any) => {
    if (!selectedCampaign) return;
    investMutation.mutate({
      campaignId: selectedCampaign.id,
      data,
    });
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(parseFloat(amount));
  };

  const getProgressPercentage = (raised: string, target: string) => {
    return Math.min((parseFloat(raised) / parseFloat(target)) * 100, 100);
  };

  const getCampaignTypeColor = (type: string) => {
    const colors = {
      seed: "bg-green-100 text-green-800",
      "series-a": "bg-blue-100 text-blue-800",
      "series-b": "bg-purple-100 text-purple-800",
      crowdfunding: "bg-orange-100 text-orange-800",
    };
    return colors[type as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  const CampaignCard = ({ campaign }: { campaign: any }) => {
    const progressPercentage = getProgressPercentage(campaign.raisedAmount, campaign.targetAmount);
    
    return (
      <Card className="cursor-pointer hover:shadow-lg transition-shadow">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl font-bold">{campaign.title}</CardTitle>
              <CardDescription className="text-sm text-gray-600">
                {campaign.startup?.name} • {campaign.startup?.industry}
              </CardDescription>
            </div>
            <Badge className={getCampaignTypeColor(campaign.campaignType)}>
              {campaign.campaignType.replace('-', ' ').toUpperCase()}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-4 line-clamp-3">{campaign.description}</p>
          
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Progress</span>
                <span>{progressPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
              <div className="flex justify-between text-sm mt-1">
                <span className="font-semibold">{formatCurrency(campaign.raisedAmount)}</span>
                <span className="text-gray-600">of {formatCurrency(campaign.targetAmount)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-1">
                <DollarSign className="w-4 h-4 text-green-600" />
                <span>Min: {formatCurrency(campaign.minimumInvestment)}</span>
              </div>
              <div className="flex items-center gap-1">
                <Target className="w-4 h-4 text-blue-600" />
                <span>{campaign.equityOffered}% equity</span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button 
                onClick={() => setSelectedCampaign(campaign)}
                className="flex-1"
              >
                View Details
              </Button>
              {isAuthenticated && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="flex-1">
                      <Heart className="w-4 h-4 mr-1" />
                      Invest
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Invest in {campaign.title}</DialogTitle>
                    </DialogHeader>
                    <Form {...investmentForm}>
                      <form onSubmit={investmentForm.handleSubmit(onInvest)} className="space-y-4">
                        <FormField
                          control={investmentForm.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Investment Amount ($)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  min={campaign.minimumInvestment}
                                  placeholder={`Minimum: $${campaign.minimumInvestment}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={investmentForm.control}
                          name="equityPercentage"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Expected Equity (%)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01"
                                  max={campaign.equityOffered}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={investmentForm.control}
                          name="paymentMethod"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Payment Method</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="wire">Wire Transfer</SelectItem>
                                  <SelectItem value="check">Check</SelectItem>
                                  <SelectItem value="crypto">Cryptocurrency</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={investmentForm.control}
                          name="investorNotes"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Notes (Optional)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Any additional notes or questions..."
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <Button 
                          type="submit" 
                          className="w-full"
                          disabled={investMutation.isPending}
                        >
                          {investMutation.isPending ? "Processing..." : "Submit Investment"}
                        </Button>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Fundraising Platform
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Discover and invest in promising startups, or launch your own fundraising campaign
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="campaigns">Active Campaigns</TabsTrigger>
            <TabsTrigger value="my-investments" disabled={!isAuthenticated}>
              My Investments
            </TabsTrigger>
            <TabsTrigger value="create" disabled={!isAuthenticated}>
              Create Campaign
            </TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="campaigns" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {campaignsLoading ? (
                [...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-white dark:bg-gray-800 rounded-lg h-80"></div>
                  </div>
                ))
              ) : campaigns.length > 0 ? (
                campaigns.map((campaign: any) => (
                  <CampaignCard key={campaign.id} campaign={campaign} />
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <TrendingUp className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    No Active Campaigns
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    Be the first to launch a fundraising campaign!
                  </p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="my-investments" className="mt-6">
            <div className="space-y-4">
              {myInvestments.length > 0 ? (
                myInvestments.map((investment: any) => (
                  <Card key={investment.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{investment.campaign.title}</CardTitle>
                          <CardDescription>
                            {investment.campaign.startup.name} • Invested: {formatCurrency(investment.amount)}
                          </CardDescription>
                        </div>
                        <Badge 
                          variant={investment.status === 'completed' ? 'default' : 'secondary'}
                        >
                          {investment.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Equity:</span>
                          <p className="font-semibold">{investment.equityPercentage}%</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Payment Method:</span>
                          <p className="font-semibold capitalize">{investment.paymentMethod}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Investment Date:</span>
                          <p className="font-semibold">
                            {format(new Date(investment.createdAt), 'MMM dd, yyyy')}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-12">
                  <DollarSign className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    No Investments Yet
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    Start investing in promising startups today!
                  </p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="create" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Create Fundraising Campaign</CardTitle>
                <CardDescription>
                  Launch a new fundraising campaign for your startup
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...campaignForm}>
                  <form onSubmit={campaignForm.handleSubmit(onCreateCampaign)} className="space-y-6">
                    <FormField
                      control={campaignForm.control}
                      name="startupId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Select Startup</FormLabel>
                          <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Choose your startup" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {userStartups.map((startup: any) => (
                                <SelectItem key={startup.id} value={startup.id.toString()}>
                                  {startup.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={campaignForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Campaign Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Seed Round for AI Revolution" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={campaignForm.control}
                        name="campaignType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Campaign Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="seed">Seed Round</SelectItem>
                                <SelectItem value="series-a">Series A</SelectItem>
                                <SelectItem value="series-b">Series B</SelectItem>
                                <SelectItem value="crowdfunding">Crowdfunding</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={campaignForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your fundraising opportunity..."
                              rows={4}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={campaignForm.control}
                        name="targetAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Target Amount ($)</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="1000000" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={campaignForm.control}
                        name="minimumInvestment"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Minimum Investment ($)</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="5000" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={campaignForm.control}
                        name="equityOffered"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Equity Offered (%)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.1" placeholder="20" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={campaignForm.control}
                        name="valuation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company Valuation ($)</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="5000000" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={campaignForm.control}
                        name="marketingPlan"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Marketing Plan (Optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="How will you promote this campaign?"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={campaignForm.control}
                      name="useOfFunds"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Use of Funds</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Explain how you will use the raised funds..."
                              rows={3}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={createCampaignMutation.isPending}
                    >
                      {createCampaignMutation.isPending ? "Creating..." : "Create Campaign"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Campaigns</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{campaigns.length}</div>
                  <div className="flex items-center text-xs text-green-600">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Active fundraising
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Raised</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(
                      campaigns.reduce((sum: number, c: any) => sum + parseFloat(c.raisedAmount), 0).toString()
                    )}
                  </div>
                  <div className="flex items-center text-xs text-blue-600">
                    <DollarSign className="w-3 h-3 mr-1" />
                    Across all campaigns
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">My Investments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{myInvestments.length}</div>
                  <div className="flex items-center text-xs text-purple-600">
                    <Heart className="w-3 h-3 mr-1" />
                    Portfolio size
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Success Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {campaigns.length > 0 
                      ? `${((campaigns.filter((c: any) => parseFloat(c.raisedAmount) >= parseFloat(c.targetAmount)).length / campaigns.length) * 100).toFixed(1)}%`
                      : "0%"
                    }
                  </div>
                  <div className="flex items-center text-xs text-green-600">
                    <Award className="w-3 h-3 mr-1" />
                    Fully funded
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}