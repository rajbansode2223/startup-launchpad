import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/header";
import StartupCard from "@/components/startup-card";
import FundingProgress from "@/components/funding-progress";
import MessageList from "@/components/message-list";
import {
  DollarSign,
  TrendingUp,
  Users,
  Presentation,
  Plus,
  Video,
  BarChart3,
  MessageSquare,
  Clock,
  Star,
} from "lucide-react";

export default function Dashboard() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  const { data: myStartupsData, isLoading: startupsLoading } = useQuery({
    queryKey: ["/api/startups/my"],
    enabled: !!user,
  });

  const { data: activeFundingRoundsData, isLoading: fundingLoading } = useQuery({
    queryKey: ["/api/funding-rounds/active"],
    enabled: !!user,
  });

  const { data: activePitchRoomsData, isLoading: pitchRoomsLoading } = useQuery({
    queryKey: ["/api/pitch-rooms/active"],
    enabled: !!user,
  });

  const { data: myMessagesData, isLoading: messagesLoading } = useQuery({
    queryKey: ["/api/messages/my"],
    enabled: !!user,
  });

  const { data: leaderboardData, isLoading: leaderboardLoading } = useQuery({
    queryKey: ["/api/leaderboard"],
    enabled: !!user,
  });

  // Investor-specific data queries
  const { data: myInvestmentsData, isLoading: investmentsLoading } = useQuery({
    queryKey: ["/api/investments/my"],
    enabled: !!user && (user as any)?.role === "investor",
  });

  const { data: portfolioStatsData, isLoading: portfolioLoading } = useQuery({
    queryKey: ["/api/investors/portfolio-stats"],
    enabled: !!user && (user as any)?.role === "investor",
  });

  // Safe data extraction with proper type checking
  const myStartups = Array.isArray(myStartupsData) ? myStartupsData : [];
  const activeFundingRounds = Array.isArray(activeFundingRoundsData) ? activeFundingRoundsData : [];
  const activePitchRooms = Array.isArray(activePitchRoomsData) ? activePitchRoomsData : [];
  const myMessages = Array.isArray(myMessagesData) ? myMessagesData : [];
  const leaderboard = Array.isArray(leaderboardData) ? leaderboardData : [];
  const myInvestments = Array.isArray(myInvestmentsData) ? myInvestmentsData : [];
  const portfolioStats = portfolioStatsData || {};

  const roleUpdateMutation = useMutation({
    mutationFn: async (role: "founder" | "investor") => {
      await apiRequest("POST", "/api/auth/role", { role });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Role Updated",
        description: "Your role has been updated successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update role. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const isFounder = (user as any)?.role === "founder";
  const dashboardTitle = isFounder ? "Founder Dashboard" : "Investor Dashboard";

  // Calculate stats for founders
  const totalValuation = myStartups.reduce((sum: number, startup: any) => 
    sum + (parseFloat(startup.valuation) || 0), 0
  );
  
  const activeInvestors = activeFundingRounds.reduce((sum: number, round: any) =>
    sum + (round.investments?.length || 0), 0
  );

  const avgPitchScore = (() => {
    const foundItem = leaderboard.find((item: any) => 
      myStartups.some((startup: any) => startup.id === item.id)
    );
    const rating = foundItem?.averageRating;
    return typeof rating === 'number' ? rating : 0;
  })();

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header 
        user={user} 
        onRoleChange={(role) => roleUpdateMutation.mutate(role)}
        isChangingRole={roleUpdateMutation.isPending}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold text-neutral-900">{dashboardTitle}</h1>
            {isFounder && (
              <Button 
                onClick={() => setLocation("/startup/new")}
                className="flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>Create Startup</span>
              </Button>
            )}
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {isFounder ? (
              <>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <DollarSign className="w-6 h-6 text-primary" />
                      </div>
                      <span className="text-2xl">💰</span>
                    </div>
                    <h3 className="text-2xl font-bold text-neutral-900 mb-1">
                      ${totalValuation.toLocaleString()}
                    </h3>
                    <p className="text-neutral-600 text-sm">Total Valuation</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-secondary" />
                      </div>
                      <span className="text-2xl">📈</span>
                    </div>
                    <h3 className="text-2xl font-bold text-neutral-900 mb-1">
                      {myStartups.length}
                    </h3>
                    <p className="text-neutral-600 text-sm">Active Startups</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <Users className="w-6 h-6 text-accent" />
                      </div>
                      <span className="text-2xl">👥</span>
                    </div>
                    <h3 className="text-2xl font-bold text-neutral-900 mb-1">
                      {activeInvestors}
                    </h3>
                    <p className="text-neutral-600 text-sm">Active Investors</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-amber-500/10 rounded-lg flex items-center justify-center">
                        <Presentation className="w-6 h-6 text-amber-500" />
                      </div>
                      <span className="text-2xl">🎯</span>
                    </div>
                    <h3 className="text-2xl font-bold text-neutral-900 mb-1">
                      {avgPitchScore.toFixed(1)}
                    </h3>
                    <p className="text-neutral-600 text-sm">Avg Pitch Score</p>
                  </CardContent>
                </Card>
              </>
            ) : (
              <>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <DollarSign className="w-6 h-6 text-primary" />
                      </div>
                      <span className="text-2xl">💰</span>
                    </div>
                    <h3 className="text-2xl font-bold text-neutral-900 mb-1">
                      ${(portfolioStats.totalInvested || 0).toLocaleString()}
                    </h3>
                    <p className="text-neutral-600 text-sm">Total Invested</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-secondary" />
                      </div>
                      <span className="text-2xl">📊</span>
                    </div>
                    <h3 className="text-2xl font-bold text-neutral-900 mb-1">
                      {portfolioStats.totalStartups || 0}
                    </h3>
                    <p className="text-neutral-600 text-sm">Portfolio Companies</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <Star className="w-6 h-6 text-accent" />
                      </div>
                      <span className="text-2xl">⭐</span>
                    </div>
                    <h3 className="text-2xl font-bold text-neutral-900 mb-1">
                      {portfolioStats.returnPercentage ? `${portfolioStats.returnPercentage.toFixed(1)}%` : '0.0%'}
                    </h3>
                    <p className="text-neutral-600 text-sm">Portfolio Return</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-amber-500/10 rounded-lg flex items-center justify-center">
                        <BarChart3 className="w-6 h-6 text-amber-500" />
                      </div>
                      <span className="text-2xl">📈</span>
                    </div>
                    <h3 className="text-2xl font-bold text-neutral-900 mb-1">
                      {portfolioStats.activeInvestments || 0}
                    </h3>
                    <p className="text-neutral-600 text-sm">Active Investments</p>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <Tabs defaultValue={isFounder ? "startups" : "opportunities"}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value={isFounder ? "startups" : "opportunities"}>
                  {isFounder ? "My Startups" : "Opportunities"}
                </TabsTrigger>
                <TabsTrigger value="funding">Funding Rounds</TabsTrigger>
                <TabsTrigger value="pitch-rooms">Pitch Rooms</TabsTrigger>
              </TabsList>

              <TabsContent value={isFounder ? "startups" : "opportunities"} className="space-y-4">
                {isFounder ? (
                  <Card>
                    <CardHeader>
                      <CardTitle>My Startups</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {startupsLoading ? (
                        <div className="space-y-4">
                          {[1, 2, 3].map((i) => (
                            <div key={i} className="h-24 bg-neutral-200 rounded-lg animate-pulse" />
                          ))}
                        </div>
                      ) : myStartups.length > 0 ? (
                        <div className="space-y-4">
                          {myStartups.map((startup: any) => (
                            <StartupCard key={startup.id} startup={startup} />
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <p className="text-neutral-600 mb-4">No startups created yet.</p>
                          <Button onClick={() => setLocation("/startup/new")}>
                            <Plus className="w-4 h-4 mr-2" />
                            Create Your First Startup
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Investment Opportunities</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {fundingLoading ? (
                        <div className="space-y-4">
                          {[1, 2, 3].map((i) => (
                            <div key={i} className="h-24 bg-neutral-200 rounded-lg animate-pulse" />
                          ))}
                        </div>
                      ) : activeFundingRounds.length > 0 ? (
                        <div className="space-y-4">
                          {activeFundingRounds.map((round: any) => (
                            <FundingProgress key={round.id} round={round} />
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <p className="text-neutral-600">No active funding rounds available.</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="funding" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Active Funding Rounds</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {fundingLoading ? (
                      <div className="space-y-4">
                        {[1, 2].map((i) => (
                          <div key={i} className="h-32 bg-neutral-200 rounded-lg animate-pulse" />
                        ))}
                      </div>
                    ) : activeFundingRounds.length > 0 ? (
                      <div className="space-y-4">
                        {activeFundingRounds.map((round: any) => (
                          <FundingProgress key={round.id} round={round} detailed />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-neutral-600">No active funding rounds.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="pitch-rooms" className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Active Pitch Rooms</CardTitle>
                      {isFounder && (
                        <Button variant="outline" size="sm">
                          <Video className="w-4 h-4 mr-2" />
                          New Pitch Room
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    {pitchRoomsLoading ? (
                      <div className="space-y-4">
                        {[1, 2].map((i) => (
                          <div key={i} className="h-24 bg-neutral-200 rounded-lg animate-pulse" />
                        ))}
                      </div>
                    ) : activePitchRooms.length > 0 ? (
                      <div className="space-y-4">
                        {activePitchRooms.map((room: any) => (
                          <div key={room.id} className="border border-neutral-200 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-2">
                                {room.status === "live" && (
                                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                                )}
                                <h3 className="font-semibold">{room.name}</h3>
                                <Badge variant={room.status === "live" ? "destructive" : "secondary"}>
                                  {room.status}
                                </Badge>
                              </div>
                              <Button size="sm" onClick={() => setLocation(`/pitch-room/${room.id}`)}>
                                {room.status === "live" ? "Join Live" : "View Details"}
                              </Button>
                            </div>
                            <p className="text-sm text-neutral-600">{room.description}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-neutral-600">No active pitch rooms.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Messages */}
            <MessageList messages={myMessages} isLoading={messagesLoading} />

            {/* Leaderboard */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5" />
                  <span>Top Startups</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {leaderboardLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="h-12 bg-neutral-200 rounded animate-pulse" />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {leaderboard.slice(0, 5).map((startup: any, index: number) => (
                      <div key={startup.id} className="flex items-center space-x-3">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                          index === 0 ? "bg-yellow-500" : 
                          index === 1 ? "bg-gray-400" :
                          index === 2 ? "bg-amber-600" : "bg-neutral-400"
                        }`}>
                          {index + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-neutral-900 truncate">
                            {startup.name}
                          </p>
                          <p className="text-xs text-neutral-600">
                            ${parseFloat(startup.totalFunding).toLocaleString()} raised
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-semibold text-secondary">
                            {typeof startup.averageRating === 'number' ? startup.averageRating.toFixed(1) : '0.0'}
                          </p>
                          <p className="text-xs text-neutral-600">score</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-gradient-to-br from-primary to-secondary text-white">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  {isFounder ? (
                    <>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start text-white hover:bg-white/20"
                        onClick={() => setLocation("/startup/new")}
                      >
                        <Plus className="w-4 h-4 mr-3" />
                        Create Startup
                      </Button>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start text-white hover:bg-white/20"
                      >
                        <Video className="w-4 h-4 mr-3" />
                        Schedule Pitch
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start text-white hover:bg-white/20"
                      >
                        <TrendingUp className="w-4 h-4 mr-3" />
                        Browse Startups
                      </Button>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start text-white hover:bg-white/20"
                      >
                        <BarChart3 className="w-4 h-4 mr-3" />
                        View Portfolio
                      </Button>
                    </>
                  )}
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-white hover:bg-white/20"
                    onClick={() => setLocation("/leaderboard")}
                  >
                    <TrendingUp className="w-4 h-4 mr-3" />
                    View Leaderboard
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
