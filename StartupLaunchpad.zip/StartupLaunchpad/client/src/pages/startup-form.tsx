import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useParams, useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Upload, ArrowLeft, Loader2 } from "lucide-react";

const startupFormSchema = z.object({
  name: z.string().min(1, "Company name is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  vision: z.string().min(10, "Vision must be at least 10 characters"),
  businessModel: z.string().min(10, "Business model must be at least 10 characters"),
  marketSize: z.string().min(10, "Market size must be at least 10 characters"),
  industry: z.string().min(1, "Industry is required"),
  stage: z.enum(["idea", "mvp", "seed", "seriesA", "seriesB", "growth"]),
  valuation: z.string().optional(),
  websiteUrl: z.string().url().optional().or(z.literal("")),
});

type StartupFormData = z.infer<typeof startupFormSchema>;

export default function StartupForm() {
  const { user, isLoading: authLoading } = useAuth();
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);

  const isEditing = !!id;

  // Redirect to home if not authenticated or not a founder
  useEffect(() => {
    if (!authLoading && (!user || user.role !== "founder")) {
      toast({
        title: "Unauthorized",
        description: "Only founders can create or edit startups.",
        variant: "destructive",
      });
      setLocation("/");
      return;
    }
  }, [user, authLoading, toast, setLocation]);

  const { data: startup, isLoading: startupLoading } = useQuery({
    queryKey: ["/api/startups", id],
    enabled: !!id && !!user,
  });

  const form = useForm<StartupFormData>({
    resolver: zodResolver(startupFormSchema),
    defaultValues: {
      name: "",
      description: "",
      vision: "",
      businessModel: "",
      marketSize: "",
      industry: "",
      stage: "idea",
      valuation: "",
      websiteUrl: "",
    },
  });

  // Populate form when editing
  useEffect(() => {
    if (startup && isEditing) {
      form.reset({
        name: startup.name,
        description: startup.description,
        vision: startup.vision,
        businessModel: startup.businessModel,
        marketSize: startup.marketSize,
        industry: startup.industry,
        stage: startup.stage,
        valuation: startup.valuation?.toString() || "",
        websiteUrl: startup.websiteUrl || "",
      });
    }
  }, [startup, form, isEditing]);

  const createMutation = useMutation({
    mutationFn: async (data: StartupFormData) => {
      const response = await apiRequest("POST", "/api/startups", data);
      return response.json();
    },
    onSuccess: (newStartup) => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups/my"] });
      toast({
        title: "Success",
        description: "Startup created successfully!",
      });
      
      // Upload pitch deck if file is selected
      if (selectedFile) {
        uploadPitchDeck(newStartup.id);
      } else {
        setLocation("/");
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create startup. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: StartupFormData) => {
      const response = await apiRequest("PATCH", `/api/startups/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups/my"] });
      queryClient.invalidateQueries({ queryKey: ["/api/startups", id] });
      toast({
        title: "Success",
        description: "Startup updated successfully!",
      });
      
      // Upload pitch deck if file is selected
      if (selectedFile) {
        uploadPitchDeck(parseInt(id!));
      } else {
        setLocation("/");
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update startup. Please try again.",
        variant: "destructive",
      });
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (startupId: number) => {
      const formData = new FormData();
      formData.append("pitchDeck", selectedFile!);
      
      const response = await fetch(`/api/startups/${startupId}/pitch-deck`, {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Upload failed");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Pitch deck uploaded successfully!",
      });
      setLocation("/");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to upload pitch deck. Please try again.",
        variant: "destructive",
      });
    },
  });

  const uploadPitchDeck = (startupId: number) => {
    uploadMutation.mutate(startupId);
  };

  const onSubmit = (data: StartupFormData) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type !== "application/pdf") {
        toast({
          title: "Invalid File",
          description: "Please select a PDF file.",
          variant: "destructive",
        });
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please select a file smaller than 10MB.",
          variant: "destructive",
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  if (authLoading || (isEditing && startupLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user || user.role !== "founder") {
    return null;
  }

  const isLoading = createMutation.isPending || updateMutation.isPending || uploadMutation.isPending;

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header user={user} />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-neutral-900">
            {isEditing ? "Edit Startup" : "Create New Startup"}
          </h1>
          <p className="text-neutral-600 mt-2">
            {isEditing 
              ? "Update your startup information and pitch deck."
              : "Build your startup profile and upload your pitch deck to attract investors."
            }
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Startup Information</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., TechFlow AI" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="industry"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Industry</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Artificial Intelligence" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="stage"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Stage</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select startup stage" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="idea">Idea Stage</SelectItem>
                            <SelectItem value="mvp">MVP</SelectItem>
                            <SelectItem value="seed">Seed</SelectItem>
                            <SelectItem value="seriesA">Series A</SelectItem>
                            <SelectItem value="seriesB">Series B</SelectItem>
                            <SelectItem value="growth">Growth</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="valuation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Valuation (USD)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., 5000000" type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Brief description of your company and what it does..."
                          className="min-h-[100px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="vision"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vision</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Your company's vision and long-term goals..."
                          className="min-h-[100px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="businessModel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Business Model</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="How your company makes money and operates..."
                          className="min-h-[100px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="marketSize"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Market Size & Opportunity</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Total addressable market, target market size, and growth potential..."
                          className="min-h-[100px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="websiteUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Website URL (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="https://yourcompany.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Pitch Deck Upload */}
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-neutral-900">
                      Pitch Deck (PDF)
                    </label>
                    <p className="text-sm text-neutral-600">
                      Upload your pitch deck to attract investors. Max file size: 10MB.
                    </p>
                  </div>
                  
                  <div className="border-2 border-dashed border-neutral-300 rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
                    <input
                      type="file"
                      accept=".pdf"
                      onChange={handleFileChange}
                      className="hidden"
                      id="pitch-deck-upload"
                    />
                    <label htmlFor="pitch-deck-upload" className="cursor-pointer">
                      <Upload className="w-8 h-8 text-neutral-400 mx-auto mb-2" />
                      <p className="text-sm text-neutral-600">
                        {selectedFile ? selectedFile.name : "Click to upload pitch deck"}
                      </p>
                      <p className="text-xs text-neutral-500 mt-1">
                        PDF files only, up to 10MB
                      </p>
                    </label>
                  </div>
                </div>

                <div className="flex items-center justify-end space-x-4 pt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setLocation("/")}
                    disabled={isLoading}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    {isEditing ? "Update Startup" : "Create Startup"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
