import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  Lightbulb, 
  BarChart3, 
  Zap, 
  Rocket,
  CheckCircle,
  AlertCircle,
  Star,
  ArrowRight,
  Plus,
  Loader2
} from "lucide-react";

export default function AIDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("cofounder");

  // Co-Founder Assistant State
  const [cofounderForm, setCofounderForm] = useState({
    skills: "",
    industry: "",
    experience: ""
  });

  // Validation Engine State
  const [validationForm, setValidationForm] = useState({
    startupIdea: "",
    targetMarket: "",
    industry: ""
  });

  // Growth Stack State
  const [growthForm, setGrowthForm] = useState({
    productType: "",
    brandVoice: "",
    targetAudience: "",
    goals: ""
  });

  // Co-Founder Assistant Mutations
  const cofounderRecommendations = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/cofounder/profile-recommendations", {
        skills: data.skills.split(",").map((s: string) => s.trim()),
        industry: data.industry,
        experience: data.experience
      });
    }
  });

  const compatibilityAnalysis = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/cofounder/compatibility", data);
    }
  });

  const teamDynamics = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/cofounder/team-dynamics", data);
    }
  });

  // Validation Engine Mutations
  const validationFramework = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/validation/framework", data);
    }
  });

  const experimentAnalysis = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/validation/experiment-analysis", data);
    }
  });

  const productMarketFit = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/validation/product-market-fit", data);
    }
  });

  // Investor Pulse Queries
  const { data: marketInsights } = useQuery({
    queryKey: ["/api/ai/investor/market-insights"],
    enabled: user?.role === "investor"
  });

  const { data: portfolioMetrics } = useQuery({
    queryKey: ["/api/ai/investor/portfolio-metrics"],
    enabled: user?.role === "investor"
  });

  // Growth Stack Mutations
  const growthStrategy = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/growth/strategy", data);
    }
  });

  const contentStrategy = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/growth/content-strategy", {
        brandVoice: data.brandVoice,
        targetAudience: data.targetAudience,
        goals: data.goals.split(",").map((g: string) => g.trim())
      });
    }
  });

  const viralMechanisms = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/ai/growth/viral-mechanisms", data);
    }
  });

  const handleCofounderSubmit = () => {
    if (cofounderForm.skills && cofounderForm.industry && cofounderForm.experience) {
      cofounderRecommendations.mutate(cofounderForm);
    }
  };

  const handleValidationSubmit = () => {
    if (validationForm.startupIdea && validationForm.targetMarket && validationForm.industry) {
      validationFramework.mutate(validationForm);
    }
  };

  const handleGrowthSubmit = () => {
    if (growthForm.brandVoice && growthForm.targetAudience && growthForm.goals) {
      contentStrategy.mutate(growthForm);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          AI-Powered Startup Intelligence
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          Leverage advanced AI tools to optimize your startup journey from co-founder matching to growth scaling
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="cofounder" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Co-Founder AI
          </TabsTrigger>
          <TabsTrigger value="validation" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Lean Validation
          </TabsTrigger>
          <TabsTrigger value="investor" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Investor Pulse
          </TabsTrigger>
          <TabsTrigger value="growth" className="flex items-center gap-2">
            <Rocket className="h-4 w-4" />
            Growth Stack
          </TabsTrigger>
        </TabsList>

        {/* AI Co-Founder Assistant */}
        <TabsContent value="cofounder" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Co-Founder Profile Generator
                </CardTitle>
                <CardDescription>
                  Get AI-powered recommendations for ideal co-founder profiles based on your skills and startup needs
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="skills">Your Skills (comma-separated)</Label>
                  <Input
                    id="skills"
                    placeholder="e.g. React, Python, Marketing, Design"
                    value={cofounderForm.skills}
                    onChange={(e) => setCofounderForm(prev => ({...prev, skills: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="industry">Industry</Label>
                  <Select onValueChange={(value) => setCofounderForm(prev => ({...prev, industry: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fintech">FinTech</SelectItem>
                      <SelectItem value="healthtech">HealthTech</SelectItem>
                      <SelectItem value="edtech">EdTech</SelectItem>
                      <SelectItem value="ecommerce">E-commerce</SelectItem>
                      <SelectItem value="saas">SaaS</SelectItem>
                      <SelectItem value="ai">AI/ML</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="experience">Experience Level</Label>
                  <Textarea
                    id="experience"
                    placeholder="Describe your startup and professional experience"
                    value={cofounderForm.experience}
                    onChange={(e) => setCofounderForm(prev => ({...prev, experience: e.target.value}))}
                  />
                </div>
                <Button 
                  onClick={handleCofounderSubmit}
                  disabled={cofounderRecommendations.isPending}
                  className="w-full"
                >
                  {cofounderRecommendations.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Lightbulb className="h-4 w-4 mr-2" />
                  )}
                  Generate Recommendations
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Co-Founder Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                {cofounderRecommendations.isPending && (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                )}
                {cofounderRecommendations.data?.profiles && (
                  <ScrollArea className="h-80">
                    <div className="space-y-4">
                      {cofounderRecommendations.data.profiles.map((profile: any, index: number) => (
                        <div key={index} className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold">{profile.title}</h4>
                            <Badge variant={profile.priority === 'high' ? 'destructive' : profile.priority === 'medium' ? 'default' : 'secondary'}>
                              {profile.priority}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                            {profile.reasoning}
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {profile.skills?.map((skill: string, idx: number) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
                {!cofounderRecommendations.data && !cofounderRecommendations.isPending && (
                  <div className="text-center py-8 text-gray-500">
                    Fill out the form to get AI-powered co-founder recommendations
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Lean Validation Engine */}
        <TabsContent value="validation" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Validation Framework Generator
                </CardTitle>
                <CardDescription>
                  Create systematic validation plans using lean startup methodology
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="startupIdea">Startup Idea</Label>
                  <Textarea
                    id="startupIdea"
                    placeholder="Describe your startup idea in detail"
                    value={validationForm.startupIdea}
                    onChange={(e) => setValidationForm(prev => ({...prev, startupIdea: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="targetMarket">Target Market</Label>
                  <Input
                    id="targetMarket"
                    placeholder="e.g. Small business owners, College students"
                    value={validationForm.targetMarket}
                    onChange={(e) => setValidationForm(prev => ({...prev, targetMarket: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="validationIndustry">Industry</Label>
                  <Select onValueChange={(value) => setValidationForm(prev => ({...prev, industry: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fintech">FinTech</SelectItem>
                      <SelectItem value="healthtech">HealthTech</SelectItem>
                      <SelectItem value="edtech">EdTech</SelectItem>
                      <SelectItem value="ecommerce">E-commerce</SelectItem>
                      <SelectItem value="saas">SaaS</SelectItem>
                      <SelectItem value="ai">AI/ML</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button 
                  onClick={handleValidationSubmit}
                  disabled={validationFramework.isPending}
                  className="w-full"
                >
                  {validationFramework.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <CheckCircle className="h-4 w-4 mr-2" />
                  )}
                  Generate Validation Plan
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Validation Framework</CardTitle>
              </CardHeader>
              <CardContent>
                {validationFramework.isPending && (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                )}
                {validationFramework.data && (
                  <ScrollArea className="h-80">
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold mb-2">Key Hypotheses</h4>
                        {validationFramework.data.hypotheses?.map((hypothesis: any, index: number) => (
                          <div key={index} className="p-3 border rounded mb-2">
                            <div className="flex items-center justify-between mb-1">
                              <Badge variant="outline">{hypothesis.type}</Badge>
                              <Badge variant={hypothesis.riskLevel === 'high' ? 'destructive' : 'default'}>
                                {hypothesis.riskLevel} risk
                              </Badge>
                            </div>
                            <p className="text-sm mb-2">{hypothesis.hypothesis}</p>
                            <p className="text-xs text-gray-600">
                              Success: {hypothesis.successCriteria}
                            </p>
                          </div>
                        ))}
                      </div>
                      
                      {validationFramework.data.mvpRecommendations && (
                        <div>
                          <h4 className="font-semibold mb-2">MVP Recommendations</h4>
                          <ul className="space-y-1">
                            {validationFramework.data.mvpRecommendations.map((rec: string, index: number) => (
                              <li key={index} className="text-sm flex items-start gap-2">
                                <ArrowRight className="h-3 w-3 mt-1 text-blue-500" />
                                {rec}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                )}
                {!validationFramework.data && !validationFramework.isPending && (
                  <div className="text-center py-8 text-gray-500">
                    Generate a validation framework to see your lean startup roadmap
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Investor Pulse Dashboard */}
        <TabsContent value="investor" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Market Insights
                </CardTitle>
                <CardDescription>
                  Real-time market trends and investment opportunities
                </CardDescription>
              </CardHeader>
              <CardContent>
                {marketInsights ? (
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Hot Sectors</h4>
                      <div className="flex flex-wrap gap-2">
                        {marketInsights.marketOverview?.hotSectors?.map((sector: string, index: number) => (
                          <Badge key={index} variant="default">{sector}</Badge>
                        ))}
                      </div>
                    </div>
                    <Separator />
                    <div>
                      <h4 className="font-semibold mb-2">Emerging Trends</h4>
                      <ul className="space-y-1">
                        {marketInsights.marketOverview?.emergingTrends?.map((trend: string, index: number) => (
                          <li key={index} className="text-sm flex items-start gap-2">
                            <TrendingUp className="h-3 w-3 mt-1 text-green-500" />
                            {trend}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <Separator />
                    <div>
                      <h4 className="font-semibold mb-2">Investment Opportunities</h4>
                      {marketInsights.investmentOpportunities?.slice(0, 3).map((opp: any, index: number) => (
                        <div key={index} className="p-3 border rounded mb-2">
                          <div className="flex items-center justify-between mb-1">
                            <p className="font-medium text-sm">{opp.opportunity}</p>
                            <Badge variant={opp.riskLevel === 'low' ? 'default' : 'secondary'}>
                              {opp.riskLevel} risk
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-600">{opp.reasoning}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <BarChart3 className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    Loading market insights...
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  Portfolio Performance
                </CardTitle>
                <CardDescription>
                  AI-powered portfolio analysis and metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                {portfolioMetrics ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded">
                        <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                          ${portfolioMetrics.portfolioValue?.toLocaleString() || '0'}
                        </p>
                        <p className="text-xs text-green-600 dark:text-green-400">Portfolio Value</p>
                      </div>
                      <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded">
                        <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                          {portfolioMetrics.multipleOnInvested?.toFixed(2) || '0.0'}x
                        </p>
                        <p className="text-xs text-blue-600 dark:text-blue-400">Multiple on Invested</p>
                      </div>
                    </div>
                    
                    {portfolioMetrics.portfolioComposition && (
                      <div>
                        <h4 className="font-semibold mb-2">Sector Allocation</h4>
                        {portfolioMetrics.portfolioComposition.map((comp: any, index: number) => (
                          <div key={index} className="mb-2">
                            <div className="flex justify-between text-sm mb-1">
                              <span>{comp.sector}</span>
                              <span>{comp.allocation}</span>
                            </div>
                            <Progress value={parseFloat(comp.allocation)} className="h-2" />
                          </div>
                        ))}
                      </div>
                    )}

                    {portfolioMetrics.topPerformers && (
                      <div>
                        <h4 className="font-semibold mb-2">Top Performers</h4>
                        <div className="space-y-1">
                          {portfolioMetrics.topPerformers.slice(0, 3).map((performer: string, index: number) => (
                            <div key={index} className="flex items-center gap-2 text-sm">
                              <Star className="h-3 w-3 text-yellow-500" />
                              {performer}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Star className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    Loading portfolio metrics...
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Growth Stack */}
        <TabsContent value="growth" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Growth Strategy Generator
                </CardTitle>
                <CardDescription>
                  AI-powered growth tactics and content strategies
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="brandVoice">Brand Voice</Label>
                  <Select onValueChange={(value) => setGrowthForm(prev => ({...prev, brandVoice: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select brand voice" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="friendly">Friendly</SelectItem>
                      <SelectItem value="innovative">Innovative</SelectItem>
                      <SelectItem value="authoritative">Authoritative</SelectItem>
                      <SelectItem value="casual">Casual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="targetAudience">Target Audience</Label>
                  <Input
                    id="targetAudience"
                    placeholder="e.g. Tech-savvy millennials, Enterprise decision makers"
                    value={growthForm.targetAudience}
                    onChange={(e) => setGrowthForm(prev => ({...prev, targetAudience: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="goals">Growth Goals (comma-separated)</Label>
                  <Input
                    id="goals"
                    placeholder="e.g. Increase user acquisition, Improve retention, Build brand awareness"
                    value={growthForm.goals}
                    onChange={(e) => setGrowthForm(prev => ({...prev, goals: e.target.value}))}
                  />
                </div>
                <Button 
                  onClick={handleGrowthSubmit}
                  disabled={contentStrategy.isPending}
                  className="w-full"
                >
                  {contentStrategy.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Rocket className="h-4 w-4 mr-2" />
                  )}
                  Generate Growth Strategy
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Content & Growth Strategy</CardTitle>
              </CardHeader>
              <CardContent>
                {contentStrategy.isPending && (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                )}
                {contentStrategy.data && (
                  <ScrollArea className="h-80">
                    <div className="space-y-4">
                      {contentStrategy.data.contentPillars && (
                        <div>
                          <h4 className="font-semibold mb-2">Content Pillars</h4>
                          {contentStrategy.data.contentPillars.map((pillar: any, index: number) => (
                            <div key={index} className="p-3 border rounded mb-2">
                              <h5 className="font-medium mb-1">{pillar.pillar}</h5>
                              <p className="text-sm text-gray-600 mb-2">{pillar.description}</p>
                              <div className="flex flex-wrap gap-1">
                                {pillar.contentTypes?.map((type: string, idx: number) => (
                                  <Badge key={idx} variant="outline" className="text-xs">
                                    {type}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {contentStrategy.data.seoStrategy && (
                        <div>
                          <h4 className="font-semibold mb-2">SEO Strategy</h4>
                          <div className="p-3 border rounded">
                            <p className="text-sm mb-2">Target Keywords:</p>
                            <div className="flex flex-wrap gap-1">
                              {contentStrategy.data.seoStrategy.targetKeywords?.map((keyword: string, index: number) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {keyword}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {contentStrategy.data.engagementTactics && (
                        <div>
                          <h4 className="font-semibold mb-2">Engagement Tactics</h4>
                          <ul className="space-y-1">
                            {contentStrategy.data.engagementTactics.map((tactic: string, index: number) => (
                              <li key={index} className="text-sm flex items-start gap-2">
                                <Plus className="h-3 w-3 mt-1 text-green-500" />
                                {tactic}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                )}
                {!contentStrategy.data && !contentStrategy.isPending && (
                  <div className="text-center py-8 text-gray-500">
                    Configure your growth parameters to get AI-powered strategies
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}