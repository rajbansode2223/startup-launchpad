import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MessageCircle, Users, Send, Check, X, Clock, Plus } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function Chat() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeConversation, setActiveConversation] = useState<number | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [showConnectionRequest, setShowConnectionRequest] = useState(false);
  const [connectionTarget, setConnectionTarget] = useState("");
  const [connectionMessage, setConnectionMessage] = useState("");

  // Fetch user connections
  const { data: connections = [] } = useQuery({
    queryKey: ["/api/chat/connections"],
  });

  // Fetch conversations
  const { data: conversations = [] } = useQuery({
    queryKey: ["/api/chat/conversations"],
  });

  // Fetch messages for active conversation
  const { data: messages = [] } = useQuery({
    queryKey: ["/api/chat/conversations", activeConversation, "messages"],
    enabled: !!activeConversation,
  });

  // Fetch notifications
  const { data: notifications = [] } = useQuery({
    queryKey: ["/api/chat/notifications"],
    refetchInterval: 5000, // Poll every 5 seconds
  });

  // Send connection request
  const connectionMutation = useMutation({
    mutationFn: async (data: { targetId: string; requestMessage: string; connectionType: string }) => {
      return apiRequest("POST", "/api/chat/connections", data);
    },
    onSuccess: () => {
      toast({
        title: "Connection Request Sent",
        description: "Your connection request has been sent successfully.",
      });
      setShowConnectionRequest(false);
      setConnectionTarget("");
      setConnectionMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/chat/connections"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send connection request. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update connection status
  const updateConnectionMutation = useMutation({
    mutationFn: async ({ id, status, responseMessage }: { id: number; status: string; responseMessage?: string }) => {
      return apiRequest("PUT", `/api/chat/connections/${id}`, { status, responseMessage });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/chat/conversations"] });
    },
  });

  // Send message
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { content: string; messageType?: string }) => {
      return apiRequest("POST", `/api/chat/conversations/${activeConversation}/messages`, data);
    },
    onSuccess: () => {
      setNewMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/chat/conversations", activeConversation, "messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/chat/conversations"] });
    },
  });

  const handleSendMessage = () => {
    if (!newMessage.trim() || !activeConversation) return;
    
    sendMessageMutation.mutate({
      content: newMessage,
      messageType: "text",
    });
  };

  const handleConnectionRequest = () => {
    if (!connectionTarget || !connectionMessage.trim()) return;
    
    connectionMutation.mutate({
      targetId: connectionTarget,
      requestMessage: connectionMessage,
      connectionType: "chat",
    });
  };

  const handleConnectionResponse = (connectionId: number, status: string, responseMessage?: string) => {
    updateConnectionMutation.mutate({
      id: connectionId,
      status,
      responseMessage,
    });
  };

  const getOtherUser = (connection: any) => {
    return connection.requesterId === user?.id ? connection.target : connection.requester;
  };

  const unreadNotifications = notifications.filter((n: any) => !n.isRead);

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center gap-4 mb-6">
        <MessageCircle className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">Chat</h1>
          <p className="text-muted-foreground">Connect and message with other users</p>
        </div>
        {unreadNotifications.length > 0 && (
          <Badge variant="destructive" className="ml-auto">
            {unreadNotifications.length} new
          </Badge>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Connections & Conversations Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          {/* New Connection Button */}
          <Button 
            onClick={() => setShowConnectionRequest(true)}
            className="w-full"
            variant="outline"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Connection
          </Button>

          {/* Connection Requests */}
          {connections.filter((c: any) => c.status === "pending").length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Pending Requests</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {connections
                  .filter((c: any) => c.status === "pending")
                  .map((connection: any) => {
                    const otherUser = getOtherUser(connection);
                    const isIncoming = connection.targetId === user?.id;
                    
                    return (
                      <div key={connection.id} className="p-3 border rounded-lg">
                        <div className="flex items-center gap-3 mb-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={otherUser.profileImageUrl} />
                            <AvatarFallback>
                              {otherUser.firstName?.[0]}{otherUser.lastName?.[0]}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="font-medium text-sm">
                              {otherUser.firstName} {otherUser.lastName}
                            </p>
                            <Badge variant="secondary" className="text-xs">
                              {otherUser.role}
                            </Badge>
                          </div>
                        </div>
                        
                        {connection.requestMessage && (
                          <p className="text-sm text-muted-foreground mb-3">
                            "{connection.requestMessage}"
                          </p>
                        )}
                        
                        {isIncoming ? (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => handleConnectionResponse(connection.id, "approved")}
                              disabled={updateConnectionMutation.isPending}
                            >
                              <Check className="h-4 w-4 mr-1" />
                              Accept
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleConnectionResponse(connection.id, "rejected")}
                              disabled={updateConnectionMutation.isPending}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Decline
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Clock className="h-4 w-4" />
                            Waiting for response
                          </div>
                        )}
                      </div>
                    );
                  })}
              </CardContent>
            </Card>
          )}

          {/* Active Conversations */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Conversations</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                {conversations.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No conversations yet
                  </p>
                ) : (
                  <div className="space-y-2">
                    {conversations.map((conversation: any) => {
                      const otherUser = getOtherUser(conversation.connection);
                      
                      return (
                        <div
                          key={conversation.id}
                          className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                            activeConversation === conversation.id
                              ? "bg-primary/10 border-primary"
                              : "hover:bg-muted"
                          }`}
                          onClick={() => setActiveConversation(conversation.id)}
                        >
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={otherUser.profileImageUrl} />
                              <AvatarFallback>
                                {otherUser.firstName?.[0]}{otherUser.lastName?.[0]}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm truncate">
                                {otherUser.firstName} {otherUser.lastName}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {conversation.lastMessageAt 
                                  ? format(new Date(conversation.lastMessageAt), "MMM d, HH:mm")
                                  : "No messages yet"
                                }
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-2">
          {activeConversation ? (
            <Card className="h-[600px] flex flex-col">
              <CardHeader className="flex-shrink-0">
                <div className="flex items-center gap-3">
                  {(() => {
                    const conversation = conversations.find((c: any) => c.id === activeConversation);
                    if (!conversation) return null;
                    const otherUser = getOtherUser(conversation.connection);
                    
                    return (
                      <>
                        <Avatar>
                          <AvatarImage src={otherUser.profileImageUrl} />
                          <AvatarFallback>
                            {otherUser.firstName?.[0]}{otherUser.lastName?.[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-lg">
                            {otherUser.firstName} {otherUser.lastName}
                          </CardTitle>
                          <CardDescription>
                            {otherUser.role} • {otherUser.email}
                          </CardDescription>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </CardHeader>
              
              <Separator />
              
              <CardContent className="flex-1 flex flex-col p-0">
                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  {messages.length === 0 ? (
                    <div className="text-center py-8">
                      <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">Start your conversation</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {messages.map((message: any) => {
                        const isOwn = message.senderId === user?.id;
                        
                        return (
                          <div
                            key={message.id}
                            className={`flex ${isOwn ? "justify-end" : "justify-start"}`}
                          >
                            <div
                              className={`max-w-[70%] p-3 rounded-lg ${
                                isOwn
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-muted"
                              }`}
                            >
                              <p className="text-sm">{message.content}</p>
                              <p className={`text-xs mt-1 ${
                                isOwn ? "text-primary-foreground/70" : "text-muted-foreground"
                              }`}>
                                {format(new Date(message.createdAt), "HH:mm")}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </ScrollArea>
                
                {/* Message Input */}
                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      disabled={sendMessageMutation.isPending}
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim() || sendMessageMutation.isPending}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="h-[600px] flex items-center justify-center">
              <div className="text-center">
                <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Select a conversation</h3>
                <p className="text-muted-foreground">
                  Choose a conversation from the sidebar to start chatting
                </p>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* New Connection Dialog */}
      {showConnectionRequest && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Send Connection Request</CardTitle>
              <CardDescription>
                Send a connection request to start chatting with another user
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">User ID or Email</label>
                <Input
                  placeholder="Enter user ID or email"
                  value={connectionTarget}
                  onChange={(e) => setConnectionTarget(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Message</label>
                <Textarea
                  placeholder="Why would you like to connect?"
                  value={connectionMessage}
                  onChange={(e) => setConnectionMessage(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  onClick={() => setShowConnectionRequest(false)}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleConnectionRequest}
                  disabled={!connectionTarget || !connectionMessage.trim() || connectionMutation.isPending}
                >
                  Send Request
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}