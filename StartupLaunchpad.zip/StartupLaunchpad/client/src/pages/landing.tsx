import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { queryClient } from "@/lib/queryClient";
import { Rocket, Users, TrendingUp, MessageSquare, Trophy, Star } from "lucide-react";

export default function Landing() {
  const handleDevLogin = async (role: "founder" | "investor") => {
    try {
      const response = await fetch('/api/auth/dev-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: `${role}@example.com`, 
          role 
        }),
        credentials: 'include'
      });
      
      if (response.ok) {
        queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
        window.location.reload();
      }
    } catch (error) {
      console.error('Dev login failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b border-neutral-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <Rocket className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-neutral-900">LaunchPad</span>
            </div>
            <Button onClick={() => window.location.href = "/api/login"}>
              Get Started
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-neutral-900 mb-6">
            Turn Your <span className="text-primary">Startup Dreams</span> Into Reality
          </h1>
          <p className="text-xl text-neutral-600 mb-8 max-w-2xl mx-auto">
            Join the premier startup funding simulation platform where founders pitch ideas and investors discover the next big thing. Practice, learn, and connect in a risk-free environment.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={() => handleDevLogin("founder")}>
              <Rocket className="w-5 h-5 mr-2" />
              Start as Founder
            </Button>
            <Button size="lg" variant="outline" onClick={() => handleDevLogin("investor")}>
              <TrendingUp className="w-5 h-5 mr-2" />
              Invest & Discover
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-neutral-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">
              Everything You Need to Succeed
            </h2>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              From pitch creation to funding simulation, we provide all the tools for startup success.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Startup Builder */}
            <Card className="startup-card border-0 shadow-md">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Rocket className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  Startup Profile Builder
                </h3>
                <p className="text-neutral-600 mb-4">
                  Create comprehensive startup profiles with vision, business model, market analysis, and pitch decks.
                </p>
                <ul className="space-y-2 text-sm text-neutral-600">
                  <li>• PDF pitch deck uploads</li>
                  <li>• Business model canvas</li>
                  <li>• Market size analysis</li>
                  <li>• Team profiles</li>
                </ul>
              </CardContent>
            </Card>

            {/* Funding Simulation */}
            <Card className="startup-card border-0 shadow-md">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-secondary" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  Funding Simulation
                </h3>
                <p className="text-neutral-600 mb-4">
                  Simulate real funding rounds with investors, negotiate terms, and track cap table evolution.
                </p>
                <ul className="space-y-2 text-sm text-neutral-600">
                  <li>• Multiple funding rounds</li>
                  <li>• Real-time negotiations</li>
                  <li>• Cap table tracking</li>
                  <li>• Valuation modeling</li>
                </ul>
              </CardContent>
            </Card>

            {/* Pitch Rooms */}
            <Card className="startup-card border-0 shadow-md">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <MessageSquare className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  Live Pitch Rooms
                </h3>
                <p className="text-neutral-600 mb-4">
                  Host virtual pitch sessions with real-time chat and document sharing capabilities.
                </p>
                <ul className="space-y-2 text-sm text-neutral-600">
                  <li>• Live video presentations</li>
                  <li>• Real-time Q&A</li>
                  <li>• Document viewer</li>
                  <li>• Session recording</li>
                </ul>
              </CardContent>
            </Card>

            {/* Scoring System */}
            <Card className="startup-card border-0 shadow-md">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-amber-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Star className="w-6 h-6 text-amber-500" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  Scoring & Feedback
                </h3>
                <p className="text-neutral-600 mb-4">
                  Get detailed feedback from investors on team, product, and market potential.
                </p>
                <ul className="space-y-2 text-sm text-neutral-600">
                  <li>• Multi-dimensional scoring</li>
                  <li>• Detailed feedback</li>
                  <li>• Performance analytics</li>
                  <li>• Improvement suggestions</li>
                </ul>
              </CardContent>
            </Card>

            {/* Network */}
            <Card className="startup-card border-0 shadow-md">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  Investor Network
                </h3>
                <p className="text-neutral-600 mb-4">
                  Connect with a diverse network of angel investors and VCs looking for opportunities.
                </p>
                <ul className="space-y-2 text-sm text-neutral-600">
                  <li>• Verified investor profiles</li>
                  <li>• Direct messaging</li>
                  <li>• Investment preferences</li>
                  <li>• Deal flow management</li>
                </ul>
              </CardContent>
            </Card>

            {/* Leaderboards */}
            <Card className="startup-card border-0 shadow-md">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Trophy className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  Leaderboards & Challenges
                </h3>
                <p className="text-neutral-600 mb-4">
                  Compete with other startups and climb the rankings based on various metrics.
                </p>
                <ul className="space-y-2 text-sm text-neutral-600">
                  <li>• Startup rankings</li>
                  <li>• Monthly challenges</li>
                  <li>• Achievement system</li>
                  <li>• Community recognition</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-neutral-900 mb-6">
            Ready to Launch Your Journey?
          </h2>
          <p className="text-lg text-neutral-600 mb-8">
            Join thousands of founders and investors already using LaunchPad to practice, learn, and grow.
          </p>
          <Button size="lg" onClick={() => window.location.href = "/api/login"}>
            Get Started for Free
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <Rocket className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">LaunchPad</span>
            </div>
            <p className="text-neutral-400">
              © 2024 LaunchPad. Building the future of startup funding.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
