import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import Header from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Trophy, 
  TrendingUp, 
  DollarSign, 
  Star, 
  Medal,
  Crown,
  Award,
  Users,
  Target,
  Zap
} from "lucide-react";

export default function Leaderboard() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  const { data: leaderboard = [], isLoading: leaderboardLoading } = useQuery({
    queryKey: ["/api/leaderboard"],
    enabled: !!user,
  });

  const { data: allStartups = [], isLoading: startupsLoading } = useQuery({
    queryKey: ["/api/startups"],
    enabled: !!user,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const getRankIcon = (position: number) => {
    switch (position) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-amber-600" />;
      default:
        return (
          <div className="w-6 h-6 bg-neutral-400 rounded-full flex items-center justify-center text-white text-sm font-bold">
            {position}
          </div>
        );
    }
  };

  const getRankBadgeColor = (position: number) => {
    switch (position) {
      case 1:
        return "bg-gradient-to-r from-yellow-400 to-yellow-600";
      case 2:
        return "bg-gradient-to-r from-gray-300 to-gray-500";
      case 3:
        return "bg-gradient-to-r from-amber-400 to-amber-600";
      default:
        return "bg-gradient-to-r from-neutral-400 to-neutral-600";
    }
  };

  // Group startups by different metrics
  const topByFunding = [...leaderboard].sort((a, b) => 
    parseFloat(b.totalFunding) - parseFloat(a.totalFunding)
  );

  const topByRating = [...leaderboard].sort((a, b) => 
    b.averageRating - a.averageRating
  );

  const newestStartups = [...allStartups]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 10);

  const renderStartupCard = (startup: any, position: number, metric: string) => (
    <Card key={startup.id} className="startup-card">
      <CardContent className="p-6">
        <div className="flex items-center space-x-4">
          {/* Rank */}
          <div className="flex-shrink-0">
            {position <= 3 ? (
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getRankBadgeColor(position)}`}>
                {getRankIcon(position)}
              </div>
            ) : (
              <div className="w-12 h-12 bg-neutral-100 rounded-full flex items-center justify-center">
                <span className="text-neutral-600 font-bold text-lg">{position}</span>
              </div>
            )}
          </div>

          {/* Startup Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-2">
              <h3 className="font-semibold text-neutral-900 truncate">{startup.name}</h3>
              <Badge variant="outline" className="capitalize">
                {startup.stage}
              </Badge>
            </div>
            <p className="text-sm text-neutral-600 mb-2 line-clamp-1">
              {startup.description}
            </p>
            <div className="flex items-center space-x-4 text-sm">
              <span className="text-neutral-500">{startup.industry}</span>
              {startup.valuation && (
                <span className="text-neutral-500">
                  ${parseFloat(startup.valuation).toLocaleString()} valuation
                </span>
              )}
            </div>
          </div>

          {/* Metric Value */}
          <div className="text-right">
            {metric === "funding" && (
              <div>
                <div className="text-2xl font-bold text-secondary">
                  ${parseFloat(startup.totalFunding).toLocaleString()}
                </div>
                <div className="text-sm text-neutral-600">Total Funding</div>
              </div>
            )}
            {metric === "rating" && (
              <div>
                <div className="text-2xl font-bold text-amber-500 flex items-center">
                  <Star className="w-5 h-5 mr-1 fill-current" />
                  {startup.averageRating.toFixed(1)}
                </div>
                <div className="text-sm text-neutral-600">Avg Rating</div>
              </div>
            )}
            {metric === "new" && (
              <div>
                <div className="text-sm font-medium text-primary">
                  {new Date(startup.createdAt).toLocaleDateString()}
                </div>
                <div className="text-sm text-neutral-600">Founded</div>
              </div>
            )}
          </div>
        </div>

        {/* Progress indicators */}
        {metric === "funding" && startup.totalFunding > 0 && (
          <div className="mt-4 pt-4 border-t border-neutral-100">
            <div className="flex justify-between text-sm text-neutral-600 mb-1">
              <span>Funding Progress</span>
              <span>${parseFloat(startup.totalFunding).toLocaleString()} raised</span>
            </div>
            <div className="w-full bg-neutral-200 rounded-full h-2">
              <div 
                className="bg-secondary h-2 rounded-full" 
                style={{ 
                  width: `${Math.min((parseFloat(startup.totalFunding) / 1000000) * 100, 100)}%` 
                }}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header user={user} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center">
                <Trophy className="w-8 h-8 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-neutral-900 mb-2">Startup Leaderboard</h1>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              Discover the top-performing startups and rising stars in our community
            </p>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <div className="text-2xl font-bold text-neutral-900 mb-1">
                  {allStartups.length}
                </div>
                <div className="text-neutral-600">Total Startups</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <DollarSign className="w-6 h-6 text-secondary" />
                </div>
                <div className="text-2xl font-bold text-neutral-900 mb-1">
                  ${topByFunding.reduce((sum, startup) => sum + parseFloat(startup.totalFunding), 0).toLocaleString()}
                </div>
                <div className="text-neutral-600">Total Funding</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-amber-500/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Star className="w-6 h-6 text-amber-500" />
                </div>
                <div className="text-2xl font-bold text-neutral-900 mb-1">
                  {leaderboard.length > 0 
                    ? (leaderboard.reduce((sum, startup) => sum + startup.averageRating, 0) / leaderboard.length).toFixed(1)
                    : "0.0"
                  }
                </div>
                <div className="text-neutral-600">Avg Rating</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Leaderboard Tabs */}
        <Tabs defaultValue="overall" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overall" className="flex items-center space-x-2">
              <Trophy className="w-4 h-4" />
              <span>Overall</span>
            </TabsTrigger>
            <TabsTrigger value="funding" className="flex items-center space-x-2">
              <DollarSign className="w-4 h-4" />
              <span>Top Funded</span>
            </TabsTrigger>
            <TabsTrigger value="rating" className="flex items-center space-x-2">
              <Star className="w-4 h-4" />
              <span>Highest Rated</span>
            </TabsTrigger>
            <TabsTrigger value="newest" className="flex items-center space-x-2">
              <Zap className="w-4 h-4" />
              <span>Rising Stars</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overall">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-primary" />
                  <span>Overall Rankings</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {leaderboardLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} className="h-24 bg-neutral-200 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : leaderboard.length > 0 ? (
                  <div className="space-y-4">
                    {leaderboard.map((startup, index) => 
                      renderStartupCard(startup, index + 1, "overall")
                    )}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Trophy className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-neutral-900 mb-2">
                      No Rankings Yet
                    </h3>
                    <p className="text-neutral-600">
                      Be the first to create a startup and get rated!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="funding">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="w-5 h-5 text-secondary" />
                  <span>Top Funded Startups</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {leaderboardLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} className="h-24 bg-neutral-200 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : topByFunding.length > 0 ? (
                  <div className="space-y-4">
                    {topByFunding.map((startup, index) => 
                      renderStartupCard(startup, index + 1, "funding")
                    )}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <DollarSign className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-neutral-900 mb-2">
                      No Funding Data
                    </h3>
                    <p className="text-neutral-600">
                      Start a funding round to appear here!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rating">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Star className="w-5 h-5 text-amber-500" />
                  <span>Highest Rated Startups</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {leaderboardLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} className="h-24 bg-neutral-200 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : topByRating.filter(s => s.averageRating > 0).length > 0 ? (
                  <div className="space-y-4">
                    {topByRating
                      .filter(startup => startup.averageRating > 0)
                      .map((startup, index) => 
                        renderStartupCard(startup, index + 1, "rating")
                      )}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Star className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-neutral-900 mb-2">
                      No Ratings Yet
                    </h3>
                    <p className="text-neutral-600">
                      Get rated by investors to appear here!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="newest">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-primary" />
                  <span>Rising Stars</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {startupsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} className="h-24 bg-neutral-200 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : newestStartups.length > 0 ? (
                  <div className="space-y-4">
                    {newestStartups.map((startup, index) => 
                      renderStartupCard(startup, index + 1, "new")
                    )}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Zap className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-neutral-900 mb-2">
                      No New Startups
                    </h3>
                    <p className="text-neutral-600">
                      Be the first to create a startup!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
