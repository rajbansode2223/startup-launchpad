import { useParams, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useEffect, useState } from "react";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  ArrowLeft, 
  Video, 
  MessageSquare, 
  Users, 
  FileText,
  Send,
  Loader2,
  Clock,
  Play,
  Pause,
  Volume2
} from "lucide-react";

interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: string;
  type: "room";
}

export default function PitchRoom() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [participants, setParticipants] = useState<any[]>([]);
  const [isJoined, setIsJoined] = useState(false);

  // WebSocket connection for real-time features
  const { socket, isConnected } = useWebSocket();

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  const { data: room, isLoading: roomLoading } = useQuery({
    queryKey: ["/api/pitch-rooms", id],
    enabled: !!id && !!user,
  });

  const { data: startup, isLoading: startupLoading } = useQuery({
    queryKey: ["/api/startups", room?.startupId],
    enabled: !!room?.startupId && !!user,
  });

  const joinRoomMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/pitch-rooms/${id}/join`);
    },
    onSuccess: () => {
      setIsJoined(true);
      toast({
        title: "Joined Room",
        description: "You have successfully joined the pitch room.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to join pitch room. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle WebSocket messages
  useEffect(() => {
    if (socket) {
      const handleMessage = (event: MessageEvent) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.type === "room_message" && data.roomId === parseInt(id!)) {
            setMessages(prev => [...prev, {
              id: data.id || Date.now().toString(),
              senderId: data.senderId,
              senderName: data.senderName,
              content: data.content,
              timestamp: data.timestamp || new Date().toISOString(),
              type: "room"
            }]);
          } else if (data.type === "room_join" && data.roomId === parseInt(id!)) {
            setParticipants(prev => [...prev, data.participant]);
          } else if (data.type === "room_leave" && data.roomId === parseInt(id!)) {
            setParticipants(prev => prev.filter(p => p.id !== data.participantId));
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error);
        }
      };

      socket.addEventListener("message", handleMessage);
      return () => socket.removeEventListener("message", handleMessage);
    }
  }, [socket, id]);

  const sendMessage = () => {
    if (!message.trim() || !socket || !user) return;

    const messageData = {
      type: "room_message",
      roomId: parseInt(id!),
      senderId: user.id,
      senderName: `${user.firstName || ""} ${user.lastName || ""}`.trim() || "Anonymous",
      content: message.trim(),
      timestamp: new Date().toISOString(),
    };

    socket.send(JSON.stringify(messageData));
    setMessage("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  if (authLoading || roomLoading || startupLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  if (!room || !startup) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Header user={user} />
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="text-center py-12">
              <h2 className="text-xl font-semibold text-neutral-900 mb-2">
                Pitch Room Not Found
              </h2>
              <p className="text-neutral-600 mb-4">
                The pitch room you're looking for doesn't exist.
              </p>
              <Button onClick={() => setLocation("/")}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  const isOwner = startup.founderId === user.id;
  const roomStarted = room.status === "live";
  const roomEnded = room.status === "ended";

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header user={user} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-12rem)]">
          {/* Main Video/Presentation Area */}
          <div className="lg:col-span-3 space-y-4">
            {/* Room Header */}
            <Card>
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center space-x-3">
                      {roomStarted && (
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                          <span className="text-red-600 font-medium text-sm">LIVE</span>
                        </div>
                      )}
                      <span>{room.name}</span>
                    </CardTitle>
                    <p className="text-neutral-600 mt-1">{startup.name}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant={
                        roomStarted ? "destructive" :
                        room.status === "scheduled" ? "secondary" :
                        "outline"
                      }
                      className="capitalize"
                    >
                      {room.status}
                    </Badge>
                    {!isJoined && !roomEnded && (
                      <Button 
                        onClick={() => joinRoomMutation.mutate()}
                        disabled={joinRoomMutation.isPending}
                        size="sm"
                      >
                        {joinRoomMutation.isPending && (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        )}
                        <Video className="w-4 h-4 mr-2" />
                        Join Room
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Video/Presentation Area */}
            <Card className="flex-1">
              <CardContent className="p-0 h-full">
                <div className="bg-neutral-900 rounded-lg h-full min-h-[400px] flex items-center justify-center relative">
                  {roomStarted ? (
                    <div className="text-center text-white">
                      <Video className="w-16 h-16 mx-auto mb-4 text-neutral-400" />
                      <h3 className="text-xl font-semibold mb-2">Live Presentation</h3>
                      <p className="text-neutral-300">
                        {startup.name} is presenting live
                      </p>
                      <div className="flex items-center justify-center space-x-4 mt-6">
                        <Button variant="secondary" size="sm">
                          <Volume2 className="w-4 h-4 mr-2" />
                          Mute
                        </Button>
                        {startup.pitchDeckUrl && (
                          <Button variant="secondary" size="sm" asChild>
                            <a href={startup.pitchDeckUrl} target="_blank" rel="noopener noreferrer">
                              <FileText className="w-4 h-4 mr-2" />
                              View Deck
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  ) : room.status === "scheduled" ? (
                    <div className="text-center text-white">
                      <Clock className="w-16 h-16 mx-auto mb-4 text-neutral-400" />
                      <h3 className="text-xl font-semibold mb-2">Scheduled Presentation</h3>
                      <p className="text-neutral-300 mb-4">
                        Starts at {new Date(room.scheduledAt).toLocaleString()}
                      </p>
                      {startup.pitchDeckUrl && (
                        <Button variant="secondary">
                          <FileText className="w-4 h-4 mr-2" />
                          Preview Pitch Deck
                        </Button>
                      )}
                    </div>
                  ) : (
                    <div className="text-center text-white">
                      <Play className="w-16 h-16 mx-auto mb-4 text-neutral-400" />
                      <h3 className="text-xl font-semibold mb-2">Presentation Ended</h3>
                      <p className="text-neutral-300">
                        Thank you for attending
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Startup Info */}
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <span className="text-sm font-medium text-neutral-500">Industry</span>
                    <p className="text-neutral-900">{startup.industry}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-neutral-500">Stage</span>
                    <p className="text-neutral-900 capitalize">{startup.stage}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-neutral-500">Valuation</span>
                    <p className="text-neutral-900">
                      ${startup.valuation ? parseFloat(startup.valuation).toLocaleString() : "TBD"}
                    </p>
                  </div>
                </div>
                <div className="mt-4">
                  <p className="text-neutral-600">{startup.description}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Chat and Participants */}
          <div className="space-y-4">
            {/* Participants */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <Users className="w-5 h-5" />
                  <span>Participants ({participants.length + 1})</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {/* Room Owner */}
                  <div className="flex items-center space-x-2 p-2 bg-primary/5 rounded-lg">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={startup.founder?.profileImageUrl} />
                      <AvatarFallback>
                        {startup.founder?.firstName?.[0]}{startup.founder?.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-neutral-900">
                        {startup.founder?.firstName} {startup.founder?.lastName}
                      </p>
                      <p className="text-xs text-neutral-600">Founder</p>
                    </div>
                  </div>
                  
                  {/* Other Participants */}
                  {participants.map((participant, index) => (
                    <div key={participant.id} className="flex items-center space-x-2 p-2">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={participant.profileImageUrl} />
                        <AvatarFallback>
                          {participant.firstName?.[0]}{participant.lastName?.[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-neutral-900">
                          {participant.firstName} {participant.lastName}
                        </p>
                        <p className="text-xs text-neutral-600 capitalize">{participant.role}</p>
                      </div>
                    </div>
                  ))}
                  
                  {participants.length === 0 && (
                    <p className="text-sm text-neutral-500 text-center py-4">
                      No other participants yet
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Chat */}
            <Card className="flex flex-col h-96">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <MessageSquare className="w-5 h-5" />
                  <span>Chat</span>
                  {!isConnected && (
                    <Badge variant="outline" className="text-xs">
                      Connecting...
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="flex-1 flex flex-col p-0">
                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-3">
                    {messages.length === 0 ? (
                      <p className="text-sm text-neutral-500 text-center py-8">
                        No messages yet. Start the conversation!
                      </p>
                    ) : (
                      messages.map((msg) => (
                        <div key={msg.id} className={`flex items-start space-x-2 ${
                          msg.senderId === user.id ? "flex-row-reverse space-x-reverse" : ""
                        }`}>
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="text-xs">
                              {msg.senderName[0]?.toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className={`flex-1 min-w-0 ${
                            msg.senderId === user.id ? "text-right" : ""
                          }`}>
                            <div className="text-xs text-neutral-500 mb-1">
                              {msg.senderName} • {new Date(msg.timestamp).toLocaleTimeString()}
                            </div>
                            <div className={`inline-block px-3 py-2 rounded-lg text-sm ${
                              msg.senderId === user.id 
                                ? "bg-primary text-white" 
                                : "bg-neutral-100 text-neutral-900"
                            }`}>
                              {msg.content}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
                
                {/* Message Input */}
                <div className="p-4 border-t border-neutral-200">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Type a message..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      disabled={!isConnected || roomEnded}
                    />
                    <Button 
                      size="sm"
                      onClick={sendMessage}
                      disabled={!message.trim() || !isConnected || roomEnded}
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
